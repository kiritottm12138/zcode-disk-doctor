---
name: zcode-disk-doctor
description: Inspect how much disk space ZCode uses, explain where the space went, and open the Disk Doctor side panel for a visual breakdown and a reversible quarantine-based cleanup. Use when the user asks where ZCode's disk space went, why the data folder is large, what can be safely removed, or wants to clean logs/temp/update downloads without deleting files.
---

# ZCode Disk Doctor

Read-only disk accounting for ZCode, plus a side panel whose cleanup only
**renames** safe items into a quarantine folder. The plugin never deletes a
file.

## When to use

- "ZCode 占了多少磁盘？" / "Where did my disk space go?"
- "数据目录怎么这么大？" / "What is safe to remove?"
- "帮我清理一下日志/临时文件/更新包。" — run the report, then open the panel;
  the user performs the move there.
- The user wants a saved Markdown/JSON report of ZCode's storage — call
  `disk_report` with `write: true`; the default is an in-memory summary only.

## Tools

| Tool | What it does |
|---|---|
| `disk_report` | Read-only scan. Returns a Markdown summary; writes `.md` + `.json` only when `write: true` (default false). Parameters: `scope` (`summary`/`full`), `topN` (1..100), `write`, `categories`. |
| `open_disk_panel` | Opens the **空间体检** side panel. Use it whenever the user wants to see the breakdown or review cleanup. |

The panel also has app-only tools (`get_report`, `plan_cleanup`,
`perform_cleanup`, `undo_cleanup`, `open_folder`, …). **You cannot call those**;
they are intentionally hidden from the model. Never claim that you moved,
deleted, or cleaned files.

## Three areas, never summed

- **ZCode 数据** — `~/.zcode` (CLI db, artifacts, logs, exec, image cache,
  plugins) plus the desktop data folder from `ZCODE_DATA_BASE_DIR/.zcode`
  (`v2/`, task index, desktop logs, visualizations).
- **ZCode 程序** — the application install (e.g. `D:\Zcode12`), read-only.
- **系统缓存** — the Chromium user data under `%APPDATA%\ZCode` and the
  updater downloads under `%LOCALAPPDATA%\@zcodedesktop-updater`.

The three totals are reported side by side and **are never added together**.
The application and caches are not the user's ZCode data.

## Safety levels

- 🟢 **可以安全清理 / Safe** — logs, exec output, image cache, old plugin cache,
  temp directories, updater downloads. ZCode regenerates them.
- 🟠 **要谨慎处理 / Care** — session artifacts, subagent output, model I/O logs,
  installed plugin cache, marketplace clones, unknown data. Use the right
  method (e.g. uninstall a plugin) rather than deleting files.
- ⚪ **不要动 / Keep** — session database, settings/credentials, plugin private
  data, backups, workspaces, visualizations, the application, Chromium profile.

## Workflow

1. For a quick answer, call `disk_report` with `scope: "summary"`.
2. For a visual answer or any cleanup, call `open_disk_panel`.
3. Summarise in the user's language: the data-area total, the largest two or
   three categories, what is 🟢 safe, and what must not be touched.
4. If the user asks to clean up, tell them to use the panel: **看看会移动什么**
   → **移动到隔离区** (two clicks). If they want it back: **撤销** on the batch.
5. Reports live in the plugin data directory's `reports/` folder. The panel's
   **打开报告目录** button reveals it.

## Notes

- The scan only reads sizes/timestamps. It does not upload anything and makes
  no network calls.
- Paths in tool results and saved reports are redacted (`~` instead of the home
  directory). The panel shows real paths because the user copies/opens them.
- A cleanup is refused when the relevant item was touched recently; it is listed
  as "skipped" instead. This is deliberate — moving a live session's temp folder
  is not a cleanup.
- Chromium caches are marked 🟠 and are not auto-cleaned while ZCode is running.
- If the application folder is not detected automatically, set **ZCode 程序目录**
  in the plugin settings (or `app_dir` in the manifest's `userConfig`).
