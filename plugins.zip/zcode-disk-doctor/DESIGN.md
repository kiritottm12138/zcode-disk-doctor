# 设计文档

`zcode-disk-doctor` 回答一个 ZCode 自己不回答的问题：**ZCode 占了多少磁盘，这些字节
分别是谁的，哪些可以安全回收。** 本文记录设计、口径与不变式；安装与用法见
[README.md](README.md) 与 [USAGE.md](USAGE.md)。

---

## 1. 问题与范围

ZCode 的数据分布在多个位置：

- CLI 数据：`~/.zcode/cli/`（会话数据库、附件、日志、exec、图片缓存、插件）；
- 桌面端数据：`ZCODE_DATA_BASE_DIR/.zcode/v2/`（任务索引、设置、日志、可视化）；
- 程序本体：安装目录（如 `D:\Zcode12`）；
- 系统缓存：`%APPDATA%\ZCode` 的 Chromium 数据与更新下载缓存。

用户既不知道“这 400 MB 是什么”，也不知道“删掉哪个会坏”。插件把问题拆成：

1. **构成**：按类别、按条目，空间花在哪；
2. **归属**：哪些是 ZCode 可重建的，哪些是用户内容；
3. **回收**：对可安全回收的部分，如何在失败也能退回的前提下回收。

**非目标**：一键清理、读取文件内容、联网、动会话数据库/程序/登录态、发布公共市场。

---

## 2. 为什么是 MCP 工具 + MCP Apps 面板

DSH 插件用 Cordis + 宿主 Web 路由 + 浏览器半边。ZCode 没有这套扩展面；它提供的是：

- `.zcode-plugin/plugin.json` 清单；
- MCP stdio 服务器；
- `userConfig` 原生设置表单；
- `ui.surfaces` + `ui://.../panel.html` 的 MCP Apps 侧栏。

因此 ZCode 版的映射是：

| DSH | ZCode |
|---|---|
| `disk_report` 工具 | `disk_report` MCP 工具 |
| 3 条本地 HTTP 路由 | 面板专用 MCP 工具（`get_report`、`plan_cleanup`、…） |
| `client/client.js` 浏览器半边 | `ui/panel.js` + MCP Apps `App` 客户端 |
| schemastery 设置表单 | `userConfig` + 面板 ⚙ 写入 `config.json` |
| `rename` 隔离目录 | 同样的 `rename` 隔离目录 |

面板通过宿主代理调用本插件工具；`visibility: ["app"]` 的工具模型不可见，所以**模型无法
触发移动或打开文件夹**。这是比 DSH 更窄的权限面。

---

## 3. 三个区，永不相加

| 区 | 内容 | 为什么单独成区 |
|---|---|---|
| `data` | CLI 数据 + 桌面端数据 | 用户真正拥有的那部分 |
| `app` | ZCode 程序安装 | 归卸载程序管 |
| `cache` | Chromium 用户数据 + 更新下载缓存 | 在 ZCode 数据目录之外 |

**不相加**的原因不是硬链接重叠（ZCode 目前不用 pnpm 硬链接），而是口径：
程序与系统缓存不属于“你的 ZCode 数据”，把它们加起来会暗示一个不存在的“总占用”。
报告只给每个区自己的数字，头部主数字明确是 `data` 区。

---

## 4. 路径探测

`server/locate.js`：

```text
CLI 数据     ZDD_ZCODE_HOME → ~/.zcode/cli/config.json 的 storage.dir → ~/.zcode
桌面端数据    ZDD_DESKTOP_HOME → ZCODE_DATA_BASE_DIR/.zcode → CLI 数据目录
程序安装      ZCODE_APP_ROOT → resourcesPath → ZCODE_DESKTOP_NODE_EXECUTABLE
             → process.execPath → 常见安装位置；必须有 resources/app.asar 才算数
Chromium      %APPDATA%/ZCode → ~/Library/Application Support/ZCode → ~/.config/ZCode
更新缓存      %LOCALAPPDATA%/@zcodedesktop-updater → macOS/Linux 回落
插件目录      <zcodeHome>/cli/plugins；解析 junction 到真实目标
```

每个函数对输入纯：环境、可执行文件路径与文件系统探针可注入。探测不到就说探测不到，
不猜路径；`app_dir` / `zcode_home` / `desktop_home` 是手工逃生口。

**两个数据 home** 是这台机器的关键发现：桌面端 `ZCODE_DATA_BASE_DIR=D:\zcodeworking`
让 `v2/` 落在 `D:\zcodeworking\.zcode`，而 CLI 的 `cli/db` 仍在 `~/.zcode`。插件同时统计
两者；如果一者包含另一者，只扫描外层，避免重复。

---

## 5. 类别表与精确划分

`server/targets.js` 的类别声明 `area`、`safety`、`regenerable`、`roots`、`enumerate`、
`reclaim`（“删了会怎样”）与 `recentMs`（清理前的安静期）。

- **数据区每个字节恰好落进一个类别**：`other` 是兜底，但它不是简单的第一层遍历，而是
  “残留枚举”：遇到包含已覆盖根的子目录就继续下钻，否则把该条目作为一个 item。这样
  `cli/log` 不会被 `cli` 整块重复计算。
- **三桶相加等于总数**：`safe + care + keep = total`，报告与面板的数字来自同一份类别表。
- **chromium-cache 与 chromium-profile 不重叠**：profile 枚举时按名字跳过五个缓存目录。
- **插件目录外置**：`<zcodeHome>/cli/plugins` 是 junction 时，真实目标计入数据区，链接本身
  从兜底里排除；报告注明“插件目录外置”。

23 个类别、三个区；数据区保证不漏账。

---

## 6. 扫描

- 只 `stat`，不 `open`；不读取文件内容。
- 并发 64 个 `lstat`、16 个子目录；失败不中断；无权限/消失/循环链接记录后跳过。
- 默认不跟随符号链接；开启后按 `realpath` 去重。
- 上限 50 万文件 / 30 秒；撞上限置 `truncated`。
- 硬链接按 `dev:ino` 去重；同一次扫描里记录重叠字节（为未来 pnpm 布局保留）。
- 链接安装：目标在扫描范围之外的链接单独列出真实目标与大小，不计入任何区。
- 扫描结果缓存不设全局缓存；面板每次展开只扫描一个类别，`get_report` 只取 top 3，
  所以载荷小、速度快。

真实机器实测：约 0.3 秒完成数据/程序/缓存三区（4.3 亿 + 8.4 亿 + 4.5 亿字节）。

---

## 7. 清理：预演 → 移动 → 撤销

### 预演

- 只扫描 🟢 类别；
- 条目上限 500；
- 最近 1 小时（更新包 24 小时、旧插件 24 小时）内被改动的条目跳过，写 `skipped`
  （`reason: "recent"`）；
- 目的地只计算、不创建；预演零副作用。

### 移动

- 需要 `allow_cleanup === true` + 面板二次确认 + 工具参数 `confirm: true`；
- 服务端重新预演，逐项 `ownsCleanupPath()` 复核，再 `renameSync`；
- 目标为 `<quarantine>/<批次>/<类别>/<原始布局>`；重名加 `-2`/`-3`；
- 每移动一项重写 `manifest.json`；中途中断仍与磁盘一致；
- 跨卷 `EXDEV` 记为失败并原样留在原地，**不复制、不删除**。

### 撤销

- 批次 id 必须匹配 `YYYYMMDD-HHMMSS`；
- 每个 target 必须在批次内；每个 original 必须属于安全类别；
- 原位置已存在则拒绝覆盖（`occupied`）；
- 倒序恢复（先子后父）；
- 即使 `allow_cleanup` 关闭也允许撤销。

---

## 8. 面板

- 单文件 `dist/ui/panel.html`，内联 CSS/JS，无外部资源；
- `@modelcontextprotocol/ext-apps` 的 `App` 连接宿主，`callServerTool` 取数；
- 三个区、三种视图、类别展开、打开/复制、清理框、批次、⚙、颜色说明；
- 中英双语；跟随宿主 locale 或设置；
- 所有宿主字符串用 `textContent` 渲染，不使用 `innerHTML`；
- 载荷：`get_report` 只返回类别摘要（top 3 留在服务端），详情用 `get_category` 分页；
  `plan_cleanup` 默认每页 100 项。这避开了 MCP Apps `structuredContent` 的 64 KB 上限。

---

## 9. 工具面

模型可见：

- `disk_report`：只读扫描 + 报告；
- `open_disk_panel`：打开面板。

面板专用（`visibility: ["app"]`）：

- `get_report`、`get_category`；
- `get_settings`、`set_settings`、`reset_settings`；
- `plan_cleanup`、`perform_cleanup`、`undo_cleanup`、`list_quarantine`；
- `open_folder`、`open_reports`、`open_quarantine`。

`set_settings` 只接受行为字段，不接受路径；`perform_cleanup` 需要开关 + 确认；
`undo_cleanup` 只恢复。

---

## 10. 由测试钉住的不变量

1. 源码不出现 `unlink`/`rm`/`rmdir`/`trashItem`/`Remove-Item`/`shutil.rmtree`；
2. `renameSync` 只出现在 `server/cleanup.js`；
3. 源码不出现 `fetch`/`http.request`/`https.request`/`net.connect`/WebSocket/XMLHttpRequest；
4. 数据区各类别之和 = 数据区总数；
5. 安全三桶之和 = 区总数；
6. 预演不创建隔离目录；
7. 移动只发生在 safe 类别；
8. 撤销拒绝占用、拒绝越界 target、拒绝不属于安全类别的 original；
9. 面板无外部 script/stylesheet、无 `innerHTML`；
10. MCP 工具可见性、面板资源 MIME、`userConfig` 与清单一致。

---

## 11. 限制

- Windows 实测；macOS/Linux 探测回退未实测。
- 会话标题不读 SQLite，按 `sess_...` 分组。
- Chromium 缓存运行期间不自动清理。
- 扫描上限内结果完整；撞上限会标注。
- 隔离目录需要用户自己清空；插件没有删除功能。
- `userConfig` 变更通常在新会话生效；面板 ⚙ 的覆盖立即生效。

---

## 12. 代码布局

```text
.zcode-plugin/plugin.json   清单、userConfig、ui.surfaces
server/
  index.js                  MCP stdio 入口
  tools.js                  工具/资源注册与 handler
  locate.js                 数据/程序/缓存/插件路径探测
  targets.js                三区、类别表、归属规则
  scan.js                   并发遍历、聚合、上限、链接
  cleanup.js                预演、移动、manifest、撤销
  report.js                 Markdown / JSON 投影、脱敏
  settings.js               默认值、环境、面板覆盖
ui/
  panel.js                  面板逻辑（DOM，无框架）
  panel.css                 主题化样式
  panel.html                构建模板
scripts/
  build.mjs                 esbuild 打包
  check-safety.mjs          安全不变量检查
test/
  core.test.mjs             扫描/清理/报告/设置/定位
  server.test.mjs           MCP stdio 冒烟
  panel-harness.html        MCP Apps 模拟宿主（视觉自查）
```
