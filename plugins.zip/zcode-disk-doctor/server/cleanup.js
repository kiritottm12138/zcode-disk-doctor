/**
 * Cleanup: the preview of what *would* move, and the one step that actually
 * moves it.
 *
 * The design is intentionally boring and reversible:
 *
 * - the preview is a read-only scan of the 🟢 safe categories;
 * - the move renames items into a quarantine folder and rewrites the manifest
 *   after every single item, so an interrupted run still records exactly what
 *   moved;
 * - undo re-validates the manifest against the disk before touching anything,
 *   refuses to overwrite an occupied original, and never deletes.
 *
 * `fs.renameSync` is the only filesystem-mutating call in this module. There is
 * no copy and no delete anywhere in the plugin.
 *
 * @module zcode-disk-doctor/cleanup
 */

import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'

import { isUnder, pathKey, pathTraversesLink } from './locate.js'
import { timestampSlug } from './report.js'
import { scan } from './scan.js'
import { CATEGORY_DEFS, categoryById, cleanableCategories, ownsCleanupPath } from './targets.js'

export const PREVIEW_ITEM_LIMIT = 500

export const RECENT_USE_MS = 60 * 60 * 1000

export const MANIFEST_NAME = 'manifest.json'

const BATCH_ID_PATTERN = /^\d{8}-\d{6}(-\d+)?$/

export const QUARANTINE_SCHEMA = 'zcode-disk-doctor/quarantine@1'

export const CLEANUP_SCHEMA = 'zcode-disk-doctor/cleanup@1'

export function quarantineRoot (settings) {
  return settings.quarantineDir
}

export function quarantineDirectory (settings, now = new Date()) {
  return path.join(quarantineRoot(settings), timestampSlug(now))
}

function scanOptions (env, settings, only, topN, limits) {
  return {
    zcodeHome: env.zcodeHome,
    desktopHome: env.desktopHome,
    tempDir: env.tempDir,
    appRoot: env.appRoot ?? null,
    appRootSource: env.appRootSource ?? null,
    chromiumDir: env.chromiumDir ?? null,
    chromiumSessionDir: env.chromiumSessionDir ?? null,
    updaterDir: env.updaterDir ?? null,
    pluginsRoot: env.pluginsRoot ?? null,
    pluginsLinkPath: env.pluginsLinkPath ?? null,
    pluginsIsLink: env.pluginsIsLink === true,
    globalCli: env.globalCli ?? null,
    quarantineDir: settings.quarantineDir ?? null,
    // Cleanup never follows links. The report may, when asked to, but a preview
    // that lists a link target as movable bytes is a promise a rename cannot keep.
    followSymlinks: false,
    excludeGlobs: settings.excludeGlobs ?? [],
    only,
    topN,
    ...(limits === undefined ? {} : { limits })
  }
}

/** The device id of the deepest existing ancestor, or null. */
function deviceOf (candidate) {
  let current = path.resolve(candidate)
  for (;;) {
    try {
      return fs.statSync(current).dev
    } catch {
      const parent = path.dirname(current)
      if (parent === current) return null
      current = parent
    }
  }
}

/** True when two paths live on the same volume, so rename cannot hit EXDEV. */
function sameVolume (a, b) {
  const left = deviceOf(a)
  const right = deviceOf(b)
  if (left !== null && right !== null) return left === right
  const rootA = path.parse(path.resolve(a)).root
  const rootB = path.parse(path.resolve(b)).root
  return process.platform === 'win32' ? rootA.toLowerCase() === rootB.toLowerCase() : rootA === rootB
}

/** The session id of the running ZCode session, when the host exposes it. */
function activeSessionId (env = process.env) {
  const raw = env.ZCODE_SESSION_ID ?? env.CLAUDE_SESSION_ID ?? ''
  return typeof raw === 'string' ? raw.trim() : ''
}

/** True when `candidate` is the running session's own output directory. */
function isActiveSessionPath (candidate, sessionId) {
  if (sessionId === '') return false
  const bare = sessionId.startsWith('session_') ? sessionId.slice('session_'.length) : sessionId
  const names = new Set([sessionId, `session_${bare}`, `sess_${bare}`])
  return candidate.split(/[\\/]+/).some((part) => names.has(part))
}

/**
 * Draw up a dry run.
 *
 * @param {object} options - cleanup options.
 * @param {object} options.env - resolved scan environment.
 * @param {object} options.settings - effective settings.
 * @param {Date} [options.now] - the instant the plan is drawn up.
 * @param {object} [options.limits] - scan ceilings.
 * @returns {Promise<object>} the plan; `dryRun` is always true.
 */
export async function planCleanup (options) {
  const now = options.now ?? new Date()
  const destination = quarantineDirectory(options.settings, now)
  const eligible = cleanableCategories()
  const report = await scan(scanOptions(
    options.env,
    options.settings,
    eligible.map((category) => category.id),
    PREVIEW_ITEM_LIMIT,
    options.limits
  ))

  const items = []
  const skipped = []
  const excluded = []
  const categories = []
  const sessionId = options.sessionId ?? activeSessionId()
  let truncated = false

  const exclude = (category, item, reason) => {
    excluded.push({
      categoryId: category.id,
      categoryLabel: category.label,
      path: item.path,
      bytes: item.bytes,
      files: item.files,
      reason
    })
  }

  for (const category of report.categories) {
    if (category.bytes === 0 && category.itemCount === 0) continue
    if (category.itemCount > category.topItems.length) truncated = true
    categories.push({
      id: category.id,
      label: category.label,
      labelEn: category.labelEn,
      bytes: category.bytes,
      files: category.files,
      itemCount: category.itemCount
    })
    for (const item of category.topItems) {
      if (isActiveSessionPath(item.path, sessionId)) {
        exclude(category, item, 'active-session')
        continue
      }
      if (!sameVolume(item.path, destination)) {
        exclude(category, item, 'cross-device')
        continue
      }
      if (pathTraversesLink(item.path)) {
        exclude(category, item, 'linked')
        continue
      }
      const recentMs = category.recentMs ?? RECENT_USE_MS
      if (await recentlyUsed(item, now, recentMs)) {
        skipped.push({
          categoryId: category.id,
          categoryLabel: category.label,
          path: item.path,
          bytes: item.bytes,
          reason: 'recent'
        })
        continue
      }
      items.push({
        categoryId: category.id,
        categoryLabel: category.label,
        path: item.path,
        bytes: item.bytes,
        files: item.files,
        mtimeMs: item.mtimeMs ?? 0,
        root: category.roots.find((root) => isUnder(item.path, root)) ?? null,
        ...(item.note === undefined ? {} : { note: item.note })
      })
    }
  }

  items.sort((a, b) => b.bytes - a.bytes)
  skipped.sort((a, b) => b.bytes - a.bytes)
  excluded.sort((a, b) => b.bytes - a.bytes)

  const totalBytes = items.reduce((sum, item) => sum + item.bytes, 0)
  const totalFiles = items.reduce((sum, item) => sum + item.files, 0)
  const skippedBytes = skipped.reduce((sum, item) => sum + item.bytes, 0)
  const excludedBytes = excluded.reduce((sum, item) => sum + item.bytes, 0)

  return {
    schema: CLEANUP_SCHEMA,
    generatedAt: now.toISOString(),
    dryRun: true,
    destination,
    totalBytes,
    totalFiles,
    itemCount: items.length,
    truncated,
    eligible: eligible.map((category) => category.id),
    items,
    skipped,
    skippedBytes,
    excluded,
    excludedBytes,
    excludedCount: excluded.length,
    categories,
    warnings: previewWarnings({ totalBytes, truncated, skippedBytes, excluded, excludedBytes }),
    refused: CATEGORY_DEFS
      .filter((category) => category.safety !== 'safe')
      .map((category) => ({ id: category.id, label: category.label, safety: category.safety }))
  }
}

async function recentlyUsed (item, now, recentMs) {
  if (!Number.isFinite(recentMs) || recentMs <= 0) return false
  if (Number.isFinite(item.mtimeMs) && item.mtimeMs > 0) {
    return now.getTime() - item.mtimeMs < recentMs
  }
  try {
    const stat = await fsp.stat(item.path)
    return now.getTime() - stat.mtimeMs < recentMs
  } catch {
    return true
  }
}

function previewWarnings (facts) {
  const warnings = [
    '这是**预演**：只列出「如果清理会移动什么」，没有移动、复制或删除任何文件'
  ]
  if (facts.totalBytes === 0 && facts.skippedBytes === 0 && facts.excludedBytes === 0) {
    warnings.push('现在没有「可以安全清理」的内容，清理功能暂时没有东西可做')
  }
  warnings.push('只有 🟢「可以安全清理」的内容参与；🟠「要谨慎处理」和 ⚪「不要动」一律不参与——' +
    '会话数据库、插件、程序文件与登录态都不在清理范围内')
  if (facts.totalBytes > 0) {
    warnings.push('这些内容 ZCode 会按需重新生成（日志、临时文件、图片缓存、更新包），' +
      '清理不会影响使用，只是下次用到时要重新生成或下载')
  }
  if (facts.skippedBytes > 0) {
    warnings.push(`另有 ${facts.skippedBytes} 字节的内容最近还在改动，可能正被 ZCode 使用，` +
      '这次不列入计划（等它们安静下来再清）')
  }
  const countByReason = (reason) => facts.excluded.filter((item) => item.reason === reason).length
  const crossDevice = countByReason('cross-device')
  const activeSession = countByReason('active-session')
  const linked = countByReason('linked')
  if (crossDevice > 0) {
    warnings.push(`另有 ${crossDevice} 项位于其他磁盘，无法移动到当前隔离区，已从计划中排除`)
  }
  if (activeSession > 0) {
    warnings.push(`另有 ${activeSession} 项属于当前会话，已跳过（避免移动正在使用的输出）`)
  }
  if (linked > 0) {
    warnings.push(`另有 ${linked} 项路径经过符号链接/junction，已跳过（避免越界移动）`)
  }
  if (facts.truncated) {
    warnings.push(`某一类的条目超过 ${PREVIEW_ITEM_LIMIT} 条；分类总量见报告，这里只移动列出的条目`)
  }
  return warnings
}

/**
 * Move everything the preview lists into a fresh quarantine batch.
 *
 * @param {object} options - cleanup options.
 * @returns {Promise<object>} the batch result.
 */
export async function performCleanup (options) {
  const now = options.now ?? new Date()
  // A caller that has just drawn a plan may pass it in, so the preview the user
  // saw and the move act on the same fresh list. Every item is still re-validated
  // below before it is touched.
  const plan = options.plan ?? await planCleanup({ ...options, now })
  const batchDir = freeBatchDir(plan.destination)
  const record = {
    schema: QUARANTINE_SCHEMA,
    id: path.basename(batchDir),
    createdAt: now.toISOString(),
    zcodeHome: options.env.zcodeHome,
    status: 'moving',
    bytes: 0,
    files: 0,
    items: [],
    skippedRecent: plan.skipped,
    failures: []
  }

  if (plan.items.length === 0) {
    return { ...record, status: 'nothing-to-move', manifestPath: null }
  }
  fs.mkdirSync(batchDir, { recursive: true })
  writeManifest(batchDir, record)

  for (const item of plan.items) {
    if (!ownsCleanupPath(options.env, item.path)) {
      record.failures.push({ original: item.path, reason: 'outside-root' })
      continue
    }
    if (!fs.existsSync(item.path)) {
      record.failures.push({ original: item.path, reason: 'missing' })
      continue
    }
    if (!sameVolume(item.path, batchDir)) {
      record.failures.push({ original: item.path, reason: 'cross-device' })
      continue
    }
    if (pathTraversesLink(item.path)) {
      record.failures.push({ original: item.path, reason: 'linked' })
      continue
    }
    let target
    try {
      target = uniqueTarget(batchDir, item)
      if (!isUnder(target, batchDir)) {
        record.failures.push({ original: item.path, reason: 'target-outside-batch' })
        continue
      }
      fs.mkdirSync(path.dirname(target), { recursive: true })
      if (pathTraversesLink(item.path)) {
        record.failures.push({ original: item.path, reason: 'linked' })
        continue
      }
      fs.renameSync(item.path, target)
    } catch (error) {
      const reason = error?.code === 'EXDEV' ? 'cross-device' : String(error?.code ?? error?.message ?? error)
      record.failures.push({ original: item.path, reason })
      continue
    }
    record.items.push({
      categoryId: item.categoryId,
      original: item.path,
      target,
      bytes: item.bytes,
      files: item.files,
      mtimeMs: item.mtimeMs ?? 0
    })
    record.bytes += item.bytes
    record.files += item.files
    try {
      writeManifest(batchDir, record)
    } catch {
      record.failures.push({ original: item.path, reason: 'manifest-write-failed' })
      record.status = 'moved-with-failures'
      return { ...record, manifestPath: path.join(batchDir, MANIFEST_NAME) }
    }
  }

  record.status = record.failures.length === 0 ? 'moved' : 'moved-with-failures'
  writeManifest(batchDir, record)
  return { ...record, manifestPath: path.join(batchDir, MANIFEST_NAME) }
}

function freeBatchDir (proposed) {
  if (!fs.existsSync(proposed)) return proposed
  for (let index = 2; index < 1000; index++) {
    const candidate = `${proposed}-${index}`
    if (!fs.existsSync(candidate)) return candidate
  }
  throw new Error('EEXIST')
}

function uniqueTarget (batchDir, item) {
  const relative = item.root === null ? path.basename(item.path) : path.relative(item.root, item.path)
  const leaf = relative === '' ? path.basename(item.path) : relative
  const base = path.join(batchDir, item.categoryId, leaf)
  if (!fs.existsSync(base)) return base
  for (let index = 2; index < 1000; index++) {
    const candidate = `${base}-${index}`
    if (!fs.existsSync(candidate)) return candidate
  }
  throw new Error('EEXIST')
}

function writeManifest (batchDir, record) {
  fs.mkdirSync(batchDir, { recursive: true })
  const target = path.join(batchDir, MANIFEST_NAME)
  const temp = `${target}.${process.pid}.${Date.now()}.tmp`
  fs.writeFileSync(temp, `${JSON.stringify(record, null, 2)}\n`, 'utf8')
  fs.renameSync(temp, target)
}

export function readManifest (settings, id) {
  if (typeof id !== 'string' || !BATCH_ID_PATTERN.test(id)) return null
  try {
    const raw = fs.readFileSync(path.join(quarantineRoot(settings), id, MANIFEST_NAME), 'utf8')
    const parsed = JSON.parse(raw)
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) return null
    if (parsed.schema !== QUARANTINE_SCHEMA) return null
    if (parsed.id !== id) return null
    if (!Array.isArray(parsed.items) || parsed.items.length > 10_000) return null
    return parsed
  } catch {
    return null
  }
}

export function listQuarantine (settings) {
  const root = quarantineRoot(settings)
  let names
  try {
    names = fs.readdirSync(root, { withFileTypes: true })
      .filter((entry) => entry.isDirectory() && BATCH_ID_PATTERN.test(entry.name))
      .map((entry) => entry.name)
  } catch {
    return []
  }
  return names.sort().reverse().map((id) => {
    const record = readManifest(settings, id)
    return {
      id,
      path: path.join(root, id),
      createdAt: record?.createdAt ?? null,
      status: record?.status ?? 'unreadable',
      itemCount: record?.items?.length ?? 0,
      bytes: record?.bytes ?? 0,
      failures: record?.failures?.length ?? 0
    }
  })
}

/**
 * Move one batch back where it came from.
 *
 * Undo is allowed even when the cleanup permission switch is off: it only
 * restores files. Everything is re-validated before a single rename happens.
 *
 * @param {object} options - cleanup environment plus `id`.
 * @returns {object} what was restored, what was refused, and why.
 */
export function undoCleanup (options) {
  const { env, settings, id } = options
  const record = readManifest(settings, id)
  if (record === null) return { ok: false, reason: 'no-manifest', id }
  if (record.status === 'undone') return { ok: false, reason: 'already-undone', id }

  const batchDir = path.join(quarantineRoot(settings), id)
  const restored = []
  const failures = []

  for (const item of [...(record.items ?? [])].reverse()) {
    if (typeof item?.target !== 'string' || typeof item?.original !== 'string') {
      failures.push({ original: String(item?.original ?? ''), reason: 'bad-record' })
      continue
    }
    const category = categoryById(item.categoryId)
    if (category === null || category.safety !== 'safe') {
      failures.push({ original: item.original, reason: 'bad-record' })
      continue
    }
    if (!isUnder(item.target, batchDir)) {
      failures.push({ original: item.original, reason: 'target-outside-batch' })
      continue
    }
    if (pathTraversesLink(item.target)) {
      failures.push({ original: item.original, reason: 'target-linked' })
      continue
    }
    if (!ownsCleanupPath(env, item.original)) {
      failures.push({ original: item.original, reason: 'original-outside-roots' })
      continue
    }
    if (!fs.existsSync(item.target)) {
      failures.push({ original: item.original, reason: 'not-in-quarantine' })
      continue
    }
    if (fs.existsSync(item.original)) {
      failures.push({ original: item.original, reason: 'occupied' })
      continue
    }
    try {
      fs.mkdirSync(path.dirname(item.original), { recursive: true })
      if (pathTraversesLink(item.original)) {
        failures.push({ original: item.original, reason: 'original-linked' })
        continue
      }
      fs.renameSync(item.target, item.original)
    } catch (error) {
      failures.push({ original: item.original, reason: String(error?.code ?? error?.message ?? error) })
      continue
    }
    restored.push({ original: item.original, target: item.target, bytes: item.bytes ?? 0 })
  }

  const status = failures.length === 0 ? 'undone' : restored.length === 0 ? record.status : 'partly-undone'
  const updated = { ...record, status, restored, failures: [...(record.failures ?? []), ...failures] }
  writeManifest(batchDir, updated)
  return {
    ok: failures.length === 0,
    id,
    status,
    restored,
    failures,
    restoredBytes: restored.reduce((sum, item) => sum + item.bytes, 0),
    manifestPath: path.join(batchDir, MANIFEST_NAME)
  }
}

/** True when `candidate` is inside the configured quarantine root. */
export function isInsideQuarantine (settings, candidate) {
  return isUnder(candidate, quarantineRoot(settings))
}

/** Exposed for tests: the path key used by the ownership checks. */
export { pathKey }
