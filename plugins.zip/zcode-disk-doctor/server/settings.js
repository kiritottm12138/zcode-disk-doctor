/**
 * Effective plugin settings.
 *
 * Three layers, lowest first:
 *   1. built-in defaults
 *   2. `userConfig` values, which ZCode injects as `ZDD_*` environment variables
 *   3. `config.json` in the plugin data directory, written by the panel's gear
 *
 * Only behavioural settings can be overridden from the panel. Paths stay in the
 * native ZCode settings form, so a panel cannot point the scanner or the
 * quarantine at an arbitrary directory.
 *
 * @module zcode-disk-doctor/settings
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import { ZCODE_HOME_DIR_NAME, canonicalizeDirectory, expandHome, resolveDesktopHome, resolveZcodeHome } from './locate.js'

export const CONFIG_VERSION = 1

export const DEFAULT_SETTINGS = Object.freeze({
  topN: 10,
  followSymlinks: false,
  allowOpenFolder: true,
  allowOpenFolderSensitive: false,
  allowCleanup: false,
  excludeGlobs: [],
  language: 'auto'
})

/** Keys the panel may change. Paths are deliberately absent. */
export const OVERRIDE_KEYS = Object.freeze([
  'topN',
  'followSymlinks',
  'allowOpenFolder',
  'allowOpenFolderSensitive',
  'allowCleanup',
  'excludeGlobs',
  'language'
])

export function pluginDataDir (env = process.env) {
  const explicit = typeof env.ZCODE_PLUGIN_DATA === 'string' ? env.ZCODE_PLUGIN_DATA.trim() : ''
  if (explicit !== '') return canonicalizeDirectory(explicit)
  // Never fall back to a shared, world-writable temp folder: a planted config
  // there could turn cleanup on or point the scanner somewhere else.
  return path.join(os.homedir(), ZCODE_HOME_DIR_NAME, '.disk-doctor')
}

export function configPath (pluginData = pluginDataDir()) {
  return path.join(pluginData, 'config.json')
}

function emptyConfig () {
  return { version: CONFIG_VERSION, overrides: {} }
}

/**
 * Read the panel overrides. A malformed file is reported, not fatal.
 * @param {string} pluginData - the plugin data directory.
 * @returns {{ overrides: object, warning: string|null }}
 */
export function readOverrides (pluginData) {
  try {
    const parsed = JSON.parse(fs.readFileSync(configPath(pluginData), 'utf8'))
    const overrides = parsed?.overrides
    if (overrides === null || typeof overrides !== 'object' || Array.isArray(overrides)) {
      return { overrides: {}, warning: 'config.json 的 overrides 不是对象，已忽略' }
    }
    return { overrides, warning: null }
  } catch (error) {
    if (error?.code === 'ENOENT') return { overrides: {}, warning: null }
    return { overrides: {}, warning: `config.json 无法读取，已使用默认值：${String(error?.message ?? error)}` }
  }
}

/**
 * Write the panel overrides.
 * @param {string} pluginData - the plugin data directory.
 * @param {object} overrides - validated overrides.
 * @returns {void}
 */
export function writeOverrides (pluginData, overrides) {
  fs.mkdirSync(pluginData, { recursive: true })
  const payload = { version: CONFIG_VERSION, overrides }
  fs.writeFileSync(configPath(pluginData), `${JSON.stringify(payload, null, 2)}\n`, 'utf8')
}

/** Clear the panel overrides without deleting the file. */
export function clearOverrides (pluginData) {
  writeOverrides(pluginData, {})
}

function parseBoolean (value, fallback) {
  if (typeof value === 'boolean') return value
  if (typeof value !== 'string') return fallback
  const normalized = value.trim().toLowerCase()
  if (normalized === 'true' || normalized === '1' || normalized === 'yes' || normalized === 'on') return true
  if (normalized === 'false' || normalized === '0' || normalized === 'no' || normalized === 'off') return false
  return fallback
}

function parseTopN (value, fallback) {
  const number = Number(value)
  if (!Number.isInteger(number) || number < 1 || number > 100) return fallback
  return number
}

function parseGlobs (value) {
  if (Array.isArray(value)) {
    return value.filter((item) => typeof item === 'string' && item.trim() !== '').map((item) => item.trim())
  }
  if (typeof value !== 'string') return []
  return value.split(',').map((item) => item.trim()).filter((item) => item !== '')
}

function normalizeLanguage (value) {
  if (value === 'zh-CN' || value === 'en-US') return value
  return 'auto'
}

function resolvedPathOrEmpty (value, home) {
  const raw = typeof value === 'string' ? value.trim() : ''
  if (raw === '') return ''
  return canonicalizeDirectory(expandHome(raw, home))
}

/**
 * Load the effective settings.
 *
 * @param {object} [options] - overrides, for tests.
 * @param {NodeJS.ProcessEnv} [options.env] - environment.
 * @param {string} [options.home] - OS home.
 * @param {string} [options.pluginData] - plugin data directory.
 * @param {object} [options.overrides] - pre-read overrides (tests).
 * @returns {object} effective settings plus path resolution and sources.
 */
export function loadSettings (options = {}) {
  const env = options.env ?? process.env
  const home = options.home ?? os.homedir()
  const pluginData = options.pluginData ?? pluginDataDir(env)
  const read = options.overrides === undefined ? readOverrides(pluginData) : { overrides: options.overrides, warning: null }
  const overrides = read.overrides ?? {}
  const sources = {}

  const envTopN = typeof env.ZDD_TOP_N === 'string' && env.ZDD_TOP_N.trim() !== ''
    ? parseTopN(env.ZDD_TOP_N, DEFAULT_SETTINGS.topN)
    : DEFAULT_SETTINGS.topN
  const envFollow = parseBoolean(env.ZDD_FOLLOW_SYMLINKS, DEFAULT_SETTINGS.followSymlinks)
  const envOpen = parseBoolean(env.ZDD_ALLOW_OPEN, DEFAULT_SETTINGS.allowOpenFolder)
  const envOpenSensitive = parseBoolean(env.ZDD_ALLOW_OPEN_SENSITIVE, DEFAULT_SETTINGS.allowOpenFolderSensitive)
  const envGlobs = parseGlobs(env.ZDD_EXCLUDE_GLOBS)
  const envLanguage = normalizeLanguage(env.ZDD_LANGUAGE)

  const topN = overrides.topN === undefined ? envTopN : parseTopN(overrides.topN, envTopN)
  sources.topN = overrides.topN === undefined ? (env.ZDD_TOP_N ? 'env' : 'default') : 'panel'
  const followSymlinks = overrides.followSymlinks === undefined
    ? envFollow
    : parseBoolean(overrides.followSymlinks, envFollow)
  sources.followSymlinks = overrides.followSymlinks === undefined ? 'env' : 'panel'
  const allowOpenFolder = overrides.allowOpenFolder === undefined
    ? envOpen
    : parseBoolean(overrides.allowOpenFolder, envOpen)
  sources.allowOpenFolder = overrides.allowOpenFolder === undefined ? 'env' : 'panel'
  const allowOpenFolderSensitive = overrides.allowOpenFolderSensitive === undefined
    ? envOpenSensitive
    : parseBoolean(overrides.allowOpenFolderSensitive, envOpenSensitive)
  sources.allowOpenFolderSensitive = overrides.allowOpenFolderSensitive === undefined ? 'env' : 'panel'
  const allowCleanup = overrides.allowCleanup === undefined
    ? DEFAULT_SETTINGS.allowCleanup
    : parseBoolean(overrides.allowCleanup, false)
  sources.allowCleanup = overrides.allowCleanup === undefined ? 'default' : 'panel'
  const excludeGlobs = overrides.excludeGlobs === undefined
    ? envGlobs
    : parseGlobs(overrides.excludeGlobs)
  sources.excludeGlobs = overrides.excludeGlobs === undefined ? 'env' : 'panel'
  const language = overrides.language === undefined
    ? envLanguage
    : normalizeLanguage(overrides.language)
  sources.language = overrides.language === undefined ? 'env' : 'panel'

  const zcodeHomeRaw = typeof env.ZDD_ZCODE_HOME === 'string' ? env.ZDD_ZCODE_HOME.trim() : ''
  const zcodeHome = resolveZcodeHome({ env, home, zcodeHome: zcodeHomeRaw })
  const desktopHomeRaw = typeof env.ZDD_DESKTOP_HOME === 'string' ? env.ZDD_DESKTOP_HOME.trim() : ''
  const desktopHome = resolveDesktopHome({
    env,
    home,
    zcodeHome: zcodeHomeRaw,
    desktopHome: desktopHomeRaw
  })
  const reportDirRaw = typeof env.ZDD_REPORT_DIR === 'string' ? env.ZDD_REPORT_DIR.trim() : ''
  const reportDir = resolvedPathOrEmpty(reportDirRaw, home) || path.join(pluginData, 'reports')
  const quarantineRaw = typeof env.ZDD_QUARANTINE_DIR === 'string' ? env.ZDD_QUARANTINE_DIR.trim() : ''
  const quarantineDir = resolvedPathOrEmpty(quarantineRaw, home) || path.join(zcodeHome, '.disk-doctor', 'quarantine')
  const appDir = resolvedPathOrEmpty(env.ZDD_APP_DIR, home)

  return {
    topN,
    followSymlinks,
    allowOpenFolder,
    allowOpenFolderSensitive,
    allowCleanup,
    excludeGlobs,
    language,
    zcodeHome,
    desktopHome,
    appDir,
    reportDir,
    quarantineDir,
    pluginData,
    overrides,
    sources,
    warning: read.warning
  }
}

/**
 * Validate one panel override.
 * @param {string} key - the key.
 * @param {*} value - the requested value.
 * @returns {*} the normalized value.
 */
function normalizeOverride (key, value) {
  switch (key) {
    case 'topN': {
      const number = Number(value)
      if (!Number.isInteger(number) || number < 1 || number > 100) {
        throw new Error('topN 必须是 1..100 的整数')
      }
      return number
    }
    case 'followSymlinks':
    case 'allowOpenFolder':
    case 'allowOpenFolderSensitive':
    case 'allowCleanup':
      if (typeof value !== 'boolean') throw new Error(`${key} 必须是布尔值`)
      return value
    case 'excludeGlobs':
      return parseGlobs(value)
    case 'language': {
      if (value !== 'auto' && value !== 'zh-CN' && value !== 'en-US') {
        throw new Error('language 必须是 auto、zh-CN 或 en-US')
      }
      return value
    }
    default:
      throw new Error(`未知的设置项：${key}`)
  }
}

/**
 * Apply a panel override and persist it.
 * @param {object} patch - partial overrides.
 * @param {{ pluginData?: string, env?: NodeJS.ProcessEnv, home?: string }} [options] - overrides.
 * @returns {object} the new effective settings.
 */
export function applyOverrides (patch, options = {}) {
  const env = options.env ?? process.env
  const home = options.home ?? os.homedir()
  const pluginData = options.pluginData ?? pluginDataDir(env)
  if (patch === null || typeof patch !== 'object' || Array.isArray(patch)) {
    throw new Error('settings 必须是一个对象')
  }
  const existing = readOverrides(pluginData).overrides
  const next = { ...existing }
  for (const [key, value] of Object.entries(patch)) {
    if (!OVERRIDE_KEYS.includes(key)) throw new Error(`未知的设置项：${key}`)
    next[key] = normalizeOverride(key, value)
  }
  writeOverrides(pluginData, next)
  return loadSettings({ env, home, pluginData, overrides: next })
}

/**
 * Remove every panel override.
 * @param {{ pluginData?: string, env?: NodeJS.ProcessEnv, home?: string }} [options] - overrides.
 * @returns {object} the effective settings with built-in/env values.
 */
export function resetOverrides (options = {}) {
  const env = options.env ?? process.env
  const home = options.home ?? os.homedir()
  const pluginData = options.pluginData ?? pluginDataDir(env)
  clearOverrides(pluginData)
  return loadSettings({ env, home, pluginData, overrides: {} })
}

/** The subset of settings that affects scan output, for change detection. */
export function settingsFingerprint (settings) {
  return JSON.stringify({
    topN: settings.topN,
    followSymlinks: settings.followSymlinks,
    excludeGlobs: settings.excludeGlobs,
    zcodeHome: settings.zcodeHome,
    desktopHome: settings.desktopHome,
    appDir: settings.appDir
  })
}
