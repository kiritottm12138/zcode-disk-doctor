/**
 * What belongs to which report category on disk, and how a category is broken
 * into rankable items.
 *
 * Every category resolves to roots, and every root enumerates items. Items
 * partition their roots exactly once, so a category total is a plain sum of its
 * item totals. `other` is the data-area catch-all: it enumerates only the part
 * of the data folder that no other data category covers, which keeps
 * `sum(categories) === data area total`.
 *
 * Categories are grouped into three areas — data, application, system caches.
 * The areas are reported side by side and never added together: the application
 * and the caches are not part of the user's ZCode data, and a grand total would
 * imply they are.
 *
 * @module zcode-disk-doctor/targets
 */

import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'

import { isUnder, listTempSpill, pathKey, pathTraversesLink } from './locate.js'

/** True when `candidate` is an existing directory (following links). */
export function isDirectory (candidate) {
  try {
    return fs.statSync(candidate).isDirectory()
  } catch {
    return false
  }
}

/** True when `candidate` is an existing regular file. */
export function isFile (candidate) {
  try {
    return fs.statSync(candidate).isFile()
  } catch {
    return false
  }
}

async function readEntries (dir) {
  try {
    return await fsp.readdir(dir, { withFileTypes: true })
  } catch {
    return []
  }
}

function classify (entry) {
  return { isDir: entry.isDirectory(), isSymlink: entry.isSymbolicLink() }
}

/** Depth-1 entries of a root, one item each. */
export async function itemsByFirstLevel (root) {
  const entries = await readEntries(root.path)
  return entries.map((entry) => ({
    label: root.label ?? entry.name,
    path: path.join(root.path, entry.name),
    ...classify(entry)
  }))
}

/** One item per `sess_…` / `session_…` directory. */
async function enumerateSessionDirs (root) {
  const entries = await readEntries(root.path)
  return entries.map((entry) => ({
    label: entry.name,
    path: path.join(root.path, entry.name),
    ...classify(entry)
  }))
}

/**
 * Exec contains both per-session folders and shared helper folders. Expanding
 * `bash-startup/<session>` and `shell-snapshots/<file>` keeps one active session
 * from dragging every other session into the same cleanup item.
 */
async function enumerateExec (root) {
  const items = []
  const entries = await readEntries(root.path)
  for (const entry of entries) {
    const entryPath = path.join(root.path, entry.name)
    const kind = classify(entry)
    if (kind.isDir && (entry.name === 'bash-startup' || entry.name === 'shell-snapshots')) {
      const children = await readEntries(entryPath)
      if (children.length === 0) {
        items.push({ label: entry.name, path: entryPath, ...kind })
        continue
      }
      for (const child of children) {
        items.push({
          label: `${entry.name}/${child.name}`,
          path: path.join(entryPath, child.name),
          ...classify(child)
        })
      }
      continue
    }
    items.push({ label: entry.name, path: entryPath, ...kind })
  }
  return items
}

/**
 * Plugin cache is `cache/<marketplace>/<plugin>/<version>`. Grouping at the
 * plugin level makes "which plugin is big" answerable without listing every
 * version separately.
 */
async function enumeratePluginCache (root) {
  const items = []
  for (const marketplace of await readEntries(root.path)) {
    const marketplacePath = path.join(root.path, marketplace.name)
    const marketplaceKind = classify(marketplace)
    if (!marketplaceKind.isDir) {
      items.push({ label: marketplace.name, path: marketplacePath, ...marketplaceKind })
      continue
    }
    const plugins = await readEntries(marketplacePath)
    if (plugins.length === 0) {
      items.push({ label: marketplace.name, path: marketplacePath, ...marketplaceKind })
      continue
    }
    for (const plugin of plugins) {
      items.push({
        label: `${marketplace.name}/${plugin.name}`,
        path: path.join(marketplacePath, plugin.name),
        ...classify(plugin)
      })
    }
  }
  return items
}

/** Chromium scroll/profile folders that live beside the caches. */
const CHROMIUM_CACHE_NAMES = new Set([
  'Cache',
  'Code Cache',
  'GPUCache',
  'DawnGraphiteCache',
  'DawnWebGPUCache'
])

/** The profile side of the session folder: everything except the cache folders. */
async function enumerateChromiumProfile (root) {
  const items = []
  for (const entry of await readEntries(root.path)) {
    const entryPath = path.join(root.path, entry.name)
    const kind = classify(entry)
    // The cache categories own these folders. Skipping a *directory* by shape
    // keeps the totals disjoint; an unexpected file with the same name is still
    // accounted for here.
    if (kind.isDir && CHROMIUM_CACHE_NAMES.has(entry.name)) continue
    items.push({ label: entry.name, path: entryPath, ...kind })
  }
  return items
}

/**
 * Enumerate the uncovered part of the data folder.
 *
 * A plain first-level walk would double count nested covered roots (for example
 * `cli/log` inside `cli`). This descends only where a covered root lives below
 * the current entry, and emits the entry itself otherwise. The scanner's prune
 * set is a second line of defence.
 *
 * @param {Set<string>} covered - path keys of roots owned by other categories.
 * @returns {(root: { path: string }) => Promise<object[]>} an enumerator.
 */
function enumerateResidual (covered) {
  const coveredList = [...covered]
  const exact = (candidate) => covered.has(pathKey(candidate))
  const containsCovered = (candidate) => coveredList.some((root) => isUnder(root, candidate))

  return async function walkRoot (root) {
    const items = []
    const visit = async (dir, depth) => {
      for (const entry of await readEntries(dir)) {
        const entryPath = path.join(dir, entry.name)
        if (exact(entryPath)) continue
        const kind = classify(entry)
        if (kind.isDir && containsCovered(entryPath) && depth < 6) {
          await visit(entryPath, depth + 1)
          continue
        }
        items.push({ label: entry.name, path: entryPath, ...kind })
      }
    }
    await visit(root.path, 0)
    return items
  }
}

/** The three areas, in report order. */
export const AREA_DEFS = [
  {
    id: 'data',
    label: 'ZCode 数据',
    labelEn: 'ZCode data',
    note (env) {
      const parts = [`数据文件夹：${env.zcodeHome}`]
      if (typeof env.desktopHome === 'string' && env.desktopHome !== '' &&
          pathKey(env.desktopHome) !== pathKey(env.zcodeHome)) {
        parts.push(`桌面端数据：${env.desktopHome}`)
      }
      if (env.pluginsIsLink && env.pluginsRoot !== null) {
        parts.push(`插件目录外置：${env.pluginsLinkPath} → ${env.pluginsRoot}（已计入）`)
      }
      return parts.join('；')
    }
  },
  {
    id: 'app',
    label: 'ZCode 程序',
    labelEn: 'ZCode application',
    note (env) {
      if (typeof env.appRoot !== 'string' || env.appRoot === '') {
        return '没能自动找到程序安装位置，这部分没有统计进去（可在设置里填写）'
      }
      const how = env.appRootSource === 'config' ? '来自设置' : '自动找到'
      return `安装位置：${env.appRoot}（${how}）；只读展示，不参与清理`
    }
  },
  {
    id: 'cache',
    label: '系统缓存',
    labelEn: 'System caches',
    note (env) {
      const found = []
      if (typeof env.chromiumDir === 'string' && env.chromiumDir !== '') {
        found.push(`桌面端用户数据 ${env.chromiumDir}`)
      }
      if (typeof env.updaterDir === 'string' && env.updaterDir !== '') {
        found.push(`更新下载缓存 ${env.updaterDir}`)
      }
      return found.length === 0
        ? '这台机器上没有找到 ZCode 用到的系统缓存'
        : `这些位置在 ZCode 数据目录之外，与数据区不能相加：${found.join('、')}`
    }
  }
]

function wholeRoot (target, label) {
  return { path: target, label: label ?? path.basename(target), whole: true }
}

function fileRoot (target, label) {
  return { path: target, label: label ?? path.basename(target), whole: true }
}

/**
 * The data homes to scan.
 *
 * ZCode Desktop can keep its `v2/` state under `ZCODE_DATA_BASE_DIR/.zcode`
 * while the CLI keeps `cli/` under `~/.zcode`; both are ZCode data. When one
 * home contains the other, only the outer one is scanned so the same bytes are
 * never counted twice.
 *
 * @param {object} env - scan environment.
 * @returns {string[]} outermost data homes.
 */
export function dataHomes (env) {
  const list = []
  for (const candidate of [env.zcodeHome, env.desktopHome]) {
    if (typeof candidate !== 'string' || candidate === '') continue
    if (list.some((home) => pathKey(home) === pathKey(candidate))) continue
    if (list.some((home) => isUnder(candidate, home))) continue
    for (let index = list.length - 1; index >= 0; index--) {
      if (isUnder(list[index], candidate)) list.splice(index, 1)
    }
    list.push(candidate)
  }
  return list
}

function homeRoots (env, ...segments) {
  return dataHomes(env).map((home) => ({ path: path.join(home, ...segments), expand: true }))
}

function homeFiles (env, ...segments) {
  return dataHomes(env).map((home) => fileRoot(path.join(home, ...segments)))
}

/**
 * The category table. Order is report order; `other` is resolved last.
 *
 * `reclaim` is the "what happens if I delete this" sentence shown in the panel.
 * `recentMs` is the quiet period a cleanup requires; 0 means "never eligible".
 *
 * @type {ReadonlyArray<object>}
 */
export const CATEGORY_DEFS = [
  {
    id: 'sessions-db',
    area: 'data',
    label: '会话数据库',
    labelEn: 'Session database',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '会话、消息、工具调用和用量都在这里；删了会丢历史。',
      en: 'Conversations, messages, tool calls and usage live here; deleting it loses history.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'cli', 'db') })
  },
  {
    id: 'artifacts',
    area: 'data',
    label: '会话附件与工具输出',
    labelEn: 'Session artifacts',
    safety: 'care',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '旧会话里的工具输出和附件；删了对应会话可能缺内容。',
      en: 'Tool output and attachments from old sessions; deleting them can leave a conversation incomplete.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'cli', 'artifacts') }),
    enumerate: enumerateSessionDirs
  },
  {
    id: 'agent-outputs',
    area: 'data',
    label: '子代理输出',
    labelEn: 'Subagent output',
    safety: 'care',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '子代理的任务输出；任务历史可能需要它。',
      en: 'Outputs from subagents; task history may still reference them.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'cli', 'agents') }),
    enumerate: enumerateSessionDirs
  },
  {
    id: 'model-io',
    area: 'data',
    label: '模型 I/O 日志',
    labelEn: 'Model I/O logs',
    safety: 'care',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '模型请求与回复的调试日志，可能含对话内容；按需清理。',
      en: 'Debug logs of model requests and replies; they may contain conversation content.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'cli', 'rollout') })
  },
  {
    id: 'logs',
    area: 'data',
    label: '诊断日志',
    labelEn: 'Diagnostic logs',
    safety: 'safe',
    regenerable: true,
    recentMs: 60 * 60 * 1000,
    reclaim: {
      zh: '运行日志与崩溃转储；删了只影响排查问题，ZCode 会继续写新日志。',
      en: 'Runtime logs and crash dumps; deleting them only affects troubleshooting, and new logs are written.'
    },
    resolve: (env) => ({
      roots: [
        ...homeRoots(env, 'cli', 'log'),
        ...homeRoots(env, 'v2', 'logs'),
        ...homeRoots(env, 'v2', 'crash'),
        ...homeRoots(env, 'feedback', 'logs')
      ]
    })
  },
  {
    id: 'exec-temp',
    area: 'data',
    label: '命令输出与 Shell 快照',
    labelEn: 'Command output and shell snapshots',
    safety: 'safe',
    regenerable: true,
    recentMs: 24 * 60 * 60 * 1000,
    reclaim: {
      zh: '命令的 stdout/stderr 与 shell 启动快照；删了不影响会话。',
      en: 'Command stdout/stderr and shell startup snapshots; deleting them does not affect conversations.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'cli', 'exec') }),
    enumerate: enumerateExec
  },
  {
    id: 'image-cache',
    area: 'data',
    label: '会话图片缓存',
    labelEn: 'Session image cache',
    safety: 'safe',
    regenerable: true,
    recentMs: 60 * 60 * 1000,
    reclaim: {
      zh: '会话里用过的图片缓存；删了下次需要时会重新生成。',
      en: 'Images cached for conversations; they are regenerated when needed.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'cli', 'image-cache') }),
    enumerate: enumerateSessionDirs
  },
  {
    id: 'plugin-cache',
    area: 'data',
    label: '已安装插件缓存',
    labelEn: 'Installed plugin cache',
    safety: 'care',
    regenerable: true,
    recentMs: 0,
    reclaim: {
      zh: '已安装插件的运行副本；请用插件管理卸载，不要手删。',
      en: 'Working copies of installed plugins; uninstall through Plugin Management rather than deleting by hand.'
    },
    resolve: (env) => ({
      roots: typeof env.pluginsRoot === 'string' && env.pluginsRoot !== ''
        ? [{ path: path.join(env.pluginsRoot, 'cache'), expand: true }]
        : []
    }),
    enumerate: enumeratePluginCache
  },
  {
    id: 'plugin-marketplaces',
    area: 'data',
    label: '插件市场缓存',
    labelEn: 'Marketplace cache',
    safety: 'care',
    regenerable: true,
    recentMs: 0,
    reclaim: {
      zh: '市场仓库的克隆；删了要重新添加市场或刷新。',
      en: 'Cloned marketplace repositories; deleting them requires re-adding or refreshing the marketplace.'
    },
    resolve: (env) => ({
      roots: typeof env.pluginsRoot === 'string' && env.pluginsRoot !== ''
        ? [{ path: path.join(env.pluginsRoot, 'marketplaces'), expand: true }]
        : []
    })
  },
  {
    id: 'plugin-data',
    area: 'data',
    label: '插件私有数据',
    labelEn: 'Plugin private data',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '插件自己的设置、壁纸、缓存等；删了会丢配置。',
      en: 'Plugin settings, wallpapers and private caches; deleting them loses configuration.'
    },
    resolve: (env) => ({
      roots: typeof env.pluginsRoot === 'string' && env.pluginsRoot !== ''
        ? [{ path: path.join(env.pluginsRoot, 'data'), expand: true }]
        : []
    })
  },
  {
    id: 'plugin-old-cache',
    area: 'data',
    label: '旧插件缓存残留',
    labelEn: 'Old plugin cache leftovers',
    safety: 'safe',
    regenerable: true,
    recentMs: 24 * 60 * 60 * 1000,
    reclaim: {
      zh: '上一版插件目录的缓存与市场克隆；通常是升级后的残留。',
      en: 'Cache and marketplace clones from a previous plugin directory; usually leftovers after an upgrade.'
    },
    resolve: (env) => ({
      roots: [
        ...homeRoots(env, 'cli', 'plugins.old', 'cache'),
        ...homeRoots(env, 'cli', 'plugins.old', 'marketplaces')
      ]
    })
  },
  {
    id: 'plugin-old-data',
    area: 'data',
    label: '旧插件私有数据',
    labelEn: 'Old plugin private data',
    safety: 'care',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '上一版插件目录里的插件设置；确认不再回退后再处理。',
      en: 'Plugin settings from a previous plugin directory; only remove after deciding not to roll back.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'cli', 'plugins.old', 'data') })
  },
  {
    id: 'settings',
    area: 'data',
    label: '设置、凭据与任务索引',
    labelEn: 'Settings, credentials and task index',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: 'ZCode 的配置、登录凭据、任务索引与证书；删了会丢设置或登录态。',
      en: 'ZCode configuration, credentials, task index and certificates; deleting them loses settings or sign-in state.'
    },
    resolve: (env) => {
      const stateNames = [
        'setting.json',
        'credentials.json',
        'provider_config.json',
        'onboarding-record.json',
        'agents-state.json',
        'telemetry-state.json',
        'bot-config.v3.json',
        'bot-state.v3.json',
        'tasks-index.sqlite',
        'tasks-index.sqlite-wal',
        'tasks-index.sqlite-shm'
      ]
      const roots = [
        ...homeFiles(env, 'cli', 'config.json'),
        ...stateNames.flatMap((name) => homeFiles(env, 'v2', name)),
        ...homeRoots(env, 'v2', 'certs').map((root) => ({ ...root, whole: true })),
        ...homeRoots(env, 'v2', 'runtime').map((root) => ({ ...root, whole: true })),
        ...homeRoots(env, 'v2', 'cache').map((root) => ({ ...root, whole: true })),
        ...homeRoots(env, 'v2', 'gen-ui-state').map((root) => ({ ...root, whole: true }))
      ]
      return { roots }
    }
  },
  {
    id: 'backup',
    area: 'data',
    label: '备份',
    labelEn: 'Backups',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: 'ZCode 自己的备份；删了会失去回滚点。',
      en: 'ZCode backups; deleting them removes a rollback point.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'backup') })
  },
  {
    id: 'workspaces',
    area: 'data',
    label: '工作区数据',
    labelEn: 'Workspace data',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: 'ZCode 工作区与插件工作区；属于你的内容。',
      en: 'ZCode workspace and plugin-workspace data; this is your content.'
    },
    resolve: (env) => ({
      roots: [
        ...homeRoots(env, 'workspace'),
        ...homeRoots(env, 'plugin-workspace')
      ]
    })
  },
  {
    id: 'visualizations',
    area: 'data',
    label: '会话可视化',
    labelEn: 'Session visualizations',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '会话里生成的 HTML 可视化；属于你的内容。',
      en: 'HTML visualizations generated for conversations; this is your content.'
    },
    resolve: (env) => ({ roots: homeRoots(env, 'v2', 'visualizations') })
  },
  {
    id: 'temp-spill',
    area: 'data',
    label: '会话临时目录',
    labelEn: 'Session temp directories',
    safety: 'safe',
    regenerable: true,
    recentMs: 24 * 60 * 60 * 1000,
    reclaim: {
      zh: 'ZCode 在系统临时目录里创建的 zcode-* 工作目录；删了不影响会话。',
      en: 'zcode-* working directories under the OS temp folder; deleting them does not affect conversations.'
    },
    resolve: (env) => ({ roots: listTempSpill(env.tempDir).map((dir) => wholeRoot(dir)) }),
    owns: (env, candidate) =>
      pathKey(path.dirname(candidate)) === pathKey(env.tempDir) &&
      path.basename(candidate).toLowerCase().startsWith('zcode-')
  },
  {
    id: 'app-install',
    area: 'app',
    label: '程序安装目录',
    labelEn: 'Application install folder',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: 'ZCode 程序本体；由卸载程序管理，不要手动删。',
      en: 'The ZCode application itself; managed by the uninstaller, not by hand.'
    },
    resolve: (env) => ({
      roots: typeof env.appRoot === 'string' && env.appRoot !== ''
        ? [{ path: env.appRoot, expand: true }]
        : []
    })
  },
  {
    id: 'global-cli',
    area: 'app',
    label: '全局 ZCode CLI',
    labelEn: 'Global ZCode CLI',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: 'npm/pnpm 全局安装的第二份 ZCode；由包管理器管理。',
      en: 'A second ZCode installation in npm/pnpm global packages; managed by the package manager.'
    },
    resolve: (env) => ({
      roots: typeof env.globalCli === 'string' && env.globalCli !== ''
        ? [{ path: env.globalCli, expand: true }]
        : []
    })
  },
  {
    id: 'chromium-cache',
    area: 'cache',
    label: '桌面端浏览器缓存',
    labelEn: 'Desktop browser cache',
    safety: 'care',
    regenerable: true,
    recentMs: 0,
    reclaim: {
      zh: 'ZCode 窗口的 Chromium 缓存；运行期间不宜搬走，关闭 ZCode 后可由系统清理。',
      en: 'Chromium cache for the ZCode window; do not move it while ZCode is running.'
    },
    resolve: (env) => {
      const base = env.chromiumSessionDir
      if (typeof base !== 'string' || base === '') return { roots: [] }
      return {
        roots: [...CHROMIUM_CACHE_NAMES].map((name) => ({ path: path.join(base, name), expand: true }))
      }
    }
  },
  {
    id: 'chromium-profile',
    area: 'cache',
    label: '桌面端用户数据',
    labelEn: 'Desktop user data',
    safety: 'keep',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '登录态、本地存储、会话分区；删了要重新登录或丢界面状态。',
      en: 'Sign-in state, local storage and session partitions; deleting them loses sign-in or UI state.'
    },
    resolve: (env) => {
      if (typeof env.chromiumSessionDir !== 'string' || env.chromiumSessionDir === '') return { roots: [] }
      const roots = [{ path: env.chromiumSessionDir, expand: true }]
      if (typeof env.chromiumDir === 'string' && env.chromiumDir !== '') {
        try {
          for (const entry of fs.readdirSync(env.chromiumDir, { withFileTypes: true })) {
            if (entry.isFile() && entry.name.toLowerCase().endsWith('.bdic')) {
              roots.push(fileRoot(path.join(env.chromiumDir, entry.name)))
            }
          }
        } catch {
          /* absent */
        }
      }
      return { roots }
    },
    enumerate: enumerateChromiumProfile
  },
  {
    id: 'updater-cache',
    area: 'cache',
    label: '更新下载缓存',
    labelEn: 'Updater downloads',
    safety: 'safe',
    regenerable: true,
    recentMs: 24 * 60 * 60 * 1000,
    reclaim: {
      zh: '下载好的更新包；清理后需要时会重新下载，不影响已安装版本。',
      en: 'Downloaded update packages; they are downloaded again when needed and do not affect the installed version.'
    },
    resolve: (env) => ({
      roots: typeof env.updaterDir === 'string' && env.updaterDir !== ''
        ? [{ path: env.updaterDir, expand: true }]
        : []
    })
  },
  {
    id: 'quarantine',
    area: 'data',
    label: '隔离区（仍占用磁盘）',
    labelEn: 'Quarantine (still on disk)',
    safety: 'care',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '清理只是把文件改名到这里，并没有释放磁盘空间；确认不再需要后请手动清空隔离区。',
      en: 'Cleanup only renamed files here; it did not free space. Empty the quarantine manually when you are sure.'
    },
    resolve: (env) => ({
      roots: typeof env.quarantineDir === 'string' && env.quarantineDir !== ''
        ? [{ path: env.quarantineDir, expand: true }]
        : []
    }),
    enumerate: itemsByFirstLevel
  },
  {
    id: 'other',
    area: 'data',
    label: '其他',
    labelEn: 'Other',
    safety: 'care',
    regenerable: false,
    recentMs: 0,
    reclaim: {
      zh: '数据目录里没有归入其他类别的部分；先看清是什么再处理。',
      en: 'Parts of the data folder not claimed by another category; inspect before touching.'
    },
    resolve: (env) => ({ roots: dataHomes(env).map((home) => ({ path: home, expand: true, isCatchAll: true })) }),
    enumerate: null // filled with the residual enumerator by resolveTargets
  }
]

/** The 🟢 categories a cleanup may own. */
export function cleanableCategories () {
  return CATEGORY_DEFS
    .filter((def) => def.safety === 'safe')
    .map((def) => ({ id: def.id, label: def.label, labelEn: def.labelEn }))
}

/**
 * Resolve the category table against a concrete environment.
 *
 * Categories whose roots do not exist come back with `roots: []` plus a
 * warning, so the report can say what it looked for instead of silently
 * omitting it.
 *
 * @param {object} env - resolved scan environment.
 * @param {Set<string>|null} [only] - selected category ids.
 * @returns {{ categories: object[], warnings: string[], covered: Set<string> }}
 */
export function resolveTargets (env, only = null) {
  const categories = []
  const warnings = []
  const covered = new Set()
  const isSelected = (id) => only === null || only.has(id)
  // The plugin root may be a junction. Its bytes are counted through the real
  // plugin-cache/marketplace/data roots; the link itself must never be followed
  // a second time by the data-area catch-all.
  if (env.pluginsIsLink === true && typeof env.pluginsLinkPath === 'string') {
    covered.add(pathKey(env.pluginsLinkPath))
  }
  // The quarantine lives inside the data home by default. It is reported by its
  // own category, never as part of "other".
  if (typeof env.quarantineDir === 'string' && env.quarantineDir !== '') {
    covered.add(pathKey(env.quarantineDir))
  }

  for (const def of CATEGORY_DEFS) {
    if (def.id === 'other') continue
    const resolved = def.resolve(env)
    const all = resolved.roots ?? []
    const roots = all.filter((root) => isDirectory(root.path) || isFile(root.path))
    for (const root of roots) {
      if (def.area === 'data' && !root.isCatchAll) covered.add(pathKey(root.path))
    }
    if (!isSelected(def.id)) continue
    if (resolved.warning !== undefined) warnings.push(resolved.warning)
    // A split layout legitimately has a category in only one of the two data
    // homes. Only a category with no roots at all is worth telling the reader
    // about; per-home "not built" notices would bury the real warnings.
    if (roots.length === 0 && all.length > 0) {
      warnings.push(`${def.label}：没有找到可统计的路径`)
    }
    categories.push({
      ...def,
      enumerate: def.enumerate ?? itemsByFirstLevel,
      roots
    })
  }

  if (isSelected('other')) {
    const otherDef = CATEGORY_DEFS.find((def) => def.id === 'other')
    const roots = dataHomes(env)
      .filter((home) => isDirectory(home))
      .map((home) => ({ path: home, expand: true, isCatchAll: true }))
    categories.push({
      ...otherDef,
      enumerate: enumerateResidual(covered),
      roots
    })
  }

  return { categories, warnings, covered }
}

/**
 * True when a cleanup may own `candidate`.
 *
 * The rule is independent of whether the path exists right now: an undo has to
 * recognise a folder it moved away, and a whole-folder item is exactly the case
 * where the root is gone because it *is* the item.
 *
 * @param {object} env - scan environment.
 * @param {string} candidate - absolute path.
 * @returns {boolean} whether a cleanup may move it.
 */
export function ownsCleanupPath (env, candidate) {
  if (typeof candidate !== 'string' || candidate === '') return false
  const resolved = path.resolve(candidate)
  // A link anywhere in the candidate path (the item itself, a parent, or a
  // cleanable root) would make a rename act on bytes outside the lexical root.
  if (pathTraversesLink(resolved)) return false
  for (const def of CATEGORY_DEFS) {
    if (def.safety !== 'safe') continue
    if (def.owns !== undefined) {
      if (def.owns(env, resolved)) return true
      continue
    }
    for (const root of def.resolve(env).roots ?? []) {
      if (pathTraversesLink(root.path)) continue
      if (isUnder(resolved, root.path)) return true
    }
  }
  return false
}

/**
 * Every path the panel may reveal, tagged with the safety level that gates it.
 * @param {object} env - scan environment.
 * @returns {Array<{path: string, safety: string, categoryId: string, area: string, whole: boolean}>}
 */
export function openRoots (env) {
  const roots = []
  for (const def of CATEGORY_DEFS) {
    for (const root of def.resolve(env).roots ?? []) {
      if (!isDirectory(root.path) && !isFile(root.path)) continue
      roots.push({
        path: root.path,
        safety: def.safety,
        categoryId: def.id,
        area: def.area,
        whole: root.whole === true
      })
    }
  }
  return roots
}

/** Look up one definition by id. */
export function categoryById (id) {
  return CATEGORY_DEFS.find((def) => def.id === id) ?? null
}
