/**
 * MCP tools and the panel resource.
 *
 * Two audiences share one server:
 *
 * - model-visible tools (`disk_report`, `open_disk_panel`) can read, but can
 *   never move a file or open a folder;
 * - app-only tools (`get_report`, `plan_cleanup`, `perform_cleanup`, …) are
 *   reachable only from the panel, through the host's MCP Apps bridge.
 *
 * That split is deliberate: the agent can report, but only the user's clicks in
 * the panel can authorise a move.
 *
 * @module zcode-disk-doctor/tools
 */

import { spawn } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'

import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js'
import { z } from 'zod'

import { listQuarantine, performCleanup, planCleanup, undoCleanup } from './cleanup.js'
import { buildEnvironment, isUnder, pathTraversesLink } from './locate.js'
import { redactDeep, renderMarkdownFile, renderSummary, timestampSlug, toJsonReport } from './report.js'
import { scan } from './scan.js'
import { applyOverrides, loadSettings, resetOverrides } from './settings.js'
import { CATEGORY_DEFS, openRoots } from './targets.js'

export const SERVER_NAME = 'disk-doctor'
export const SERVER_VERSION = '0.1.0'
export const PANEL_URI = 'ui://disk-doctor/panel.html'
export const SURFACE_ID = 'disk-doctor'
export const HTML_MIME = 'text/html;profile=mcp-app'

const CATEGORY_IDS = CATEGORY_DEFS.map((def) => def.id)
const SAFE_IDS = new Set(CATEGORY_DEFS.filter((def) => def.safety === 'safe').map((def) => def.id))

const MODEL_META = { ui: { visibility: ['model'] } }
const APP_META = { ui: { visibility: ['app'] } }
const PANEL_META = {
  ui: {
    resourceUri: PANEL_URI,
    surface: SURFACE_ID,
    visibility: ['model', 'app']
  }
}

function textResult (text, structured) {
  return {
    content: [{ type: 'text', text }],
    ...(structured === undefined ? {} : { structuredContent: structured })
  }
}

function errorResult (message, code = 'error') {
  return {
    isError: true,
    content: [{ type: 'text', text: `[${code}] ${message}` }],
    structuredContent: { error: { code, message } }
  }
}

function languageOf (settings) {
  return settings.language === 'en-US' ? 'en-US' : 'zh-CN'
}

function resolveTopN (requested, fallback) {
  if (requested === undefined || requested === null) return fallback
  const value = Number(requested)
  if (!Number.isInteger(value) || value < 1 || value > 100) {
    throw new Error(`topN 必须是 1..100 的整数，收到 ${JSON.stringify(requested)}`)
  }
  return value
}

function resolveCategories (requested) {
  if (requested === undefined || requested === null || requested.length === 0) return undefined
  const unknown = requested.filter((id) => !CATEGORY_IDS.includes(id))
  if (unknown.length > 0) {
    throw new Error(`未知类别：${unknown.join(', ')}。可选：${CATEGORY_IDS.join(', ')}`)
  }
  return [...new Set(requested)]
}

function scanOptions (env, settings, topN, only, limits) {
  return {
    zcodeHome: env.zcodeHome,
    desktopHome: env.desktopHome,
    tempDir: env.tempDir,
    appRoot: env.appRoot,
    appRootSource: env.appRootSource,
    chromiumDir: env.chromiumDir,
    chromiumSessionDir: env.chromiumSessionDir,
    updaterDir: env.updaterDir,
    pluginsRoot: env.pluginsRoot,
    pluginsLinkPath: env.pluginsLinkPath,
    pluginsIsLink: env.pluginsIsLink,
    globalCli: env.globalCli,
    quarantineDir: settings.quarantineDir,
    topN,
    only,
    excludeGlobs: settings.excludeGlobs,
    followSymlinks: settings.followSymlinks,
    ...(limits === undefined ? {} : { limits })
  }
}

async function scanAll (settings, { topN, only, limits } = {}) {
  const env = buildEnvironment(settings)
  const report = await scan(scanOptions(env, settings, topN ?? settings.topN, only, limits))
  return { env, report }
}

function compactReport (report, settings, env) {
  return {
    generatedAt: report.generatedAt,
    durationMs: report.durationMs,
    truncated: report.truncated,
    totals: report.totals,
    areas: report.areas,
    categories: report.categories.map((category) => ({
      id: category.id,
      area: category.area,
      label: category.label,
      labelEn: category.labelEn,
      bytes: category.bytes,
      files: category.files,
      dirs: category.dirs,
      safety: category.safety,
      regenerable: category.regenerable,
      itemCount: category.itemCount,
      linkedItems: category.linkedItems,
      overlapBytes: category.overlapBytes ?? 0,
      roots: category.roots,
      reclaim: category.reclaim
    })),
    linkInstalls: report.linkInstalls,
    warnings: report.warnings,
    capabilities: {
      openFolder: settings.allowOpenFolder === true,
      openFolderSensitive: settings.allowOpenFolderSensitive === true,
      cleanup: settings.allowCleanup === true
    },
    paths: {
      zcodeHome: env.zcodeHome,
      desktopHome: env.desktopHome,
      reportDir: settings.reportDir,
      quarantineDir: settings.quarantineDir,
      pluginsRoot: env.pluginsRoot,
      pluginsLinkPath: env.pluginsLinkPath,
      chromiumDir: env.chromiumDir,
      updaterDir: env.updaterDir,
      appRoot: env.appRoot
    },
    language: languageOf(settings)
  }
}

function compactPlan (plan, offset, limit) {
  const items = plan.items.slice(offset, offset + limit).map((item) => ({
    categoryId: item.categoryId,
    categoryLabel: item.categoryLabel,
    path: item.path,
    bytes: item.bytes,
    files: item.files,
    mtimeMs: item.mtimeMs,
    ...(item.note === undefined ? {} : { note: item.note })
  }))
  const skipped = plan.skipped.slice(0, 100)
  const excluded = (plan.excluded ?? []).slice(0, 100)
  return {
    schema: plan.schema,
    generatedAt: plan.generatedAt,
    dryRun: true,
    destination: plan.destination,
    totalBytes: plan.totalBytes,
    totalFiles: plan.totalFiles,
    itemCount: plan.itemCount,
    items,
    offset,
    limit,
    next: offset + items.length < plan.itemCount ? offset + items.length : null,
    skipped,
    skippedCount: plan.skipped.length,
    skippedBytes: plan.skippedBytes,
    excluded,
    excludedCount: plan.excludedCount ?? excluded.length,
    excludedBytes: plan.excludedBytes ?? 0,
    truncated: plan.truncated,
    eligible: plan.eligible,
    refused: plan.refused,
    categories: plan.categories,
    warnings: plan.warnings
  }
}

function compactCleanupResult (record) {
  const failures = (record.failures ?? []).slice(0, 20)
  return {
    ok: record.status === 'moved' || record.status === 'nothing-to-move',
    id: record.id,
    status: record.status,
    bytes: record.bytes,
    files: record.files,
    itemCount: record.items?.length ?? 0,
    failureCount: record.failures?.length ?? 0,
    failures,
    skippedRecentCount: record.skippedRecent?.length ?? 0,
    manifestPath: record.manifestPath ?? null
  }
}

function systemOpenCommand () {
  if (process.platform === 'win32') {
    const root = process.env.SystemRoot || process.env.windir || 'C:\\Windows'
    return path.join(root, 'explorer.exe')
  }
  if (process.platform === 'darwin') return '/usr/bin/open'
  for (const candidate of ['/usr/bin/xdg-open', '/usr/local/bin/xdg-open', '/bin/xdg-open']) {
    try {
      if (fs.statSync(candidate).isFile()) return candidate
    } catch {
      /* keep looking */
    }
  }
  return null
}

function openTarget (target) {
  const command = systemOpenCommand()
  if (command === null) throw new Error('open-command-not-found')
  // Absolute command and a system cwd: a bare `explorer.exe` would let a
  // planted binary in the workspace (the MCP server's cwd) run instead.
  const child = spawn(command, [target], {
    detached: true,
    stdio: 'ignore',
    cwd: path.dirname(command),
    windowsHide: true
  })
  child.unref()
}

/**
 * Resolve a user-requested reveal.
 * @param {string} requested - the path.
 * @param {object} settings - effective settings.
 * @param {object} env - scan environment.
 * @returns {{ok: true, target: string, safety: string}|{ok: false, reason: string}}
 */
function resolveOpenTarget (requested, settings, env) {
  if (settings.allowOpenFolder !== true) return { ok: false, reason: 'disabled' }
  if (typeof requested !== 'string' || requested.trim() === '') return { ok: false, reason: 'no-path' }
  let target
  try {
    target = path.resolve(requested)
  } catch {
    return { ok: false, reason: 'bad-path' }
  }
  if (pathTraversesLink(target)) return { ok: false, reason: 'linked' }
  let stat
  try {
    stat = fs.statSync(target)
  } catch {
    return { ok: false, reason: 'missing' }
  }
  const roots = openRoots(env)
  const covering = roots
    .filter((root) => isUnder(target, root.path))
    .sort((a, b) => b.path.length - a.path.length)[0]
  if (covering === undefined) return { ok: false, reason: 'outside-root' }
  if (covering.safety !== 'safe' && settings.allowOpenFolderSensitive !== true) {
    return { ok: false, reason: 'sensitive' }
  }
  return {
    ok: true,
    target: stat.isDirectory() ? target : path.dirname(target),
    safety: covering.safety
  }
}

function readPanelHtml (panelPath) {
  try {
    return fs.readFileSync(panelPath, 'utf8')
  } catch {
    return '<!doctype html><meta charset="utf-8"><title>Disk Doctor</title>' +
      '<body style="font:14px system-ui;padding:24px">Panel bundle is missing. Run <code>npm run build</code>.</body>'
  }
}

/**
 * Create the MCP server and register every tool/resource.
 *
 * @param {object} [options] - options.
 * @param {string} [options.panelPath] - the built panel HTML.
 * @returns {McpServer} the server, not yet connected.
 */
export function createServer (options = {}) {
  const panelPath = options.panelPath ?? new URL('./ui/panel.html', import.meta.url)
  const server = new McpServer({ name: SERVER_NAME, version: SERVER_VERSION })

  server.registerResource(
    'panel',
    PANEL_URI,
    { mimeType: HTML_MIME, description: 'ZCode Disk Doctor panel' },
    async () => ({
      contents: [{
        uri: PANEL_URI,
        mimeType: HTML_MIME,
        text: readPanelHtml(panelPath)
      }]
    })
  )

  server.registerTool('disk_report', {
    title: 'ZCode disk report',
    description:
      'Report how much disk space ZCode occupies on this machine. Three areas are reported ' +
      'side by side and never summed: the ZCode data folder, the ZCode application install, and the system ' +
      'caches ZCode uses. Each area is broken down by category, the largest items are listed, and with ' +
      'write=true Markdown + JSON reports are also written. It never deletes anything; without write=true ' +
      'it only reads sizes and timestamps. 中文：统计 ZCode 的磁盘占用，分「数据 / 程序 / 系统缓存」三个区' +
      '各自独立统计（不相加），附 Top N 明细；仅当 write=true 时额外写报告文件，不删除任何文件。',
    inputSchema: {
      scope: z.enum(['summary', 'full']).optional().describe('summary 只看分类汇总（默认）；full 附带 Top N 明细。'),
      topN: z.number().int().min(1).max(100).optional().describe('每个类别列出的条目数，1..100。'),
      write: z.boolean().optional().describe('是否写入 Markdown/JSON 报告，默认 false；true 时会写两个报告文件。'),
      categories: z.array(z.enum(CATEGORY_IDS)).optional().describe('只统计这些类别，默认全部。')
    },
    annotations: { readOnlyHint: false, openWorldHint: false },
    _meta: MODEL_META
  }, async (args) => {
    try {
      const settings = loadSettings()
      const topN = resolveTopN(args.topN, settings.topN)
      const only = resolveCategories(args.categories)
      const { report } = await scanAll(settings, { topN, only })
      const generatedAt = new Date()
      let reportPath
      let jsonPath

      if (args.write === true) {
        try {
          fs.mkdirSync(settings.reportDir, { recursive: true })
          const stem = `zcode-disk-report-${timestampSlug(generatedAt)}`
          reportPath = path.join(settings.reportDir, `${stem}.md`)
          jsonPath = path.join(settings.reportDir, `${stem}.json`)
          fs.writeFileSync(reportPath, renderMarkdownFile(report, {
            zcodeHome: settings.zcodeHome,
            desktopHome: settings.desktopHome,
            generatedAt,
            language: languageOf(settings)
          }), 'utf8')
          fs.writeFileSync(jsonPath, `${JSON.stringify(toJsonReport(report, {
            zcodeHome: settings.zcodeHome,
            desktopHome: settings.desktopHome,
            generatedAt,
            redact: true,
            capabilities: {
              openFolder: settings.allowOpenFolder,
              openFolderSensitive: settings.allowOpenFolderSensitive,
              cleanup: settings.allowCleanup
            }
          }), null, 2)}\n`, 'utf8')
        } catch (error) {
          report.warnings.push(`报告写入失败：${String(error?.message ?? error)}`)
          reportPath = undefined
          jsonPath = undefined
        }
      }

      const markdown = renderSummary(report, {
        detail: args.scope === 'full',
        reportPath,
        language: languageOf(settings)
      })

      return textResult(markdown, redactDeep({
        ...(reportPath === undefined ? {} : { reportPath, jsonPath }),
        totals: report.totals,
        areas: report.areas.map((area) => ({
          id: area.id,
          label: area.label,
          bytes: area.totals.bytes,
          files: area.totals.files,
          dirs: area.totals.dirs,
          roots: area.roots,
          notes: area.notes,
          categories: area.categories
        })),
        linkInstalls: report.linkInstalls,
        regenerableBytes: report.regenerableBytes,
        contentBytes: report.contentBytes,
        durationMs: report.durationMs,
        truncated: report.truncated,
        warnings: report.warnings,
        categories: report.categories.map((category) => ({
          id: category.id,
          area: category.area,
          label: category.label,
          bytes: category.bytes,
          files: category.files,
          safety: category.safety,
          regenerable: category.regenerable,
          itemCount: category.itemCount,
          roots: category.roots
        }))
      }))
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'disk-report-failed')
    }
  })

  server.registerTool('open_disk_panel', {
    title: 'Open the Disk Doctor panel',
    description:
      'Open the ZCode Disk Doctor side panel. Use when the user wants to see where disk space went, ' +
      'or wants to review/clean safe-to-remove items. The panel itself performs any move after an explicit ' +
      'second click. 中文：打开「空间体检」侧栏面板；清理只能在面板里由用户确认后执行。',
    inputSchema: {},
    annotations: { readOnlyHint: true, openWorldHint: false },
    _meta: PANEL_META
  }, async () => {
    try {
      const settings = loadSettings()
      return textResult(
        languageOf(settings) === 'en-US'
          ? 'The Disk Doctor panel is open. If it is not visible, choose "Disk Doctor" from the session side panel.'
          : '空间体检面板已打开。如果没有出现，请在会话侧栏选择「空间体检」。'
      )
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'open-panel-failed')
    }
  })

  server.registerTool('get_report', {
    title: 'Panel: report summary',
    description: 'Return the panel summary with real paths.',
    inputSchema: {},
    annotations: { readOnlyHint: true, openWorldHint: false },
    _meta: APP_META
  }, async () => {
    try {
      const settings = loadSettings()
      const { env, report } = await scanAll(settings, { topN: 3 })
      return textResult('ok', compactReport(report, settings, env))
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'report-failed')
    }
  })

  server.registerTool('get_category', {
    title: 'Panel: category items',
    description: 'Return a page of items for one category.',
    inputSchema: {
      categoryId: z.enum(CATEGORY_IDS),
      offset: z.number().int().min(0).max(500).optional(),
      limit: z.number().int().min(1).max(100).optional()
    },
    annotations: { readOnlyHint: true, openWorldHint: false },
    _meta: APP_META
  }, async (args) => {
    try {
      const settings = loadSettings()
      const offset = args.offset ?? 0
      const limit = args.limit ?? 25
      if (offset + limit > 500) return errorResult('offset + limit 不能超过 500', 'range')
      const { report } = await scanAll(settings, { topN: offset + limit, only: [args.categoryId] })
      const category = report.categories.find((item) => item.id === args.categoryId)
      if (category === undefined) return errorResult(`未知类别：${args.categoryId}`, 'unknown-category')
      const items = category.topItems.slice(offset, offset + limit)
      return textResult('ok', {
        category: {
          id: category.id,
          area: category.area,
          label: category.label,
          labelEn: category.labelEn,
          bytes: category.bytes,
          files: category.files,
          itemCount: category.itemCount,
          safety: category.safety,
          regenerable: category.regenerable,
          roots: category.roots,
          reclaim: category.reclaim,
          truncated: category.truncated
        },
        items,
        offset,
        limit,
        next: offset + items.length < category.itemCount ? offset + items.length : null
      })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'category-failed')
    }
  })

  server.registerTool('get_settings', {
    title: 'Panel: settings',
    description: 'Return effective settings, their sources, and detected paths.',
    inputSchema: {},
    annotations: { readOnlyHint: true, openWorldHint: false },
    _meta: APP_META
  }, async () => {
    try {
      const settings = loadSettings()
      const env = buildEnvironment(settings)
      return textResult('ok', {
        values: {
          topN: settings.topN,
          followSymlinks: settings.followSymlinks,
          allowOpenFolder: settings.allowOpenFolder,
          allowOpenFolderSensitive: settings.allowOpenFolderSensitive,
          allowCleanup: settings.allowCleanup,
          excludeGlobs: settings.excludeGlobs,
          language: settings.language
        },
        sources: settings.sources,
        paths: {
          zcodeHome: env.zcodeHome,
          desktopHome: env.desktopHome,
          appRoot: env.appRoot,
          reportDir: settings.reportDir,
          quarantineDir: settings.quarantineDir,
          pluginsRoot: env.pluginsRoot,
          pluginsLinkPath: env.pluginsLinkPath,
          chromiumDir: env.chromiumDir,
          updaterDir: env.updaterDir
        },
        warning: settings.warning
      })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'settings-failed')
    }
  })

  server.registerTool('set_settings', {
    title: 'Panel: update settings',
    description: 'Update behavioural settings (never paths).',
    inputSchema: {
      topN: z.number().int().min(1).max(100).optional(),
      followSymlinks: z.boolean().optional(),
      allowOpenFolder: z.boolean().optional(),
      allowOpenFolderSensitive: z.boolean().optional(),
      allowCleanup: z.boolean().optional(),
      excludeGlobs: z.array(z.string()).optional(),
      language: z.enum(['auto', 'zh-CN', 'en-US']).optional()
    },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    _meta: APP_META
  }, async (args) => {
    try {
      const patch = {}
      for (const [key, value] of Object.entries(args)) if (value !== undefined) patch[key] = value
      const settings = applyOverrides(patch)
      return textResult('ok', {
        values: {
          topN: settings.topN,
          followSymlinks: settings.followSymlinks,
          allowOpenFolder: settings.allowOpenFolder,
          allowOpenFolderSensitive: settings.allowOpenFolderSensitive,
          allowCleanup: settings.allowCleanup,
          excludeGlobs: settings.excludeGlobs,
          language: settings.language
        },
        sources: settings.sources
      })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'settings-failed')
    }
  })

  server.registerTool('reset_settings', {
    title: 'Panel: reset settings',
    description: 'Remove panel overrides and return to native/default settings.',
    inputSchema: {},
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    _meta: APP_META
  }, async () => {
    try {
      const settings = resetOverrides()
      return textResult('ok', {
        values: {
          topN: settings.topN,
          followSymlinks: settings.followSymlinks,
          allowOpenFolder: settings.allowOpenFolder,
          allowOpenFolderSensitive: settings.allowOpenFolderSensitive,
          allowCleanup: settings.allowCleanup,
          excludeGlobs: settings.excludeGlobs,
          language: settings.language
        }
      })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'settings-failed')
    }
  })

  server.registerTool('plan_cleanup', {
    title: 'Panel: cleanup preview',
    description: 'Preview what a safe cleanup would move. Read-only; moves nothing.',
    inputSchema: {
      offset: z.number().int().min(0).max(500).optional(),
      limit: z.number().int().min(1).max(200).optional()
    },
    annotations: { readOnlyHint: true, openWorldHint: false },
    _meta: APP_META
  }, async (args) => {
    try {
      const settings = loadSettings()
      const env = buildEnvironment(settings)
      const plan = await planCleanup({ env, settings })
      const offset = args.offset ?? 0
      const limit = args.limit ?? 100
      return textResult('ok', compactPlan(plan, offset, limit))
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'plan-failed')
    }
  })

  server.registerTool('perform_cleanup', {
    title: 'Panel: move safe items to quarantine',
    description: 'Move the previewed safe items into the quarantine. Requires allowCleanup and confirm=true.',
    inputSchema: {
      confirm: z.boolean(),
      expectedBytes: z.number().int().nonnegative().optional(),
      expectedItemCount: z.number().int().nonnegative().optional()
    },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    _meta: APP_META
  }, async (args) => {
    try {
      const settings = loadSettings()
      if (settings.allowCleanup !== true) {
        return errorResult('清理开关没有打开。请先在面板的 ⚙ 里打开「允许清理」。', 'disabled')
      }
      if (args.confirm !== true) {
        return errorResult('需要显式的二次确认（confirm=true）。', 'confirmation-required')
      }
      const env = buildEnvironment(settings)
      const plan = await planCleanup({ env, settings })
      if (args.expectedItemCount !== undefined && args.expectedItemCount !== plan.itemCount) {
        return textResult('stale-plan', {
          ok: false,
          reason: 'stale-plan',
          itemCount: plan.itemCount,
          totalBytes: plan.totalBytes
        })
      }
      if (args.expectedBytes !== undefined && args.expectedBytes !== plan.totalBytes) {
        return textResult('stale-plan', {
          ok: false,
          reason: 'stale-plan',
          itemCount: plan.itemCount,
          totalBytes: plan.totalBytes
        })
      }
      const result = await performCleanup({ env, settings, plan })
      return textResult('ok', compactCleanupResult(result))
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'cleanup-failed')
    }
  })

  server.registerTool('undo_cleanup', {
    title: 'Panel: undo a cleanup batch',
    description: 'Move a quarantine batch back to its original paths. Restores only; allowed even when cleanup is off.',
    inputSchema: {
      batchId: z.string().min(1).max(64)
    },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    _meta: APP_META
  }, async (args) => {
    try {
      const settings = loadSettings()
      const env = buildEnvironment(settings)
      const result = undoCleanup({ env, settings, id: args.batchId })
      if (!result.ok && result.reason !== undefined) {
        return errorResult(`撤销失败：${result.reason}`, result.reason)
      }
      return textResult('ok', {
        ok: result.ok,
        id: result.id,
        status: result.status,
        restoredCount: result.restored.length,
        restoredBytes: result.restoredBytes,
        failures: result.failures.slice(0, 20),
        failureCount: result.failures.length,
        manifestPath: result.manifestPath
      })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'undo-failed')
    }
  })

  server.registerTool('list_quarantine', {
    title: 'Panel: quarantine batches',
    description: 'List batches currently in quarantine.',
    inputSchema: {},
    annotations: { readOnlyHint: true, openWorldHint: false },
    _meta: APP_META
  }, async () => {
    try {
      const settings = loadSettings()
      return textResult('ok', { batches: listQuarantine(settings) })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'quarantine-failed')
    }
  })

  server.registerTool('open_folder', {
    title: 'Panel: reveal a folder',
    description: 'Open a scanned folder in the OS file manager. Path must be inside a scanned root.',
    inputSchema: {
      path: z.string().min(1).max(2000)
    },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false },
    _meta: APP_META
  }, async (args) => {
    try {
      const settings = loadSettings()
      const env = buildEnvironment(settings)
      const verdict = resolveOpenTarget(args.path, settings, env)
      if (!verdict.ok) return errorResult(`不能打开：${verdict.reason}`, verdict.reason)
      try {
        openTarget(verdict.target)
      } catch (error) {
        return errorResult(String(error?.message ?? error), 'open-failed')
      }
      return textResult('ok', { opened: true, target: verdict.target, safety: verdict.safety })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'open-failed')
    }
  })

  server.registerTool('open_reports', {
    title: 'Panel: reveal the report folder',
    description: 'Open the report directory.',
    inputSchema: {},
    annotations: { readOnlyHint: false, openWorldHint: false },
    _meta: APP_META
  }, async () => {
    try {
      const settings = loadSettings()
      fs.mkdirSync(settings.reportDir, { recursive: true })
      openTarget(settings.reportDir)
      return textResult('ok', { opened: true, target: settings.reportDir })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'open-failed')
    }
  })

  server.registerTool('open_quarantine', {
    title: 'Panel: reveal the quarantine folder',
    description: 'Open the quarantine directory.',
    inputSchema: {},
    annotations: { readOnlyHint: false, openWorldHint: false },
    _meta: APP_META
  }, async () => {
    try {
      const settings = loadSettings()
      fs.mkdirSync(settings.quarantineDir, { recursive: true })
      openTarget(settings.quarantineDir)
      return textResult('ok', { opened: true, target: settings.quarantineDir })
    } catch (error) {
      return errorResult(String(error?.message ?? error), 'open-failed')
    }
  })

  return server
}

export { SAFE_IDS, systemOpenCommand }
