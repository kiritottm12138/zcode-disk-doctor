/**
 * MCP stdio entry point.
 *
 * ZCode launches this as a child process from `.zcode-plugin/plugin.json`.
 * stdout is the JSON-RPC channel; diagnostics go to stderr only.
 */

import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'

import { createServer } from './tools.js'

process.on('uncaughtException', (error) => {
  process.stderr.write(`[zcode-disk-doctor] uncaught: ${error?.stack ?? error}\n`)
  process.exitCode = 1
})

process.on('unhandledRejection', (error) => {
  process.stderr.write(`[zcode-disk-doctor] unhandled rejection: ${error?.stack ?? error}\n`)
})

const server = createServer()
const transport = new StdioServerTransport()
await server.connect(transport)
