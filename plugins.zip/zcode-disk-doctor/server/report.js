/**
 * Report rendering: the Markdown that enters the conversation, the Markdown
 * file written to disk, and the stable JSON document other tools can consume.
 *
 * Rendering is pure: it takes a finished scan result and returns strings, so it
 * is testable without touching the filesystem.
 *
 * @module zcode-disk-doctor/report
 */

import os from 'node:os'

export const SCHEMA_ID = 'zcode-disk-doctor/report@1'

const UNITS = [
  { suffix: 'TB', scale: 1024 ** 4 },
  { suffix: 'GB', scale: 1024 ** 3 },
  { suffix: 'MB', scale: 1024 ** 2 },
  { suffix: 'KB', scale: 1024 }
]

export function formatIn (bytes, unit) {
  const value = bytes / unit.scale
  const digits = unit.suffix === 'B' ? 0 : value >= 100 ? 0 : value >= 10 ? 1 : 2
  return `${value.toFixed(digits)} ${unit.suffix}`
}

export function pickUnit (largest) {
  for (const unit of UNITS) if (largest >= unit.scale) return unit
  return { suffix: 'B', scale: 1 }
}

export function formatBytes (bytes) {
  return formatIn(bytes, pickUnit(bytes))
}

export function timestampSlug (date = new Date()) {
  const pad = (value) => String(value).padStart(2, '0')
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-` +
    `${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`
}

export function pickText (language, zh, en) {
  return language === 'en-US' ? en : zh
}

export function categoryLabel (category, language = 'zh-CN') {
  return language === 'en-US' && typeof category.labelEn === 'string' ? category.labelEn : category.label
}

export function areaLabel (area, language = 'zh-CN') {
  return language === 'en-US' && typeof area.labelEn === 'string' ? area.labelEn : area.label
}

function reclaimText (category, language) {
  if (category.reclaim === undefined) return ''
  if (typeof category.reclaim === 'string') return category.reclaim
  return language === 'en-US' ? category.reclaim.en : category.reclaim.zh
}

/** Make a dynamic value safe inside prose/details (no HTML, no code-fence breaks). */
export function safeInline (value) {
  return String(value ?? '')
    .replace(/`/g, "'")
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\r?\n/g, ' ')
}

/** Make a dynamic value safe inside a Markdown table cell. */
export function safeTableCell (value) {
  return safeInline(value).replace(/\|/g, '\\|')
}

export function safetyBuckets (categories) {
  const sum = (level) => categories
    .filter((category) => category.safety === level)
    .reduce((total, category) => total + category.bytes, 0)
  return { safe: sum('safe'), care: sum('care'), keep: sum('keep') }
}

function cleanableBreakdown (categories, language) {
  const parts = categories
    .filter((category) => category.bytes > 0 && category.safety === 'safe')
    .sort((a, b) => b.bytes - a.bytes)
    .map((category) => `${categoryLabel(category, language)} ${formatBytes(category.bytes)}`)
  return parts.length === 0 ? '' : pickText(language, `（来自 ${parts.join('、')}）`, ` (from ${parts.join(', ')})`)
}

function reclaimSentence (categories, totals, language) {
  const buckets = safetyBuckets(categories)
  if (language === 'en-US') {
    return `Total **${formatBytes(totals.bytes)}**: **${formatBytes(buckets.safe)}** safe to clean` +
      `${cleanableBreakdown(categories, language)}, **${formatBytes(buckets.care)}** needs the right method ` +
      `(uninstall plugins rather than deleting files), and **${formatBytes(buckets.keep)}** should be left alone.`
  }
  return `一共 **${formatBytes(totals.bytes)}**：` +
    `**${formatBytes(buckets.safe)}** 可以安全清理${cleanableBreakdown(categories, language)}，` +
    `**${formatBytes(buckets.care)}** 需要正确操作才能省下（例如卸载不用的插件），` +
    `剩下 **${formatBytes(buckets.keep)}** 请不要动。三部分相加就是总数。`
}

export function categoriesOf (report, areaId) {
  return (report.categories ?? []).filter((category) => category.area === areaId)
}

export function areasOf (report) {
  if (Array.isArray(report.areas) && report.areas.length > 0) return report.areas
  return [{
    id: 'data',
    label: 'ZCode 数据',
    labelEn: 'ZCode data',
    totals: report.totals,
    roots: [],
    notes: [],
    categories: (report.categories ?? []).map((category) => category.id)
  }]
}

function isFullWidth (code) {
  return (
    (code >= 0x1100 && code <= 0x115f) ||
    (code >= 0x2e80 && code <= 0xa4cf && code !== 0x303f) ||
    (code >= 0xac00 && code <= 0xd7a3) ||
    (code >= 0xf900 && code <= 0xfaff) ||
    (code >= 0xfe30 && code <= 0xfe6f) ||
    (code >= 0xff00 && code <= 0xff60) ||
    (code >= 0xffe0 && code <= 0xffe6) ||
    (code >= 0x20000 && code <= 0x3fffd)
  )
}

export function displayWidth (text) {
  let width = 0
  for (const character of text) width += isFullWidth(character.codePointAt(0)) ? 2 : 1
  return width
}

function padDisplay (text, width) {
  return text + ' '.repeat(Math.max(0, width - displayWidth(text)))
}

function largestItem (category) {
  return category.topItems.length === 0 ? undefined : category.topItems[0]
}

function renderTree (categories, options) {
  const shown = categories.filter((category) => category.bytes > 0)
  const unit = options.unit
  const language = options.language ?? 'zh-CN'
  const labelWidth = Math.max(6, ...shown.map((category) => displayWidth(categoryLabel(category, language))))
  const lines = []
  shown.forEach((category, index) => {
    const glyph = index === shown.length - 1 ? '└─' : '├─'
    const size = formatIn(category.bytes, unit).padStart(9)
    const biggest = largestItem(category)
    const notes = []
    if (category.linkedItems > 0) notes.push(pickText(language, `${category.linkedItems} 个链接未跟随`, `${category.linkedItems} links skipped`))
    if (category.itemCount > 1) notes.push(pickText(language, `${category.itemCount} 项`, `${category.itemCount} items`))
    if (biggest !== undefined) notes.push(pickText(language, `最大 ${formatBytes(biggest.bytes)}`, `largest ${formatBytes(biggest.bytes)}`))
    if (category.truncated) notes.push(pickText(language, '已截断', 'truncated'))
    const note = notes.length > 0 ? `  (${notes.join('，')})` : ''
    lines.push(`${options.indent ?? '  '}${glyph} ${padDisplay(categoryLabel(category, language), labelWidth)} ${size}${note}`)

    if (options.detail) {
      const itemIndent = `${options.indent ?? '  '}${index === shown.length - 1 ? '   ' : '│  '}`
      for (const item of category.topItems) {
        const itemSize = formatIn(item.bytes, unit).padStart(9)
        const itemNote = item.note !== undefined ? `  ${safeInline(item.note)}` : ''
        lines.push(`${itemIndent}  ${itemSize}  ${safeInline(item.path)}${itemNote}`)
      }
      if (category.itemCount > category.topItems.length) {
        lines.push(`${itemIndent}  ${' '.repeat(9)}  … ${category.itemCount - category.topItems.length} more`)
      }
    }
  })
  return lines
}

function renderAreaIntro (area, options = {}) {
  const unit = pickUnit(area.totals?.bytes ?? 0)
  const label = `${areaLabel(area, options.language)} — ${formatIn(area.totals?.bytes ?? 0, unit)}`
  const lines = []
  if (options.withTitle !== false) lines.push(options.heading === true ? `## ${label}` : `**${label}**`)
  for (const note of area.notes ?? []) lines.push(`> ${safeInline(note)}`)
  if (lines.length > 0) lines.push('')
  return lines
}

const LINK_INSTALL_LIMIT = 10

function renderLinkInstalls (links, language) {
  if (!Array.isArray(links) || links.length === 0) return []
  const shown = [...links].sort((a, b) => b.bytes - a.bytes)
  const lines = [
    pickText(language, '**链接安装（真实文件在扫描范围之外，不计入上面的数字）**', '**Linked installs (real files outside the scan; not counted above)**'),
    ''
  ]
  for (const link of shown.slice(0, LINK_INSTALL_LIMIT)) {
    const measured = link.truncated ? `≥ ${formatBytes(link.bytes)}` : formatBytes(link.bytes)
    lines.push(`- ${safeInline(link.path)}`)
    lines.push(`  → \`${safeInline(link.target)}\`，${measured}`)
  }
  if (shown.length > LINK_INSTALL_LIMIT) {
    lines.push(`- … ${shown.length - LINK_INSTALL_LIMIT} more`)
  }
  lines.push('')
  return lines
}

export function renderSummary (report, options = {}) {
  const language = options.language ?? 'zh-CN'
  const dataUnit = pickUnit(report.totals.bytes)
  const lines = [
    `### ${pickText(language, 'ZCode 空间体检', 'ZCode Disk Doctor')} — ` +
      `${pickText(language, 'ZCode 数据', 'ZCode data')} ${formatIn(report.totals.bytes, dataUnit)} / ` +
      `${report.totals.files.toLocaleString('en-US')} ${pickText(language, '个文件', 'files')}`,
    ''
  ]
  for (const area of areasOf(report)) {
    const own = categoriesOf(report, area.id)
    const areaUnit = pickUnit(area.totals?.bytes ?? 0)
    lines.push(...renderAreaIntro(area, { withTitle: area.id !== 'data', language }))
    const tree = renderTree(own, { unit: areaUnit, detail: options.detail === true && area.id === 'data', language })
    lines.push(...(tree.length === 0 ? ['  （这一部分没有统计到内容）'] : tree))
    if (area.id === 'data') lines.push('', reclaimSentence(own, report.totals, language))
    lines.push('')
  }
  lines.push(...renderLinkInstalls(report.linkInstalls, language))
  lines.push(pickText(language, `扫描用时 ${(report.durationMs / 1000).toFixed(1)} 秒`, `Scanned in ${(report.durationMs / 1000).toFixed(1)}s`) +
    (report.truncated ? pickText(language, '（已达上限，结果不完整）', ' (limit reached; incomplete)') : ''))
  if (options.reportPath !== undefined) {
    const safePath = safeInline(options.reportPath)
    lines.push(pickText(language, `报告已写入 \`${safePath}\``, `Report written to \`${safePath}\``))
  }
  if (report.warnings.length > 0) {
    lines.push('', '<details><summary>注意事项</summary>', '')
    for (const warning of report.warnings) lines.push(`- ${safeInline(warning)}`)
    lines.push('', '</details>')
  }
  return redactHome(lines.join('\n'))
}

export function renderMarkdownFile (report, options) {
  const language = options.language ?? 'zh-CN'
  const unit = pickUnit(report.totals.bytes)
  const areas = areasOf(report)
  const lines = [
    '# ZCode 空间体检报告',
    '',
    `- 生成时间：${options.generatedAt.toISOString()}（本地 ${options.generatedAt.toLocaleString('zh-CN')}）`,
    `- 数据文件夹：\`${safeInline(options.zcodeHome)}\``,
    ...(typeof options.desktopHome === 'string' && options.desktopHome !== '' && options.desktopHome !== options.zcodeHome
      ? [`- 桌面端数据文件夹：\`${safeInline(options.desktopHome)}\``]
      : []),
    `- 平台：${process.platform} ${os.release()} · Node ${process.versions.node}`,
    `- ZCode 数据区：**${formatIn(report.totals.bytes, unit)}**，${report.totals.files.toLocaleString('en-US')} 个文件，${report.totals.dirs.toLocaleString('en-US')} 个目录`,
    `- ${reclaimSentence(categoriesOf(report, 'data'), report.totals, language)}`,
    `- 扫描用时：${(report.durationMs / 1000).toFixed(1)} 秒${report.truncated ? '（已达上限，结果不完整）' : ''}`,
    '- 三个区各自独立统计，**不能相加**：程序与系统缓存不属于你的 ZCode 数据。',
    ''
  ]

  for (const area of areas) {
    const own = categoriesOf(report, area.id)
    const areaUnit = pickUnit(area.totals?.bytes ?? 0)
    lines.push(...renderAreaIntro(area, { heading: true, language }))
    lines.push('```', ...renderTree(own, { unit: areaUnit, detail: true, language }), '```', '')
    if (area.id === 'data') lines.push(reclaimSentence(own, report.totals, language), '')
  }

  if (Array.isArray(report.linkInstalls) && report.linkInstalls.length > 0) {
    lines.push('## 链接安装', '')
    lines.push('这些插件的真实文件在扫描范围之外（链接安装），因此**不计入上面的任何数字**。', '')
    const ranked = [...report.linkInstalls].sort((a, b) => b.bytes - a.bytes)
    for (const link of ranked.slice(0, LINK_INSTALL_LIMIT)) {
      const measured = link.truncated ? `至少 ${formatBytes(link.bytes)}` : formatBytes(link.bytes)
      lines.push(`- \`${safeInline(link.path)}\` → \`${safeInline(link.target)}\`，${measured}`)
    }
    if (ranked.length > LINK_INSTALL_LIMIT) {
      lines.push(`- …另有 ${ranked.length - LINK_INSTALL_LIMIT} 个未列出`)
    }
    lines.push('')
  }

  if (report.warnings.length > 0) {
    lines.push('## 注意事项', '')
    for (const warning of report.warnings) lines.push(`- ${safeInline(warning)}`)
    lines.push('')
  }

  lines.push('## 明细（Top N）', '')
  for (const area of areas) {
    for (const category of categoriesOf(report, area.id)) {
      if (category.bytes === 0 && category.roots.length === 0) continue
      lines.push(`### [${areaLabel(area, language)}] ${categoryLabel(category, language)} — ${formatBytes(category.bytes)}` +
        `（${category.itemCount} 项，可再生：${category.regenerable ? '是' : '否'}，` +
        `处理建议：${category.safety === 'safe' ? '可以安全清理' : category.safety === 'care' ? '要谨慎处理' : '不要动'}）`, '')
      lines.push(`> ${reclaimText(category, language)}`, '')
      if (category.roots.length > 0) {
        lines.push(`扫描路径：${category.roots.map((root) => `\`${safeInline(root)}\``).join('、')}`, '')
      }
      if (category.topItems.length === 0) {
        lines.push('_无条目_', '')
        continue
      }
      lines.push('| 大小 | 文件数 | 路径 | 备注 |', '|---|---:|---|---|')
      for (const item of category.topItems) {
        lines.push(`| ${formatBytes(item.bytes)} | ${item.files} | \`${safeTableCell(item.path)}\` | ${safeTableCell(item.note ?? '')} |`)
      }
      lines.push('')
    }
  }

  lines.push('---', '', '本报告由 `zcode-disk-doctor` v0.1 生成：只读扫描，未删除或修改任何文件。', '')
  return redactHome(lines.join('\n'))
}

export function redactHome (value, home = os.homedir()) {
  if (typeof value !== 'string' || value === '' || home === '') return value
  return value.split(home).join('~')
}

export function redactDeep (value, home = os.homedir()) {
  if (typeof value === 'string') return redactHome(value, home)
  if (Array.isArray(value)) return value.map((item) => redactDeep(item, home))
  if (value !== null && typeof value === 'object') {
    const out = {}
    for (const [key, item] of Object.entries(value)) out[key] = redactDeep(item, home)
    return out
  }
  return value
}

export function toJsonReport (report, options) {
  const document = {
    schema: SCHEMA_ID,
    generatedAt: options.generatedAt.toISOString(),
    zcodeHome: options.zcodeHome,
    desktopHome: options.desktopHome ?? null,
    platform: {
      os: process.platform,
      release: os.release(),
      node: process.versions.node
    },
    durationMs: report.durationMs,
    truncated: report.truncated,
    totals: report.totals,
    areas: areasOf(report).map((area) => ({
      id: area.id,
      label: area.label,
      labelEn: area.labelEn,
      bytes: area.totals?.bytes ?? 0,
      files: area.totals?.files ?? 0,
      dirs: area.totals?.dirs ?? 0,
      roots: area.roots ?? [],
      notes: area.notes ?? [],
      categories: area.categories ?? []
    })),
    regenerableBytes: report.regenerableBytes,
    contentBytes: report.contentBytes,
    symlinksSkipped: report.symlinks,
    unreadableEntries: report.unreadable,
    linkInstalls: (report.linkInstalls ?? []).map((link) => ({
      path: link.path,
      target: link.target,
      bytes: link.bytes,
      files: link.files,
      truncated: link.truncated,
      categoryId: link.categoryId,
      area: link.area
    })),
    capabilities: {
      openFolder: options.capabilities?.openFolder === true,
      openFolderSensitive: options.capabilities?.openFolderSensitive === true,
      cleanup: options.capabilities?.cleanup === true
    },
    categories: report.categories.map((category) => ({
      id: category.id,
      area: category.area,
      label: category.label,
      labelEn: category.labelEn,
      bytes: category.bytes,
      files: category.files,
      dirs: category.dirs,
      regenerable: category.regenerable,
      safety: category.safety,
      itemCount: category.itemCount,
      linkedItems: category.linkedItems,
      overlapBytes: category.overlapBytes ?? 0,
      roots: category.roots,
      reclaim: category.reclaim,
      topItems: category.topItems
    })),
    warnings: report.warnings
  }
  return options.redact === false ? document : redactDeep(document)
}
