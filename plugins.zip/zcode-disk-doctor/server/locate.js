/**
 * Where ZCode keeps things on this machine.
 *
 * ZCode's data folder can be relocated in two ways that must be honoured:
 * `ZCODE_DATA_BASE_DIR` names a parent directory (ZCode appends `.zcode`), and
 * `~/.zcode/cli/config.json` may carry `storage.dir`. The application install,
 * the Chromium profile and the updater cache are separate locations outside the
 * data folder; they are detected and validated rather than guessed.
 *
 * Every function is pure with respect to its inputs: environment, executable
 * path and filesystem probes are injectable, so the rules are testable without
 * depending on the machine they run on.
 *
 * @module zcode-disk-doctor/locate
 */

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

export const ZCODE_HOME_DIR_NAME = '.zcode'
export const ZCODE_DATA_BASE_ENV = 'ZCODE_DATA_BASE_DIR'
export const ZDD_HOME_ENV = 'ZDD_ZCODE_HOME'
export const ZDD_DESKTOP_HOME_ENV = 'ZDD_DESKTOP_HOME'

function defaultIsDirectory (candidate) {
  try {
    return fs.statSync(candidate).isDirectory()
  } catch {
    return false
  }
}

function defaultIsFile (candidate) {
  try {
    return fs.statSync(candidate).isFile()
  } catch {
    return false
  }
}

function defaultRealpath (candidate) {
  try {
    return fs.realpathSync(candidate)
  } catch {
    return null
  }
}

function defaultLstat (candidate) {
  try {
    return fs.lstatSync(candidate)
  } catch {
    return null
  }
}

/**
 * Expand the tilde forms ZCode documents: `~`, `~/…` and `~\…`.
 * @param {string} candidate - a configured path.
 * @param {string} [home] - the home directory.
 * @returns {string} the expanded path.
 */
export function expandHome (candidate, home = os.homedir()) {
  if (candidate === '~') return home
  if (candidate.startsWith('~/') || candidate.startsWith('~\\')) {
    return path.join(home, candidate.slice(2))
  }
  return candidate
}

/**
 * Canonicalize a directory by resolving symlinks/junctions in its deepest
 * existing ancestor, then re-appending the not-yet-created segments.
 *
 * @param {string} target - the path to canonicalize.
 * @returns {string} the canonical absolute path.
 */
export function canonicalizeDirectory (target) {
  const resolved = path.resolve(target)
  const missing = []
  let existing = resolved
  for (;;) {
    try {
      const real = fs.realpathSync(existing)
      return missing.length === 0 ? real : path.join(real, ...missing.reverse())
    } catch {
      const parent = path.dirname(existing)
      if (parent === existing) return resolved
      missing.push(path.basename(existing))
      existing = parent
    }
  }
}

/** Comparison key for a path, case-insensitive on Windows. */
export function pathKey (candidate) {
  const resolved = path.resolve(candidate)
  return process.platform === 'win32' ? resolved.toLowerCase() : resolved
}

/** True when `candidate` is `base` itself or lies inside it. */
export function isUnder (candidate, base) {
  const rel = path.relative(path.resolve(base), path.resolve(candidate))
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel))
}

/**
 * True when resolving `candidate` traverses a symlink or junction.
 *
 * Cleanup ownership is decided on lexical paths. A junction inside a "safe"
 * root would otherwise let a rename escape that root: the path looks like it is
 * under `~/.zcode/cli/log`, while the bytes live somewhere else. Missing tails
 * are resolved through their deepest existing ancestor, so an undo path that no
 * longer exists is still checked against the links that remain.
 *
 * @param {string} candidate - the path to test.
 * @returns {boolean} whether the path traverses a link (or is unusable).
 */
export function pathTraversesLink (candidate) {
  if (typeof candidate !== 'string' || candidate.trim() === '') return true
  const resolved = path.resolve(candidate)
  const real = canonicalizeDirectory(resolved)
  return pathKey(real) !== pathKey(resolved)
}

/**
 * Read `storage.dir` from ZCode's user config.
 * @param {{ home?: string, userConfigPath?: string }} [options] - overrides.
 * @returns {string|null} the configured data folder, or null.
 */
export function readStorageDir (options = {}) {
  const home = options.home ?? os.homedir()
  const file = options.userConfigPath ?? path.join(home, ZCODE_HOME_DIR_NAME, 'cli', 'config.json')
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'))
    const dir = parsed?.storage?.dir
    if (typeof dir === 'string' && dir.trim() !== '') return expandHome(dir.trim(), home)
  } catch {
    /* absent or malformed: fall through to the default */
  }
  return null
}

/**
 * The ZCode data folder on this machine.
 *
 * Order: explicit plugin setting → `ZCODE_DATA_BASE_DIR` (a parent; ZCode
 * appends `.zcode`) → `storage.dir` in the user config → `~/.zcode`.
 *
 * @param {object} [options] - overrides.
 * @param {NodeJS.ProcessEnv} [options.env] - process environment.
 * @param {string} [options.home] - OS home.
 * @param {string} [options.zcodeHome] - explicit path from plugin settings.
 * @param {string} [options.userConfigPath] - config file override.
 * @returns {string} the canonical data folder.
 */
export function resolveZcodeHome (options = {}) {
  const env = options.env ?? process.env
  const home = options.home ?? os.homedir()
  const explicit = typeof options.zcodeHome === 'string' && options.zcodeHome.trim() !== ''
    ? options.zcodeHome.trim()
    : (typeof env[ZDD_HOME_ENV] === 'string' ? env[ZDD_HOME_ENV].trim() : '')
  if (explicit !== '') return canonicalizeDirectory(expandHome(explicit, home))

  const storage = readStorageDir({ home, userConfigPath: options.userConfigPath })
  if (storage !== null) return canonicalizeDirectory(storage)

  return canonicalizeDirectory(path.join(home, ZCODE_HOME_DIR_NAME))
}

/**
 * The desktop application's data folder.
 *
 * ZCode Desktop sets `ZCODE_DATA_BASE_DIR` to a parent directory and appends
 * `.zcode`. On this machine that is a *different* folder from the CLI's
 * `~/.zcode`: the CLI keeps `cli/db` and session artifacts under the home
 * folder, while the desktop keeps `v2/` (settings, task index, logs, generated
 * UI state) under the configured base. Both are ZCode data and both are
 * reported; when the two coincide they are counted once.
 *
 * @param {object} [options] - overrides.
 * @returns {string} the canonical desktop data folder.
 */
export function resolveDesktopHome (options = {}) {
  const env = options.env ?? process.env
  const home = options.home ?? os.homedir()
  const explicit = typeof options.desktopHome === 'string' && options.desktopHome.trim() !== ''
    ? options.desktopHome.trim()
    : (typeof env[ZDD_DESKTOP_HOME_ENV] === 'string' ? env[ZDD_DESKTOP_HOME_ENV].trim() : '')
  if (explicit !== '') return canonicalizeDirectory(expandHome(explicit, home))

  const base = typeof env[ZCODE_DATA_BASE_ENV] === 'string' ? env[ZCODE_DATA_BASE_ENV].trim() : ''
  if (base !== '') return canonicalizeDirectory(path.join(expandHome(base, home), ZCODE_HOME_DIR_NAME))

  return resolveZcodeHome({ env, home, zcodeHome: options.zcodeHome })
}

/** Marker paths that prove a directory is an unpacked Electron application. */
function appMarkers (root) {
  const resources = path.join(root, 'resources')
  const contents = path.join(root, 'Contents', 'Resources')
  return [
    path.join(resources, 'app.asar'),
    path.join(resources, 'app.asar.unpacked'),
    path.join(resources, 'app-update.yml'),
    path.join(contents, 'app.asar'),
    path.join(contents, 'app.asar.unpacked')
  ]
}

/** True when `root` holds a packed Electron application. */
export function looksLikeAppRoot (root, deps = {}) {
  if (typeof root !== 'string' || root.trim() === '') return false
  const isFile = deps.isFile ?? defaultIsFile
  return appMarkers(root).some((marker) => isFile(marker))
}

/** Candidate roots implied by one directory (resources / Contents / executable). */
function rootsAround (candidate) {
  const isBundle = (value) => path.basename(value).toLowerCase().endsWith('.app')
  const roots = []
  const own = path.basename(candidate).toLowerCase()
  if (own === 'contents' && isBundle(path.dirname(candidate))) roots.push(path.dirname(candidate))
  roots.push(candidate)
  const parent = path.dirname(candidate)
  if (isBundle(parent)) roots.push(parent)
  if (isBundle(path.dirname(parent))) roots.push(path.dirname(parent))
  return [...new Set(roots)]
}

/**
 * Find the ZCode application install folder.
 *
 * Candidates are validated: a directory only counts when it really holds
 * `resources/app.asar` (or the macOS bundle equivalent). A headless `node`
 * deployment therefore reports "not found" instead of picking a neighbour.
 *
 * @param {object} [options] - overrides.
 * @returns {{ path: string, source: string }|null} the install folder and how it was found.
 */
export function detectAppRoot (options = {}) {
  const env = options.env ?? process.env
  const execPath = options.execPath ?? process.execPath
  const resourcesPath = options.resourcesPath ?? process.resourcesPath
  const isDirectory = options.isDirectory ?? defaultIsDirectory
  const sources = []

  if (typeof env.ZCODE_APP_ROOT === 'string' && env.ZCODE_APP_ROOT.trim() !== '') {
    sources.push(['ZCODE_APP_ROOT', env.ZCODE_APP_ROOT.trim()])
  }
  if (typeof resourcesPath === 'string' && resourcesPath !== '') {
    sources.push(['resourcesPath', path.dirname(resourcesPath)])
  }
  if (typeof env.ZCODE_DESKTOP_NODE_EXECUTABLE === 'string' && env.ZCODE_DESKTOP_NODE_EXECUTABLE !== '') {
    sources.push(['ZCODE_DESKTOP_NODE_EXECUTABLE', path.dirname(env.ZCODE_DESKTOP_NODE_EXECUTABLE)])
  }
  if (typeof execPath === 'string' && execPath !== '') {
    sources.push(['execPath', path.dirname(execPath)])
  }
  if (typeof env.LOCALAPPDATA === 'string' && env.LOCALAPPDATA !== '') {
    sources.push(['LOCALAPPDATA', path.join(env.LOCALAPPDATA, 'Programs', 'ZCode')])
  }
  if (typeof env.ProgramFiles === 'string' && env.ProgramFiles !== '') {
    sources.push(['ProgramFiles', path.join(env.ProgramFiles, 'ZCode')])
  }
  if (typeof env['ProgramFiles(x86)'] === 'string' && env['ProgramFiles(x86)'] !== '') {
    sources.push(['ProgramFiles(x86)', path.join(env['ProgramFiles(x86)'], 'ZCode')])
  }

  for (const [source, value] of sources) {
    for (const root of rootsAround(value)) {
      if (isDirectory(root) && looksLikeAppRoot(root, options)) return { path: root, source }
    }
  }
  return null
}

/** The Chromium user-data root ZCode's desktop window uses. */
export function detectChromiumDir (options = {}) {
  const env = options.env ?? process.env
  const home = options.home ?? os.homedir()
  const platform = options.platform ?? process.platform
  const isDirectory = options.isDirectory ?? defaultIsDirectory
  const candidates = []
  if (platform === 'win32') {
    if (typeof env.APPDATA === 'string' && env.APPDATA !== '') candidates.push(path.join(env.APPDATA, 'ZCode'))
    candidates.push(path.join(home, 'AppData', 'Roaming', 'ZCode'))
  } else if (platform === 'darwin') {
    candidates.push(path.join(home, 'Library', 'Application Support', 'ZCode'))
  } else {
    candidates.push(path.join(home, '.config', 'ZCode'))
    candidates.push(path.join(home, '.config', 'zcode'))
  }
  for (const candidate of candidates) if (isDirectory(candidate)) return candidate
  return null
}

/**
 * ZCode's Electron session folder, when it exists.
 * @param {string|null} chromiumDir - the Chromium user-data root.
 * @param {{ isDirectory?: (p: string) => boolean }} [deps] - probes.
 * @returns {string|null} the session folder, or the user-data root.
 */
export function detectChromiumSessionDir (chromiumDir, deps = {}) {
  if (typeof chromiumDir !== 'string' || chromiumDir === '') return null
  const isDirectory = deps.isDirectory ?? defaultIsDirectory
  const session = path.join(chromiumDir, 'session')
  return isDirectory(session) ? session : chromiumDir
}

/** The updater download cache. */
export function detectUpdaterDir (options = {}) {
  const env = options.env ?? process.env
  const home = options.home ?? os.homedir()
  const platform = options.platform ?? process.platform
  const isDirectory = options.isDirectory ?? defaultIsDirectory
  const candidates = []
  if (platform === 'win32') {
    if (typeof env.LOCALAPPDATA === 'string' && env.LOCALAPPDATA !== '') {
      candidates.push(path.join(env.LOCALAPPDATA, '@zcodedesktop-updater'))
    }
    candidates.push(path.join(home, 'AppData', 'Local', '@zcodedesktop-updater'))
  } else if (platform === 'darwin') {
    candidates.push(path.join(home, 'Library', 'Caches', '@zcodedesktop-updater'))
    candidates.push(path.join(home, 'Library', 'Application Support', '@zcodedesktop-updater'))
  } else {
    candidates.push(path.join(home, '.cache', '@zcodedesktop-updater'))
    candidates.push(path.join(home, '.local', 'share', '@zcodedesktop-updater'))
  }
  for (const candidate of candidates) if (isDirectory(candidate)) return candidate
  return null
}

/**
 * The plugin storage root, resolving the `<zcodeHome>/cli/plugins` junction.
 *
 * The junction is deliberate on some machines: plugin bytes live on another
 * volume. They are still ZCode data, so the resolved target is returned and the
 * report says where it went.
 *
 * @param {object} options - options.
 * @param {string} options.zcodeHome - the data folder.
 * @param {(p: string) => boolean} [options.isDirectory] - probe.
 * @param {(p: string) => object|null} [options.lstat] - probe.
 * @param {(p: string) => string|null} [options.realpath] - probe.
 * @returns {{ path: string, linkPath: string, isLink: boolean }|null} the plugin root.
 */
export function detectPluginsRoot (options = {}) {
  const zcodeHome = options.zcodeHome
  if (typeof zcodeHome !== 'string' || zcodeHome === '') return null
  const isDirectory = options.isDirectory ?? defaultIsDirectory
  const lstat = options.lstat ?? defaultLstat
  const realpath = options.realpath ?? defaultRealpath
  const linkPath = path.join(zcodeHome, 'cli', 'plugins')
  if (!isDirectory(linkPath)) return null
  const info = lstat(linkPath)
  const resolved = realpath(linkPath)
  const canonical = resolved === null ? canonicalizeDirectory(linkPath) : path.resolve(resolved)
  return {
    path: canonical,
    linkPath,
    isLink: pathKey(canonical) !== pathKey(linkPath) || info?.isSymbolicLink() === true
  }
}

/**
 * A second ZCode installation: the npm/pnpm global CLI, when present.
 * @param {object} [options] - overrides.
 * @returns {string|null} the package folder, or null.
 */
export function detectGlobalCli (options = {}) {
  const env = options.env ?? process.env
  const home = options.home ?? os.homedir()
  const isDirectory = options.isDirectory ?? defaultIsDirectory
  const isFile = options.isFile ?? defaultIsFile
  const roots = []
  if (typeof env.APPDATA === 'string' && env.APPDATA !== '') {
    roots.push(path.join(env.APPDATA, 'npm', 'node_modules'))
  }
  if (typeof env.npm_config_prefix === 'string' && env.npm_config_prefix !== '') {
    roots.push(path.join(env.npm_config_prefix, 'lib', 'node_modules'))
    roots.push(path.join(env.npm_config_prefix, 'node_modules'))
  }
  roots.push(path.join(home, '.npm-global', 'lib', 'node_modules'))
  roots.push('/usr/local/lib/node_modules')
  roots.push('/usr/lib/node_modules')
  const names = [['@zcode', 'cli'], ['@zai', 'zcode'], ['zcode']]
  for (const root of roots) {
    for (const segments of names) {
      const candidate = path.join(root, ...segments)
      if (isDirectory(candidate) && isFile(path.join(candidate, 'package.json'))) return candidate
    }
  }
  return null
}

/**
 * Session temp directories created by ZCode.
 * @param {string} tempDir - the OS temp directory.
 * @returns {string[]} existing `zcode-*` directories.
 */
export function listTempSpill (tempDir) {
  let entries
  try {
    entries = fs.readdirSync(tempDir, { withFileTypes: true })
  } catch {
    return []
  }
  const out = []
  for (const entry of entries) {
    if (!entry.name.toLowerCase().startsWith('zcode-')) continue
    const full = path.join(tempDir, entry.name)
    try {
      if (fs.statSync(full).isDirectory()) out.push(full)
    } catch {
      /* vanished */
    }
  }
  return out
}

/**
 * Build the detected environment a scan uses.
 * @param {object} settings - effective plugin settings.
 * @returns {object} the scan environment.
 */
export function buildEnvironment (settings) {
  const zcodeHome = resolveZcodeHome({
    env: process.env,
    home: os.homedir(),
    zcodeHome: settings.zcodeHome
  })
  const desktopHome = resolveDesktopHome({
    env: process.env,
    home: os.homedir(),
    zcodeHome: settings.zcodeHome,
    desktopHome: settings.desktopHome
  })
  const app = settings.appDir !== '' ? { path: settings.appDir, source: 'config' } : detectAppRoot()
  const envValue = (name) => {
    const value = process.env[name]
    return typeof value === 'string' && value.trim() !== '' ? canonicalizeDirectory(value.trim()) : null
  }
  const chromiumRoot = envValue('ZDD_CHROMIUM_DIR') ?? detectChromiumDir()
  const updaterDir = envValue('ZDD_UPDATER_DIR') ?? detectUpdaterDir()
  const tempDir = envValue('ZDD_TEMP_DIR') ?? os.tmpdir()
  const pluginsOverride = envValue('ZDD_PLUGINS_ROOT')
  const plugins = pluginsOverride !== null
    ? { path: pluginsOverride, linkPath: null, isLink: false }
    : detectPluginsRoot({ zcodeHome })
  return {
    zcodeHome,
    desktopHome,
    tempDir,
    appRoot: app === null ? null : canonicalizeDirectory(app.path),
    appRootSource: app === null ? null : app.source,
    chromiumDir: chromiumRoot,
    chromiumSessionDir: detectChromiumSessionDir(chromiumRoot),
    updaterDir,
    pluginsRoot: plugins === null ? null : plugins.path,
    pluginsLinkPath: plugins === null ? null : plugins.linkPath,
    pluginsIsLink: plugins === null ? false : plugins.isLink,
    globalCli: detectGlobalCli()
  }
}
