/**
 * Filesystem traversal and aggregation for the disk report.
 *
 * The walker is content-blind: it uses `stat` sizes only, never opens a file,
 * and never follows a symlink unless explicitly configured. Every failure mode
 * observed in the field (permission denied, vanished entry, cyclic junction) is
 * recorded and skipped instead of aborting the scan.
 *
 * The `sumTree`/`mapLimit`/`globToRegExp` core is adapted from the MIT-licensed
 * `dsh-disk-doctor` project; see NOTICE.
 *
 * @module zcode-disk-doctor/scan
 */

import fsp from 'node:fs/promises'
import path from 'node:path'

import { isUnder, pathKey } from './locate.js'
import { AREA_DEFS, isDirectory, resolveTargets } from './targets.js'

export const DEFAULT_LIMITS = Object.freeze({ maxFiles: 500_000, maxDurationMs: 30_000 })

const STAT_CONCURRENCY = 64
const DIR_CONCURRENCY = 16

const LINK_LIMITS = Object.freeze({
  maxLinks: 24,
  perRoot: 6,
  maxFiles: 30_000,
  maxDurationMs: 3_000
})

/**
 * Convert one glob to an anchored regular expression.
 * Supports `*` (within a path segment), `**` (across segments) and `?`.
 * @param {string} glob - the pattern, using either separator.
 * @returns {RegExp} a regexp matching normalized `/`-separated absolute paths.
 */
export function globToRegExp (glob) {
  const normalized = glob.replace(/\\/g, '/')
  let out = ''
  for (let i = 0; i < normalized.length; i++) {
    const ch = normalized[i]
    if (ch === '*') {
      if (normalized[i + 1] === '*') {
        i++
        if (normalized[i + 1] === '/') i++
        out += '.*'
      } else {
        out += '[^/]*'
      }
    } else if (ch === '?') {
      out += '[^/]'
    } else {
      out += ch.replace(/[.+^${}()|[\]\\]/g, '\\$&')
    }
  }
  return new RegExp(`^${out}$`, process.platform === 'win32' ? 'i' : '')
}

async function mapLimit (items, limit, fn) {
  const results = new Array(items.length)
  let cursor = 0
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    for (;;) {
      const index = cursor++
      if (index >= items.length) return
      results[index] = await fn(items[index], index)
    }
  })
  await Promise.all(workers)
  return results
}

async function safeRealpath (target) {
  try {
    return await fsp.realpath(target)
  } catch {
    return null
  }
}

async function sumTree (absPath, ctx) {
  let bytes = 0
  let files = 0
  let dirs = 0
  let mtimeMs = 0
  const visited = new Set()

  const visit = async (dir) => {
    if (ctx.stopped()) return
    if (ctx.followSymlinks) {
      const real = await safeRealpath(dir)
      const key = real === null ? null : pathKey(real)
      if (key !== null) {
        if (ctx.visitedReal.has(key)) return
        ctx.visitedReal.add(key)
      }
    }
    let entries
    try {
      entries = await fsp.readdir(dir, { withFileTypes: true })
    } catch (err) {
      ctx.unreadable += 1
      ctx.noteUnreadable(dir, err)
      return
    }

    const fileList = []
    const dirList = []

    for (const entry of entries) {
      if (ctx.stopped()) return
      const abs = path.join(dir, entry.name)
      if (ctx.pruned.has(pathKey(abs))) continue
      if (ctx.excludePatterns.length > 0 && ctx.excludePatterns.some((re) => re.test(abs.replace(/\\/g, '/')))) continue

      if (entry.isSymbolicLink()) {
        ctx.symlinks += 1
        if (!ctx.followSymlinks) continue
        let target
        try {
          target = await fsp.stat(abs)
        } catch {
          ctx.unreadable += 1
          continue
        }
        if (target.isDirectory()) dirList.push({ abs, real: await safeRealpath(abs) })
        else if (target.isFile()) fileList.push({ abs, stat: target })
        continue
      }

      if (entry.isDirectory()) dirList.push({ abs })
      else if (entry.isFile()) fileList.push({ abs, stat: null })
    }

    if (fileList.length > 0) {
      await mapLimit(fileList, STAT_CONCURRENCY, async (file) => {
        if (ctx.stopped()) return
        let stat = file.stat
        if (stat === null) {
          try {
            stat = await fsp.lstat(file.abs)
          } catch {
            ctx.unreadable += 1
            return
          }
        }
        if (stat.nlink > 1 && Number.isFinite(stat.ino) && stat.ino !== 0) {
          const inodeKey = `${stat.dev}:${stat.ino}`
          if (ctx.seenInodes !== null) {
            if (ctx.seenInodes.has(inodeKey)) return
            ctx.seenInodes.add(inodeKey)
          }
          if (ctx.hardLinked.has(inodeKey)) {
            if (ctx.probe === true) ctx.probeBytes += stat.size
          } else {
            ctx.hardLinked.set(inodeKey, stat.size)
          }
        }
        bytes += stat.size
        files += 1
        ctx.bytes += stat.size
        ctx.files += 1
        if (stat.mtimeMs > mtimeMs) mtimeMs = stat.mtimeMs
      })
    }

    await mapLimit(dirList, DIR_CONCURRENCY, async (child) => {
      if (ctx.stopped()) return
      if (child.real !== undefined) {
        if (child.real === null || visited.has(child.real)) return
        visited.add(child.real)
      }
      dirs += 1
      ctx.dirs += 1
      await visit(child.abs)
    })
  }

  await visit(absPath)
  ctx.dirs += 1
  dirs += 1
  return { bytes, files, dirs, mtimeMs }
}

async function sumFile (absPath, ctx) {
  try {
    const stat = await fsp.lstat(absPath)
    ctx.bytes += stat.size
    ctx.files += 1
    return { bytes: stat.size, files: 1, dirs: 0, mtimeMs: stat.mtimeMs }
  } catch (err) {
    ctx.unreadable += 1
    ctx.noteUnreadable(absPath, err)
    return { bytes: 0, files: 0, dirs: 0, mtimeMs: 0 }
  }
}

function pathOrNull (value) {
  return typeof value === 'string' && value.trim() !== '' ? value : null
}

/**
 * Scan every configured category, grouped into the three reported areas.
 *
 * @param {object} options - scan options.
 * @returns {Promise<object>} the report body, ready for rendering.
 */
export async function scan (options) {
  const started = Date.now()
  const limits = { ...DEFAULT_LIMITS, ...(options.limits ?? {}) }
  const topN = Number.isInteger(options.topN) && options.topN > 0 ? options.topN : 10
  const env = {
    zcodeHome: options.zcodeHome,
    desktopHome: pathOrNull(options.desktopHome),
    tempDir: options.tempDir,
    appRoot: pathOrNull(options.appRoot),
    appRootSource: typeof options.appRootSource === 'string' ? options.appRootSource : null,
    chromiumDir: pathOrNull(options.chromiumDir),
    chromiumSessionDir: pathOrNull(options.chromiumSessionDir),
    updaterDir: pathOrNull(options.updaterDir),
    pluginsRoot: pathOrNull(options.pluginsRoot),
    pluginsLinkPath: pathOrNull(options.pluginsLinkPath),
    pluginsIsLink: options.pluginsIsLink === true,
    globalCli: pathOrNull(options.globalCli),
    quarantineDir: pathOrNull(options.quarantineDir)
  }
  const only = Array.isArray(options.only) && options.only.length > 0 ? new Set(options.only) : null
  const { categories: resolved, warnings: targetWarnings, covered } = resolveTargets(env, only)

  const warnings = [...targetWarnings]
  const unreadablePaths = []
  const linkInstalls = []
  const measuredLinkTargets = new Set()
  const perRootLinks = new Map()
  const scannedRoots = resolved.flatMap((category) => category.roots.map((root) => root.path))
  let countedLinks = 0
  const linkBudget = {
    remainingFiles: LINK_LIMITS.maxFiles,
    deadline: started + Math.min(LINK_LIMITS.maxDurationMs, limits.maxDurationMs)
  }

  const ctx = {
    bytes: 0,
    files: 0,
    dirs: 0,
    symlinks: 0,
    unreadable: 0,
    truncated: false,
    followSymlinks: options.followSymlinks === true,
    seenInodes: new Set(),
    visitedReal: new Set(),
    hardLinked: new Map(),
    probe: false,
    probeBytes: 0,
    excludePatterns: (options.excludeGlobs ?? []).map(globToRegExp),
    pruned: covered,
    noteUnreadable (abs, err) {
      if (unreadablePaths.length < 20) unreadablePaths.push({ path: abs, code: err?.code ?? 'UNKNOWN' })
    },
    stopped () {
      if (ctx.truncated) return true
      if (ctx.files >= limits.maxFiles || Date.now() - started > limits.maxDurationMs) {
        ctx.truncated = true
        return true
      }
      return false
    }
  }

  const categories = []
  for (const category of resolved) {
    const before = { bytes: ctx.bytes, files: ctx.files, dirs: ctx.dirs }
    const items = []
    const isExcludedPath = (candidate) =>
      ctx.excludePatterns.length > 0 && ctx.excludePatterns.some((re) => re.test(candidate.replace(/\\/g, '/')))

    for (const root of category.roots) {
      if (ctx.stopped()) break
      if (isExcludedPath(root.path)) continue
      const enumerated = root.whole === true
        ? [{ label: root.label ?? path.basename(root.path), path: root.path, isDir: isDirectory(root.path), isSymlink: false }]
        : await category.enumerate(root)
      for (const item of enumerated) {
        if (category.id === 'other' && covered.has(pathKey(item.path))) continue
        if (isExcludedPath(item.path)) continue
        items.push({ ...item, rootIndex: category.roots.indexOf(root) })
      }
    }

    const scored = []
    let linked = 0
    ctx.probe = category.overlapProbe === true
    ctx.probeBytes = 0
    for (const item of items) {
      if (ctx.stopped()) break
      let isDir = item.isDir === true
      if (item.isSymlink === true) {
        ctx.symlinks += 1
        if (!ctx.followSymlinks) {
          linked += 1
          await recordLinkInstall(item, category, {
            linkInstalls,
            measuredLinkTargets,
            perRoot: perRootLinks,
            scannedRoots,
            onCounted: () => { countedLinks += 1 },
            linkBudget
          })
          continue
        }
        try {
          isDir = (await fsp.stat(item.path)).isDirectory()
        } catch {
          ctx.unreadable += 1
          continue
        }
      }
      const total = isDir ? await sumTree(item.path, ctx) : await sumFile(item.path, ctx)
      scored.push({ item, total })
    }
    scored.sort((a, b) => b.total.bytes - a.total.bytes || a.item.label.localeCompare(b.item.label))

    categories.push({
      id: category.id,
      area: category.area,
      label: category.label,
      labelEn: category.labelEn,
      regenerable: category.regenerable,
      safety: category.safety,
      recentMs: category.recentMs ?? 0,
      reclaim: category.reclaim,
      bytes: ctx.bytes - before.bytes,
      files: ctx.files - before.files,
      dirs: ctx.dirs - before.dirs,
      roots: category.roots.map((root) => root.path),
      itemCount: scored.length,
      linkedItems: linked,
      overlapBytes: ctx.probe ? ctx.probeBytes : 0,
      truncated: ctx.truncated,
      topItems: scored.slice(0, topN).map(({ item, total }) => ({
        path: item.path,
        bytes: total.bytes,
        files: total.files,
        mtimeMs: Math.round(total.mtimeMs),
        ...(item.label === path.basename(item.path) ? {} : { note: item.label })
      }))
    })
  }

  const areas = AREA_DEFS
    .map((def) => {
      const own = categories.filter((category) => category.area === def.id)
      const totals = own.reduce((sum, category) => ({
        bytes: sum.bytes + category.bytes,
        files: sum.files + category.files,
        dirs: sum.dirs + category.dirs
      }), { bytes: 0, files: 0, dirs: 0 })
      return {
        id: def.id,
        label: def.label,
        labelEn: def.labelEn,
        totals,
        roots: own.flatMap((category) => category.roots),
        notes: [def.note(env)],
        categories: own.map((category) => category.id)
      }
    })
    .filter((area) => area.categories.length > 0)

  const dataArea = areas.find((area) => area.id === 'data')
  const totals = dataArea?.totals ?? { bytes: 0, files: 0, dirs: 0 }
  const dataCategories = categories.filter((category) => category.area === 'data')

  if (ctx.truncated) {
    warnings.push(`扫描达到上限（${limits.maxFiles} 个文件或 ${Math.round(limits.maxDurationMs / 1000)} 秒），结果不完整`)
  }
  if (ctx.unreadable > 0) warnings.push(`${ctx.unreadable} 个条目无法读取，已跳过（不影响其余统计）`)
  if (ctx.symlinks > 0) {
    warnings.push(`${ctx.symlinks} 个符号链接/junction ${ctx.followSymlinks ? '已跟随' : '未跟随'}，未计入统计`)
  }
  if (linkInstalls.length > 0) {
    warnings.push(`${linkInstalls.length} 个链接安装（真实文件在扫描范围之外）已单独列出，不计入上面的总数`)
  }
  if (countedLinks > 0) {
    warnings.push(`${countedLinks} 个链接安装的目标本身就在扫描范围内，其字节已算在所在区里，不再单列`)
  }
  for (const missing of unreadablePaths) warnings.push(`无权限或不可读：${missing.path} (${missing.code})`)

  const regenerableBytes = dataCategories
    .filter((category) => category.regenerable)
    .reduce((sum, category) => sum + category.bytes, 0)

  return {
    generatedAt: new Date(started).toISOString(),
    totals,
    areas,
    categories,
    linkInstalls,
    regenerableBytes,
    contentBytes: totals.bytes - regenerableBytes,
    symlinks: ctx.symlinks,
    unreadable: ctx.unreadable,
    truncated: ctx.truncated,
    durationMs: Date.now() - started,
    warnings
  }
}

async function recordLinkInstall (item, category, state) {
  const perRoot = state.perRoot.get(item.rootIndex ?? 0) ?? 0
  if (perRoot >= LINK_LIMITS.perRoot) return
  if (state.linkInstalls.length >= LINK_LIMITS.maxLinks) return
  if (Date.now() > state.linkBudget.deadline || state.linkBudget.remainingFiles <= 0) return
  const target = await safeRealpath(item.path)
  if (target === null) return
  const key = pathKey(target)
  if (state.measuredLinkTargets.has(key)) return
  if (state.scannedRoots.some((root) => isUnder(target, root))) {
    state.measuredLinkTargets.add(key)
    state.onCounted()
    return
  }
  state.measuredLinkTargets.add(key)
  state.perRoot.set(item.rootIndex ?? 0, perRoot + 1)

  const sink = linkSink(state.linkBudget)
  const total = await sumTree(target, sink)
  state.linkBudget.remainingFiles -= sink.files
  state.linkInstalls.push({
    path: item.path,
    target,
    bytes: total.bytes,
    files: total.files,
    truncated: sink.truncated,
    categoryId: category.id,
    area: category.area
  })
}

function linkSink (budget) {
  const sink = {
    bytes: 0,
    files: 0,
    dirs: 0,
    symlinks: 0,
    unreadable: 0,
    truncated: false,
    followSymlinks: false,
    seenInodes: new Set(),
    visitedReal: new Set(),
    hardLinked: new Map(),
    probe: false,
    probeBytes: 0,
    excludePatterns: [],
    pruned: new Set(),
    noteUnreadable () {},
    stopped () {
      if (sink.truncated) return true
      if (sink.files >= budget.remainingFiles) {
        sink.truncated = true
        return true
      }
      return false
    }
  }
  return sink
}
