# ZCode 空间体检（zcode-disk-doctor）

> **ZCode 不会自己告诉你空间去哪了。** 这个插件把 ZCode 的数据、程序与系统缓存摊开：
> 每一类占多少、哪些可以安全回收、哪些是你的会话内容。附带一个右侧栏面板，
> 以及一次**只改名、不删除**的可撤销清理。

## 它做什么

- **只读统计** ZCode 的磁盘占用，分三个区：**ZCode 数据 / ZCode 程序 / 系统缓存**。
  三个区各自给总数，**永不相加**。
- **右侧栏“空间体检”面板**：分类条形图、Top N 明细、按插件/按会话视图、打开文件夹、
  颜色说明。
- **`disk_report` 工具**：模型可按需跑一次，返回 Markdown 摘要，并写出 `.md` + `.json`
  报告。
- **可撤销清理**，默认关闭：只处理 🟢 安全类别，只做 `rename` 到隔离目录，逐项写
  manifest，随时可以撤销；**绝不删除、绝不复制、绝不覆盖**。
- **ZCode 原生设置**（插件详情 → 高级）和面板齿轮里的实时开关。

## 安全契约

| 问题 | 回答 |
|---|---|
| 读什么？ | 只读目录元数据（`stat` 大小与时间戳）。不打开、不解析、不上传文件内容；唯一的例外是插件自己的配置、报告和隔离清单。 |
| 写什么？ | 报告文件、面板设置 `config.json`、隔离批次（被移动的文件夹本身 + `manifest.json`）。 |
| 会删除吗？ | **不会。** 代码里没有 `unlink`/`rm`/`rmdir`/`trashItem` 等删除调用；唯一的文件移动是 `cleanup.js` 里的 `renameSync`。 |
| 会联网吗？ | **不会。** 没有 `fetch`、`http`/`https`、socket；也没有遥测。 |
| 会出界吗？ | 数据目录、程序目录、Chromium 用户数据与更新缓存都是探测出来的；默认不跟随符号链接；报告会写明每个区的真实位置。 |
| 清理能碰什么？ | 只有 🟢 `safe` 类别：日志、命令输出、图片缓存、旧插件缓存、临时目录、更新下载包。会话数据库、插件本体、程序文件、登录态一律不参与。 |
| 清理能撤销吗？ | 能。每个批次都有 `manifest.json`，撤销会逐项复核；原位置已被占用时**拒绝覆盖**。 |
| 会打印账户名吗？ | 工具返回值、Markdown/JSON 报告会把主目录替换成 `~`；面板显示真实路径，因为你要在那里复制/打开。 |

## 安装（本地开发市场）

源码已经放在：

```text
D:\deep work\各种测试区\plugins\zcode-disk-doctor\
D:\deep work\各种测试区\plugins\marketplace.json
```

在 ZCode 桌面端：

1. 打开 **Plugin Marketplace**（插件市场）。
2. 点 **添加 / Add** → **Add Plugin Marketplace**。
3. 粘贴本地市场目录：`D:\deep work\各种测试区\plugins`。
4. 在 **Personal → dev-workspace-d04792e7**（本地开发市场）里找到 **ZCode 空间体检**，
   点 **安装 / Get**。
5. 安装后建议新开一个会话，让插件加载。

> 插件不会自动安装、自动启用或自动清理；安装与首次试用由你在 UI 里完成。

## 使用

自然语言即可：

- “ZCode 占了多少磁盘？帮我看看空间都花在哪了。”
- “打开空间体检面板。”
- `/disk-check`

也可以直接调用工具：

### `disk_report`

| 参数 | 类型 | 默认 | 含义 |
|---|---|---|---|
| `scope` | `"summary"` \| `"full"` | `"summary"` | `full` 额外列出每个类别的 Top N 明细。 |
| `topN` | 整数 `1..100` | 插件设置（默认 10） | 每个类别列出的条目数。 |
| `write` | 布尔 | `true` | 是否写入 `.md` / `.json` 报告。 |
| `categories` | 字符串数组 | 全部 | 只统计这些类别。 |

### 面板

- **总览**：三个区、每类一条横条；点开看 Top N。
- **按插件** / **按会话**：只看插件相关或会话相关的类别。
- **打开 / 复制路径**：安全位置默认可打开；敏感位置需要在 ⚙ 里额外打开开关。
- **清理**：**看看会移动什么** → 二次确认 → **移动到隔离区**；批次可以**撤销**。
- **⚙**：清理开关、打开敏感位置、跟随符号链接、Top N、额外排除、语言、路径。

## 三个区与类别

**ZCode 数据**：`~/.zcode` 的 `cli/`（会话数据库、附件、日志、exec、图片缓存、插件）
与桌面端数据目录（`ZCODE_DATA_BASE_DIR/.zcode` 的 `v2/`、任务索引、日志、可视化）。
插件目录如果是 junction，会解析到真实位置并计入。

**ZCode 程序**：正在运行的 ZCode 安装目录（本机 `D:\Zcode12`）。只读展示，不参与清理。

**系统缓存**：`%APPDATA%\ZCode` 的 Chromium 缓存/用户数据，以及
`%LOCALAPPDATA%\@zcodedesktop-updater` 的更新下载包。

| 等级 | 类别 |
|---|---|
| 🟢 可以安全清理 | 诊断日志、命令输出与 Shell 快照、会话图片缓存、旧插件缓存残留、会话临时目录、更新下载缓存 |
| 🟠 要谨慎处理 | 会话附件与工具输出、子代理输出、模型 I/O 日志、已安装插件缓存、插件市场缓存、旧插件私有数据、其他、桌面端浏览器缓存 |
| ⚪ 不要动 | 会话数据库、插件私有数据、设置/凭据/任务索引、备份、工作区数据、会话可视化、程序安装、全局 CLI、桌面端用户数据 |

数据区每个字节恰好落进一个类别，所以**各类别之和 = 数据区总数**。三个区仍然不相加。

## 设置

在 **设置 → 插件管理 → Installed → ZCode 空间体检 → 高级**：

| 字段 | 默认 | 含义 |
|---|---|---|
| `top_n` | 10 | 每个类别列出的条目数（1..100）。 |
| `follow_symlinks` | false | 是否跟随符号链接/junction。 |
| `allow_open_folder` | true | 允许打开安全位置。 |
| `allow_open_folder_sensitive` | false | 允许打开谨慎/不可动位置。 |
| `exclude_globs` | 空 | 额外排除的绝对路径通配符，逗号分隔。 |
| `report_dir` | 空 | 报告目录；留空用插件数据目录的 `reports/`。 |
| `quarantine_dir` | 空 | 隔离目录；留空用 `<zcodeHome>/.disk-doctor/quarantine`。 |
| `zcode_home` | 空 | CLI 数据目录；留空自动探测。 |
| `desktop_home` | 空 | 桌面端数据目录；留空用 `ZCODE_DATA_BASE_DIR/.zcode`。 |
| `app_dir` | 空 | 程序安装目录；留空从运行进程探测。 |
| `language` | auto | `auto` / `zh-CN` / `en-US`。 |

**`allow_cleanup` 不在原生设置里**，只放在面板的 ⚙ 齿轮里，默认关闭。打开后仍需在面板上
二次确认；它不会让插件删除任何东西。

面板齿轮保存的设置写入插件数据目录的 `config.json`，优先级高于原生设置；点
**恢复默认** 会移除这些覆盖。

## 清理：预演 → 移动 → 撤销

1. **预演**：只扫描 🟢 类别；列出会移动什么、跳过了什么（最近还在使用的条目不列入）。
   预演没有副作用，隔离目录不会被创建。
2. **移动**：需要 `allow_cleanup` 打开 + 面板二次确认。服务端重新预演，逐项复核归属，
   再 `rename` 到 `<quarantine>/<批次>/<类别>/<原始布局>`；每移动一项重写 `manifest.json`。
3. **撤销**：校验批次 id、目标在批次内、原路径属于安全类别、原位置未被占用；倒序恢复；
   绝不覆盖。即使清理开关关闭，撤销仍然可用。

跨卷时 `rename` 会失败并记录 `cross-device`，文件原样留在原地——**不会退化成复制+删除**。

## 报告

默认写入插件数据目录的 `reports/`：

```text
zcode-disk-report-<YYYYMMDD-HHMMSS>.md
zcode-disk-report-<YYYYMMDD-HHMMSS>.json
```

JSON 的稳定契约是 `"schema": "zcode-disk-doctor/report@1"`。面板的
**打开报告目录** 按钮可以直接定位。

## 开发

```bash
npm install
npm run build      # dist/server.mjs + dist/ui/panel.html
npm test           # core + server tests
npm run check      # 预留的安全检查入口
```

`zcode plugins validate <plugin-dir>` 可用于清单校验。

## 限制

- v0.1 在 Windows 上实测；macOS/Linux 的探测回退已实现但未实测。
- 会话标题没有读取 SQLite，按 `sess_...` 目录名分组。
- Chromium 缓存在 ZCode 运行期间不自动清理（标记 🟠）。
- 扫描有上限（50 万文件 / 30 秒）；撞上限时报告标注 `truncated`。
- 隔离目录需要你自己清空——插件里没有删除功能，这是刻意的。

## 许可证

MIT。扫描/清理/报告核心改编自 MIT 许可的
[dsh-disk-doctor](https://github.com/Yeqij/dsh-disk-doctor)，详见 [NOTICE](./NOTICE) 与
[LICENSE](./LICENSE)。
