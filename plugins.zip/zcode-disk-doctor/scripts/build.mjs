import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import { build } from 'esbuild'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const dist = path.join(root, 'dist')
const distUi = path.join(dist, 'ui')

fs.mkdirSync(distUi, { recursive: true })

await build({
  entryPoints: [path.join(root, 'server', 'index.js')],
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node20',
  outfile: path.join(dist, 'server.mjs'),
  legalComments: 'none',
  logLevel: 'warning'
})

await build({
  entryPoints: [path.join(root, 'ui', 'panel.js')],
  bundle: true,
  platform: 'browser',
  format: 'iife',
  target: 'chrome120',
  outfile: path.join(distUi, 'panel.js'),
  minify: true,
  legalComments: 'none',
  logLevel: 'warning'
})

const css = fs.readFileSync(path.join(root, 'ui', 'panel.css'), 'utf8')
const js = fs.readFileSync(path.join(distUi, 'panel.js'), 'utf8')
const template = fs.readFileSync(path.join(root, 'ui', 'panel.html'), 'utf8')
// Replacements must be functions: the bundle contains `$&`, `$'` and similar
// sequences, which String.replace would otherwise interpret as substitution
// patterns and splice the surrounding HTML into the script.
const html = template
  .replace('/*__PANEL_CSS__*/', () => css.replaceAll('</style', '<\\/style'))
  .replace('/*__PANEL_JS__*/', () => js.replaceAll('</script', '<\\/script'))

fs.writeFileSync(path.join(distUi, 'panel.html'), html, 'utf8')
fs.writeFileSync(path.join(distUi, 'panel.css'), css, 'utf8')

process.stdout.write(`built ${path.relative(root, path.join(dist, 'server.mjs'))} and ${path.relative(root, path.join(distUi, 'panel.html'))}\n`)
