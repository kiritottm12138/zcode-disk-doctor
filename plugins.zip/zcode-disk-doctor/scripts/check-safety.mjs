import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const failures = []

function read (relative) {
  return fs.readFileSync(path.join(root, relative), 'utf8')
}

const sourceFiles = [
  ...fs.readdirSync(path.join(root, 'server')).filter((file) => file.endsWith('.js')).map((file) => `server/${file}`),
  ...fs.readdirSync(path.join(root, 'ui')).filter((file) => file.endsWith('.js')).map((file) => `ui/${file}`)
]

const forbidden = [
  [/\bunlink(Sync)?\s*\(/, 'unlink'],
  [/\brmdir(Sync)?\s*\(/, 'rmdir'],
  [/\brmSync\s*\(/, 'rmSync'],
  [/\bfs\.rm\s*\(/, 'fs.rm'],
  [/trashItem/, 'trashItem'],
  [/Remove-Item/, 'Remove-Item'],
  [/shutil\.rmtree/, 'shutil.rmtree'],
  [/\bfetch\s*\(/, 'fetch'],
  [/http\.request/, 'http.request'],
  [/https\.request/, 'https.request'],
  [/net\.connect/, 'net.connect'],
  [/new\s+WebSocket/, 'WebSocket'],
  [/XMLHttpRequest/, 'XMLHttpRequest']
]

const renameFiles = []
for (const file of sourceFiles) {
  const source = read(file)
  for (const [pattern, name] of forbidden) {
    if (pattern.test(source)) failures.push(`${file}: forbidden ${name}`)
  }
  if (/\brenameSync\s*\(/.test(source)) renameFiles.push(file)
}

if (renameFiles.join(',') !== 'server/cleanup.js') {
  failures.push(`renameSync must appear only in server/cleanup.js, found: ${renameFiles.join(', ') || 'none'}`)
}

for (const file of ['dist/ui/panel.html', 'ui/panel.html']) {
  if (!fs.existsSync(path.join(root, file))) {
    failures.push(`${file}: missing`)
    continue
  }
  const html = read(file)
  if (/<script[^>]+src=["']https?:/i.test(html)) failures.push(`${file}: external script`)
  if (/<link[^>]+href=["']https?:/i.test(html)) failures.push(`${file}: external stylesheet`)
}
const panelSource = read('ui/panel.js')
if (/innerHTML|dangerouslySetInnerHTML/.test(panelSource)) failures.push('ui/panel.js: innerHTML')

const manifest = JSON.parse(read('.zcode-plugin/plugin.json'))
if (manifest.name !== 'zcode-disk-doctor') failures.push('manifest name mismatch')
if (!manifest.ui?.surfaces?.some((surface) => surface.resourceUri === 'ui://disk-doctor/panel.html')) {
  failures.push('manifest is missing the panel surface')
}
if (!manifest.mcpServers?.['disk-doctor']) failures.push('manifest is missing the disk-doctor MCP server')

const server = read('dist/server.mjs')
if (!server.includes('text/html;profile=mcp-app')) failures.push('server bundle does not serve the MCP Apps MIME type')
if (!server.includes('ui://disk-doctor/panel.html')) failures.push('server bundle does not register the panel URI')

if (failures.length > 0) {
  process.stderr.write(`Safety check failed:\n${failures.map((line) => `- ${line}`).join('\n')}\n`)
  process.exit(1)
}

process.stdout.write('Safety check passed.\n')
