import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'

import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js'

import { makeFixture, makeSettings, populate } from './helpers.mjs'
import { planCleanup } from '../server/cleanup.js'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

async function withClient (fixture, fn) {
  const client = new Client({ name: 'zdd-test', version: '0.0.0' }, { capabilities: {} })
  const transport = new StdioClientTransport({
    command: process.execPath,
    args: [path.join(root, 'dist', 'server.mjs')],
    env: {
      ...process.env,
      ZCODE_PLUGIN_DATA: fixture.data,
      ZDD_ZCODE_HOME: fixture.zcode,
      ZDD_DESKTOP_HOME: fixture.desktop,
      ZDD_APP_DIR: fixture.app,
      ZDD_QUARANTINE_DIR: fixture.quarantine,
      ZDD_PLUGINS_ROOT: fixture.plugins,
      ZDD_CHROMIUM_DIR: fixture.chromium,
      ZDD_UPDATER_DIR: fixture.updater,
      ZDD_TEMP_DIR: fixture.temp,
      ZDD_LANGUAGE: 'zh-CN'
    },
    stderr: 'pipe'
  })
  await client.connect(transport)
  try {
    return await fn(client)
  } finally {
    await client.close()
  }
}

test('MCP server exposes the tools, the panel resource, and a partitioned report', async () => {
  const fixture = makeFixture()
  populate(fixture)
  makeSettings(fixture)

  await withClient(fixture, async (client) => {
    const tools = await client.listTools()
    const names = tools.tools.map((tool) => tool.name)
    assert.ok(names.includes('disk_report'))
    assert.ok(names.includes('open_disk_panel'))
    assert.ok(names.includes('plan_cleanup'))
    assert.ok(names.includes('perform_cleanup'))

    const panelTool = tools.tools.find((tool) => tool.name === 'open_disk_panel')
    assert.equal(panelTool._meta.ui.resourceUri, 'ui://disk-doctor/panel.html')
    assert.ok(panelTool._meta.ui.visibility.includes('model'))

    const appOnly = tools.tools.find((tool) => tool.name === 'perform_cleanup')
    assert.deepEqual(appOnly._meta.ui.visibility, ['app'])
    const modelTool = tools.tools.find((tool) => tool.name === 'disk_report')
    assert.deepEqual(modelTool._meta.ui.visibility, ['model'])
    assert.equal(modelTool.annotations.readOnlyHint, false)

    const modelReport = await client.callTool({ name: 'disk_report', arguments: {} })
    assert.equal(modelReport.structuredContent.reportPath, undefined)
    assert.equal(fs.existsSync(path.join(fixture.data, 'reports')), false)

    const resources = await client.listResources()
    assert.ok(resources.resources.some((resource) => resource.uri === 'ui://disk-doctor/panel.html'))
    const panel = await client.readResource({ uri: 'ui://disk-doctor/panel.html' })
    assert.equal(panel.contents[0].mimeType, 'text/html;profile=mcp-app')
    assert.match(panel.contents[0].text, /ZCode Disk Doctor/)
    assert.doesNotMatch(panel.contents[0].text, /<script[^>]+src=/i)

    const report = await client.callTool({ name: 'get_report', arguments: {} })
    const data = report.structuredContent
    assert.equal(data.totals.bytes, 2480)
    const app = data.areas.find((area) => area.id === 'app')
    const cache = data.areas.find((area) => area.id === 'cache')
    assert.equal(app.totals.bytes, 1000)
    assert.equal(cache.totals.bytes, 690)
    assert.equal(data.categories.find((category) => category.id === 'logs').bytes, 530)

    const logs = await client.callTool({ name: 'get_category', arguments: { categoryId: 'logs', limit: 10 } })
    assert.equal(logs.structuredContent.category.id, 'logs')
    assert.ok(logs.structuredContent.items.length >= 4)
    assert.ok(logs.structuredContent.items.every((item) => typeof item.path === 'string'))

    const plan = await client.callTool({ name: 'plan_cleanup', arguments: { limit: 100 } })
    assert.equal(plan.structuredContent.dryRun, true)
    assert.equal(plan.structuredContent.itemCount, 11)
    assert.equal(plan.structuredContent.totalBytes, 1595)
    assert.equal(fs.existsSync(fixture.quarantine), false)

    const disabled = await client.callTool({ name: 'perform_cleanup', arguments: { confirm: true } })
    assert.equal(disabled.isError, true)
    assert.match(disabled.content[0].text, /disabled/)

    const settings = await client.callTool({ name: 'get_settings', arguments: {} })
    assert.equal(settings.structuredContent.values.allowCleanup, false)
    assert.equal(settings.structuredContent.paths.desktopHome, fixture.desktop)

    const updated = await client.callTool({ name: 'set_settings', arguments: { topN: 25 } })
    assert.equal(updated.structuredContent.values.topN, 25)
    const reset = await client.callTool({ name: 'reset_settings', arguments: {} })
    assert.equal(reset.structuredContent.values.topN, 10)

    const batches = await client.callTool({ name: 'list_quarantine', arguments: {} })
    assert.deepEqual(batches.structuredContent.batches, [])

    // End-to-end app-only move/undo against the fixture.
    await client.callTool({ name: 'set_settings', arguments: { allowCleanup: true } })
    const moved = await client.callTool({
      name: 'perform_cleanup',
      arguments: { confirm: true, expectedItemCount: 11, expectedBytes: 1595 }
    })
    assert.equal(moved.isError, undefined)
    assert.equal(moved.structuredContent.ok, true)
    assert.equal(moved.structuredContent.itemCount, 11)
    assert.equal(fs.existsSync(fixture.quarantine), true)
    const afterMove = await client.callTool({ name: 'list_quarantine', arguments: {} })
    assert.equal(afterMove.structuredContent.batches.length, 1)
    const batchId = afterMove.structuredContent.batches[0].id
    const undone = await client.callTool({ name: 'undo_cleanup', arguments: { batchId } })
    assert.equal(undone.structuredContent.ok, true)
    assert.equal(undone.structuredContent.restoredCount, 11)
    assert.equal(fs.existsSync(path.join(fixture.zcode, 'cli', 'log', 'a.log')), true)
    await client.callTool({ name: 'set_settings', arguments: { allowCleanup: false } })

    const badUndo = await client.callTool({ name: 'undo_cleanup', arguments: { batchId: 'not-a-batch' } })
    assert.equal(badUndo.isError, true)
  })

  fs.rmSync(fixture.root, { recursive: true, force: true })
})

test('core cleanup plan is deterministic for the fixture used by the server test', async () => {
  const fixture = makeFixture()
  populate(fixture)
  const settings = makeSettings(fixture)
  const plan = await planCleanup({
    env: {
      zcodeHome: fixture.zcode,
      desktopHome: fixture.desktop,
      tempDir: fixture.temp,
      appRoot: fixture.app,
      appRootSource: 'config',
      chromiumDir: fixture.chromium,
      chromiumSessionDir: path.join(fixture.chromium, 'session'),
      updaterDir: fixture.updater,
      pluginsRoot: fixture.plugins,
      pluginsLinkPath: null,
      pluginsIsLink: false,
      globalCli: null
    },
    settings
  })
  assert.equal(plan.itemCount, 11)
  assert.equal(plan.totalBytes, 1595)
  fs.rmSync(fixture.root, { recursive: true, force: true })
})
