import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import test from 'node:test'

import { MANIFEST_NAME, performCleanup, planCleanup, undoCleanup } from '../server/cleanup.js'
import { detectAppRoot, detectChromiumDir, detectPluginsRoot, detectUpdaterDir, resolveDesktopHome, resolveZcodeHome } from '../server/locate.js'
import { redactHome, renderMarkdownFile, renderSummary, safeInline, safetyBuckets, toJsonReport } from '../server/report.js'
import { scan } from '../server/scan.js'
import { applyOverrides, loadSettings, resetOverrides } from '../server/settings.js'
import { systemOpenCommand } from '../server/tools.js'
import { OLD, makeEnv, makeFixture, makeSettings, populate, writeFile } from './helpers.mjs'

function scanOptions (env, settings, topN = 10) {
  return {
    zcodeHome: env.zcodeHome,
    desktopHome: env.desktopHome,
    tempDir: env.tempDir,
    appRoot: env.appRoot,
    appRootSource: env.appRootSource,
    chromiumDir: env.chromiumDir,
    chromiumSessionDir: env.chromiumSessionDir,
    updaterDir: env.updaterDir,
    pluginsRoot: env.pluginsRoot,
    pluginsLinkPath: env.pluginsLinkPath,
    pluginsIsLink: env.pluginsIsLink,
    globalCli: env.globalCli,
    topN,
    excludeGlobs: settings.excludeGlobs,
    followSymlinks: settings.followSymlinks
  }
}

function bytesOf (report, id) {
  return report.categories.find((category) => category.id === id)?.bytes ?? 0
}

test('scan partitions the data area exactly once and keeps the three areas separate', async () => {
  const fixture = makeFixture()
  populate(fixture)
  const env = makeEnv(fixture)
  const settings = makeSettings(fixture)
  const report = await scan(scanOptions(env, settings))

  const dataSum = report.categories
    .filter((category) => category.area === 'data')
    .reduce((sum, category) => sum + category.bytes, 0)
  assert.equal(dataSum, report.totals.bytes)
  assert.equal(report.totals.bytes, 2480)
  assert.equal(bytesOf(report, 'other'), 5)
  assert.equal(bytesOf(report, 'logs'), 530)
  assert.equal(bytesOf(report, 'plugin-old-cache'), 85)
  assert.equal(bytesOf(report, 'settings'), 130)
  assert.equal(bytesOf(report, 'workspaces'), 130)
  assert.equal(bytesOf(report, 'visualizations'), 180)
  assert.equal(bytesOf(report, 'temp-spill'), 370)

  const app = report.areas.find((area) => area.id === 'app')
  const cache = report.areas.find((area) => area.id === 'cache')
  assert.equal(app.totals.bytes, 1000)
  assert.equal(cache.totals.bytes, 690)
  assert.equal(bytesOf(report, 'chromium-cache'), 150)
  assert.equal(bytesOf(report, 'chromium-profile'), 190)
  assert.equal(bytesOf(report, 'updater-cache'), 350)
  assert.equal(report.areas.length, 3)
})

test('cleanup preview has no side effect, moves only safe items, and undo restores them', async () => {
  const fixture = makeFixture()
  populate(fixture)
  const env = makeEnv(fixture)
  const settings = makeSettings(fixture)

  const plan = await planCleanup({ env, settings })
  assert.equal(plan.dryRun, true)
  assert.equal(plan.itemCount, 11)
  assert.equal(plan.totalBytes, 1595)
  assert.equal(plan.skipped.length, 1)
  assert.equal(plan.skipped[0].reason, 'recent')
  assert.equal(fs.existsSync(fixture.quarantine), false)

  const moved = await performCleanup({ env, settings, plan })
  assert.equal(moved.status, 'moved')
  assert.equal(moved.items.length, 11)
  assert.equal(moved.bytes, 1595)
  assert.equal(fs.existsSync(path.join(fixture.zcode, 'cli', 'log', 'a.log')), false)
  assert.equal(fs.existsSync(moved.manifestPath), true)
  const manifest = JSON.parse(fs.readFileSync(moved.manifestPath, 'utf8'))
  assert.equal(manifest.status, 'moved')
  assert.equal(manifest.items.length, 11)
  const first = manifest.items.find((item) => item.original.endsWith(path.join('cli', 'log', 'a.log')))
  assert.ok(first)
  assert.equal(fs.existsSync(first.target), true)
  assert.equal(fs.readFileSync(first.target, 'utf8').length, 300)

  const undone = undoCleanup({ env, settings, id: moved.id })
  assert.equal(undone.ok, true)
  assert.equal(undone.restored.length, 11)
  assert.equal(fs.readFileSync(path.join(fixture.zcode, 'cli', 'log', 'a.log'), 'utf8').length, 300)
})

test('undo refuses to overwrite an original that reappeared', async () => {
  const fixture = makeFixture()
  populate(fixture)
  const env = makeEnv(fixture)
  const settings = makeSettings(fixture)
  const plan = await planCleanup({ env, settings })
  const moved = await performCleanup({ env, settings, plan })

  const original = path.join(fixture.zcode, 'cli', 'log', 'a.log')
  fs.mkdirSync(path.dirname(original), { recursive: true })
  fs.writeFileSync(original, 'y'.repeat(300))

  const undone = undoCleanup({ env, settings, id: moved.id })
  assert.equal(undone.ok, false)
  assert.ok(undone.failures.some((failure) => failure.reason === 'occupied'))
  assert.equal(fs.readFileSync(original, 'utf8')[0], 'y')
})

test('undo refuses a manifest whose target escaped the batch', async () => {
  const fixture = makeFixture()
  populate(fixture)
  const env = makeEnv(fixture)
  const settings = makeSettings(fixture)
  const plan = await planCleanup({ env, settings })
  const moved = await performCleanup({ env, settings, plan })

  const manifestPath = path.join(path.dirname(moved.manifestPath), MANIFEST_NAME)
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'))
  manifest.items[0].target = path.join(fixture.root, 'outside')
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2))

  const undone = undoCleanup({ env, settings, id: moved.id })
  assert.equal(undone.ok, false)
  assert.ok(undone.failures.some((failure) => failure.reason === 'target-outside-batch'))
})

test('cleanup refuses a safe root that is a junction', async () => {
  const fixture = makeFixture()
  populate(fixture)
  const env = makeEnv(fixture)
  const settings = makeSettings(fixture)
  const outside = path.join(fixture.root, 'outside')
  writeFile(path.join(outside, 'important.txt'), 100, OLD)
  const logRoot = path.join(fixture.zcode, 'cli', 'log')
  fs.rmSync(logRoot, { recursive: true, force: true })

  let linked = true
  try {
    fs.symlinkSync(outside, logRoot, process.platform === 'win32' ? 'junction' : 'dir')
  } catch {
    linked = false
  }
  if (!linked) {
    fs.rmSync(fixture.root, { recursive: true, force: true })
    return
  }

  try {
    const plan = await planCleanup({ env, settings })
    assert.ok(plan.excluded.some((item) => item.reason === 'linked'))
    assert.equal(plan.items.some((item) => item.path.includes('important.txt')), false)

    await performCleanup({ env, settings, plan })
    assert.equal(fs.existsSync(path.join(outside, 'important.txt')), true)
  } finally {
    try {
      fs.unlinkSync(logRoot)
    } catch {
      try { fs.rmdirSync(logRoot) } catch { /* best effort */ }
    }
    fs.rmSync(fixture.root, { recursive: true, force: true })
  }
})

test('quarantine is reported separately and not double-counted as other', async () => {
  const fixture = makeFixture()
  populate(fixture)
  const env = makeEnv(fixture)
  const quarantine = path.join(fixture.zcode, '.disk-doctor', 'quarantine')
  writeFile(path.join(quarantine, '20240102-030405', 'manifest.json'), 40)
  const settings = makeSettings(fixture, { quarantineDir: quarantine })
  const report = await scan({ ...scanOptions(env, settings), quarantineDir: quarantine })

  assert.equal(bytesOf(report, 'quarantine'), 40)
  assert.equal(bytesOf(report, 'other'), 5)
  assert.equal(report.totals.bytes, 2520)
  fs.rmSync(fixture.root, { recursive: true, force: true })
})

test('the open command is absolute on Windows', () => {
  if (process.platform !== 'win32') return
  const command = systemOpenCommand()
  assert.equal(typeof command, 'string')
  assert.ok(path.isAbsolute(command))
  assert.match(command, /explorer\.exe$/i)
})

test('report escapes names that could break Markdown or inject HTML', () => {
  assert.equal(safeInline('a`b<c>\nd'), "a'b&lt;c&gt; d")
})

test('settings layers defaults, environment and panel overrides', () => {
  const fixture = makeFixture()
  const base = loadSettings({ env: {}, home: fixture.root, pluginData: fixture.data })
  assert.equal(base.topN, 10)
  assert.equal(base.allowCleanup, false)
  assert.equal(base.allowOpenFolder, true)

  const env = loadSettings({
    env: { ZDD_TOP_N: '20', ZDD_ALLOW_OPEN: 'false', ZDD_ALLOW_OPEN_SENSITIVE: 'true' },
    home: fixture.root,
    pluginData: fixture.data
  })
  assert.equal(env.topN, 20)
  assert.equal(env.allowOpenFolder, false)
  assert.equal(env.allowOpenFolderSensitive, true)

  const panel = applyOverrides({ topN: 30, allowCleanup: true }, {
    env: {}, home: fixture.root, pluginData: fixture.data
  })
  assert.equal(panel.topN, 30)
  assert.equal(panel.allowCleanup, true)
  assert.equal(panel.sources.topN, 'panel')

  const reset = resetOverrides({ env: {}, home: fixture.root, pluginData: fixture.data })
  assert.equal(reset.topN, 10)
  assert.equal(reset.allowCleanup, false)

  assert.throws(() => applyOverrides({ topN: 0 }, { home: fixture.root, pluginData: fixture.data }))
  assert.throws(() => applyOverrides({ allowCleanup: 'yes' }, { home: fixture.root, pluginData: fixture.data }))
})

test('report rendering keeps the three areas separate and redacts the home directory', async () => {
  const fixture = makeFixture()
  populate(fixture)
  const env = makeEnv(fixture)
  const settings = makeSettings(fixture)
  const report = await scan(scanOptions(env, settings))
  const generatedAt = new Date('2026-01-02T03:04:05Z')

  const summary = renderSummary(report, { detail: true, language: 'zh-CN' })
  assert.match(summary, /ZCode 空间体检/)
  assert.match(summary, /ZCode 数据/)

  const markdown = renderMarkdownFile(report, {
    zcodeHome: fixture.zcode,
    desktopHome: fixture.desktop,
    generatedAt,
    language: 'zh-CN'
  })
  assert.match(markdown, /三个区各自独立统计/)
  assert.match(markdown, /ZCode 程序/)
  assert.match(markdown, /系统缓存/)

  const json = toJsonReport(report, {
    zcodeHome: fixture.zcode,
    desktopHome: fixture.desktop,
    generatedAt,
    redact: true
  })
  assert.equal(json.schema, 'zcode-disk-doctor/report@1')
  assert.equal(json.categories.filter((category) => category.area === 'data')
    .reduce((sum, category) => sum + category.bytes, 0), json.totals.bytes)
  const buckets = safetyBuckets(json.categories.filter((category) => category.area === 'data'))
  assert.equal(buckets.safe + buckets.care + buckets.keep, json.totals.bytes)

  assert.equal(redactHome('C:\\Users\\me\\a', 'C:\\Users\\me'), '~\\a')
})

test('locate resolves the CLI home and the desktop home independently', () => {
  const fixture = makeFixture()
  fs.mkdirSync(path.join(fixture.root, 'home', '.zcode', 'cli'), { recursive: true })
  const home = path.join(fixture.root, 'home')
  assert.equal(resolveZcodeHome({ env: {}, home }), path.join(home, '.zcode'))

  const storageHome = path.join(fixture.root, 'storage')
  fs.mkdirSync(path.join(storageHome, 'cli'), { recursive: true })
  fs.writeFileSync(path.join(home, '.zcode', 'cli', 'config.json'), JSON.stringify({ storage: { dir: storageHome } }))
  assert.equal(resolveZcodeHome({ env: {}, home }), storageHome)

  const desktop = resolveDesktopHome({ env: { ZCODE_DATA_BASE_DIR: fixture.root }, home })
  assert.equal(desktop, path.join(fixture.root, '.zcode'))

  fs.mkdirSync(path.join(fixture.zcode, 'cli', 'plugins'), { recursive: true })
  const plugins = detectPluginsRoot({ zcodeHome: fixture.zcode })
  assert.equal(plugins.isLink, false)
  assert.equal(plugins.path, path.join(fixture.zcode, 'cli', 'plugins'))

  fs.mkdirSync(path.join(fixture.app, 'resources'), { recursive: true })
  fs.writeFileSync(path.join(fixture.app, 'resources', 'app.asar'), 'x')
  fs.writeFileSync(path.join(fixture.app, 'ZCode.exe'), 'x')
  const app = detectAppRoot({
    env: {},
    execPath: path.join(fixture.app, 'ZCode.exe'),
    resourcesPath: path.join(fixture.app, 'resources'),
    isDirectory: (candidate) => fs.existsSync(candidate) && fs.statSync(candidate).isDirectory(),
    isFile: (candidate) => fs.existsSync(candidate) && fs.statSync(candidate).isFile()
  })
  assert.equal(app.path, fixture.app)

  fs.mkdirSync(path.join(fixture.root, 'ZCode'), { recursive: true })
  fs.mkdirSync(path.join(fixture.root, '@zcodedesktop-updater'), { recursive: true })
  assert.equal(detectChromiumDir({ env: { APPDATA: fixture.root }, home }), path.join(fixture.root, 'ZCode'))
  assert.equal(detectUpdaterDir({ env: { LOCALAPPDATA: fixture.root }, home }), path.join(fixture.root, '@zcodedesktop-updater'))
})

test('source has no delete API and only cleanup.js renames', () => {
  const root = path.resolve('server')
  const files = fs.readdirSync(root).filter((file) => file.endsWith('.js'))
  const forbidden = [/unlink(Sync)?\s*\(/, /rmdir(Sync)?\s*\(/, /\brmSync\s*\(/, /\bfs\.rm\s*\(/, /trashItem/, /Remove-Item/, /shutil\.rmtree/]
  let renameFiles = []
  for (const file of files) {
    const source = fs.readFileSync(path.join(root, file), 'utf8')
    for (const pattern of forbidden) assert.doesNotMatch(source, pattern, `${file} contains ${pattern}`)
    if (/\brenameSync\s*\(/.test(source)) renameFiles.push(file)
  }
  assert.deepEqual(renameFiles, ['cleanup.js'])
})

test('no outbound network calls in plugin source', () => {
  const sources = [
    ...fs.readdirSync('server').filter((file) => file.endsWith('.js')).map((file) => path.join('server', file)),
    ...fs.readdirSync('ui').filter((file) => file.endsWith('.js')).map((file) => path.join('ui', file))
  ]
  const forbidden = [/\bfetch\s*\(/, /http\.request/, /https\.request/, /net\.connect/, /new\s+WebSocket/, /XMLHttpRequest/]
  for (const file of sources) {
    const source = fs.readFileSync(file, 'utf8')
    for (const pattern of forbidden) assert.doesNotMatch(source, pattern, `${file} contains ${pattern}`)
  }
})

test('panel bundle has no external script or stylesheet', () => {
  const html = fs.readFileSync(path.join('dist', 'ui', 'panel.html'), 'utf8')
  assert.doesNotMatch(html, /<script[^>]+src=["']https?:/i)
  assert.doesNotMatch(html, /<link[^>]+href=["']https?:/i)
  assert.match(html, /<style>/)
  assert.match(html, /<script>/)
})
