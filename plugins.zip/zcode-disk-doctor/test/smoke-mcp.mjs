import os from 'node:os'
import path from 'node:path'
import fs from 'node:fs'
import { fileURLToPath } from 'node:url'

import { Client } from '@modelcontextprotocol/sdk/client/index.js'
import { StdioClientTransport } from '@modelcontextprotocol/sdk/client/stdio.js'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'zdd-smoke-'))

const client = new Client({ name: 'zdd-smoke', version: '0.0.0' }, { capabilities: {} })
const transport = new StdioClientTransport({
  command: process.execPath,
  args: [path.join(root, 'dist', 'server.mjs')],
  env: {
    ...process.env,
    ZCODE_PLUGIN_DATA: dataDir,
    ZDD_LANGUAGE: 'zh-CN'
  },
  stderr: 'pipe'
})

await client.connect(transport)
const tools = await client.listTools()
console.log('tools:', tools.tools.map((tool) => tool.name).join(', '))

const resources = await client.listResources()
console.log('resources:', resources.resources.map((resource) => resource.uri).join(', '))

const panel = await client.readResource({ uri: 'ui://disk-doctor/panel.html' })
console.log('panel bytes:', panel.contents?.[0]?.text?.length ?? 0, panel.contents?.[0]?.mimeType)

const report = await client.callTool({ name: 'get_report', arguments: {} })
const payload = report.structuredContent
console.log('data bytes:', payload?.totals?.bytes, 'files:', payload?.totals?.files)
console.log('areas:', payload?.areas?.map((area) => `${area.id}:${area.bytes}`).join(' '))
console.log('categories:', payload?.categories?.length)
console.log('warnings:', payload?.warnings?.slice(0, 3))

const quick = await client.callTool({ name: 'disk_report', arguments: { scope: 'summary', write: false } })
console.log('markdown head:', String(quick.content?.[0]?.text ?? '').split('\n').slice(0, 4).join(' | '))

await client.close()
fs.rmSync(dataDir, { recursive: true, force: true })
