import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

export const OLD = new Date('2024-01-02T03:04:05Z')

export function makeFixture () {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'zdd-fixture-'))
  return {
    root,
    zcode: path.join(root, 'zcode'),
    desktop: path.join(root, 'desktop'),
    plugins: path.join(root, 'plugins'),
    app: path.join(root, 'app'),
    chromium: path.join(root, 'chromium'),
    updater: path.join(root, 'updater'),
    temp: path.join(root, 'temp'),
    quarantine: path.join(root, 'quarantine'),
    data: path.join(root, 'plugin-data')
  }
}

export function writeFile (file, bytes, mtime = OLD) {
  fs.mkdirSync(path.dirname(file), { recursive: true })
  fs.writeFileSync(file, 'x'.repeat(bytes))
  fs.utimesSync(file, mtime, mtime)
  return file
}

export function makeDirs (dir) {
  fs.mkdirSync(dir, { recursive: true })
  return dir
}

export function makeEnv (fixture) {
  return {
    zcodeHome: fixture.zcode,
    desktopHome: fixture.desktop,
    tempDir: fixture.temp,
    appRoot: fixture.app,
    appRootSource: 'config',
    chromiumDir: fixture.chromium,
    chromiumSessionDir: path.join(fixture.chromium, 'session'),
    updaterDir: fixture.updater,
    pluginsRoot: fixture.plugins,
    pluginsLinkPath: null,
    pluginsIsLink: false,
    globalCli: null
  }
}

export function makeSettings (fixture, overrides = {}) {
  return {
    topN: 10,
    followSymlinks: false,
    allowOpenFolder: true,
    allowOpenFolderSensitive: false,
    allowCleanup: true,
    excludeGlobs: [],
    language: 'zh-CN',
    zcodeHome: fixture.zcode,
    desktopHome: fixture.desktop,
    appDir: fixture.app,
    reportDir: path.join(fixture.data, 'reports'),
    quarantineDir: fixture.quarantine,
    pluginData: fixture.data,
    overrides: {},
    sources: {},
    warning: null,
    ...overrides
  }
}

export function populate (fixture) {
  writeFile(path.join(fixture.zcode, 'cli', 'db', 'db.sqlite'), 100)
  writeFile(path.join(fixture.zcode, 'cli', 'artifacts', 'sess_a', 'file'), 200)
  writeFile(path.join(fixture.zcode, 'cli', 'log', 'a.log'), 300)
  writeFile(path.join(fixture.zcode, 'cli', 'exec', 'sess_a', 'call.log'), 400)
  writeFile(path.join(fixture.zcode, 'cli', 'image-cache', 'sess_a', 'img'), 50)
  writeFile(path.join(fixture.zcode, 'cli', 'plugins.old', 'cache', 'm', 'p', '1', 'f'), 60)
  writeFile(path.join(fixture.zcode, 'cli', 'plugins.old', 'marketplaces', 'mm', 'f'), 25)
  writeFile(path.join(fixture.zcode, 'cli', 'plugins.old', 'data', 'p', 'f'), 70)
  writeFile(path.join(fixture.zcode, 'v2', 'setting.json'), 10)
  writeFile(path.join(fixture.zcode, 'v2', 'logs', 'a.log'), 80)
  writeFile(path.join(fixture.zcode, 'v2', 'visualizations', 'x.html'), 90)
  writeFile(path.join(fixture.zcode, 'backup', 'b'), 20)
  writeFile(path.join(fixture.zcode, 'otherfile'), 5)

  writeFile(path.join(fixture.desktop, 'v2', 'logs', 'd.log'), 110)
  writeFile(path.join(fixture.desktop, 'v2', 'tasks-index.sqlite'), 120)
  writeFile(path.join(fixture.desktop, 'v2', 'visualizations', 'x.html'), 90)
  writeFile(path.join(fixture.desktop, 'workspace', 'w'), 130)
  writeFile(path.join(fixture.desktop, 'backup', 'b'), 20)
  writeFile(path.join(fixture.desktop, 'feedback', 'logs', 'f.log'), 40)

  writeFile(path.join(fixture.plugins, 'cache', 'm', 'p', '1', 'f'), 140)
  writeFile(path.join(fixture.plugins, 'marketplaces', 'mm', 'f'), 20)
  writeFile(path.join(fixture.plugins, 'data', 'p', 'd'), 30)

  writeFile(path.join(fixture.app, 'resources', 'app.asar'), 1000)
  writeFile(path.join(fixture.chromium, 'session', 'Cache', 'c'), 150)
  writeFile(path.join(fixture.chromium, 'session', 'Local Storage', 'l'), 160)
  writeFile(path.join(fixture.chromium, 'session', 'Partitions', 'zcode-embedded-browser', 'Cache', 'x'), 30)
  writeFile(path.join(fixture.updater, 'pending', 'u'), 170)
  writeFile(path.join(fixture.updater, 'installer.exe'), 180)

  writeFile(path.join(fixture.temp, 'zcode-sess', 't'), 180)
  writeFile(path.join(fixture.temp, 'zcode-fresh', 't'), 190, new Date())
  writeFile(path.join(fixture.temp, 'other', 't'), 200)
}
