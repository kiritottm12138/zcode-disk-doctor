from playwright.sync_api import sync_playwright

URL = "http://127.0.0.1:8765/test/panel-harness.html"

with sync_playwright() as p:
    browser = p.chromium.launch(channel="msedge", headless=True)
    page = browser.new_page(viewport={"width": 430, "height": 1000})
    errors = []
    page.on("console", lambda msg: errors.append(f"{msg.type}: {msg.text}") if msg.type == "error" else None)
    page.on("pageerror", lambda err: errors.append(f"pageerror: {err}"))
    page.goto(URL, wait_until="networkidle")
    frame_locator = page.frame_locator("#panel")
    frame_locator.locator(".zdd-hero-value").wait_for(timeout=15000)
    page.wait_for_timeout(600)

    panel_frame = next(f for f in page.frames if "panel.html" in f.url)
    panel_frame.locator("body").screenshot(path="test/panel-full-overview.png")
    print("overview captured", panel_frame.locator(".area-card").count())

    # Enable cleanup: two deliberate clicks in the drawer.
    frame_locator.locator("button[aria-label='设置']").click()
    frame_locator.locator(".drawer").wait_for(timeout=5000)
    perm = frame_locator.locator(".perm-btn")
    perm.click()
    page.wait_for_timeout(200)
    print("armed:", perm.inner_text())
    perm.click()
    page.wait_for_timeout(600)
    print("permission:", perm.inner_text())
    page.screenshot(path="test/panel-settings-enabled.png", full_page=False)

    frame_locator.locator(".drawer-head button").click()
    page.wait_for_timeout(300)

    frame_locator.get_by_text("看看会移动什么").click()
    frame_locator.get_by_text("会移动").first.wait_for(timeout=15000)
    page.wait_for_timeout(400)
    frame_locator.get_by_text("移动到隔离区").click()
    page.wait_for_timeout(200)
    frame_locator.get_by_text("确定，移动").click()
    page.wait_for_timeout(800)
    print("notice:", frame_locator.locator(".notice").inner_text())
    print("batches:", frame_locator.locator(".batch-row").count())
    panel_frame.locator("body").screenshot(path="test/panel-full-cleanup.png")

    print("console errors:", errors[:10])
    browser.close()
