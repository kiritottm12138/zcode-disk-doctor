import {
  App,
  applyDocumentTheme,
  applyHostFonts,
  applyHostStyleVariables
} from '@modelcontextprotocol/ext-apps'

const app = new App({ name: 'ZCode Disk Doctor', version: '0.1.0' }, {}, { autoResize: true })

const STR = {
  zh: {
    title: '空间体检',
    subtitle: '看清 ZCode 的数据、程序与缓存占用；三个区独立统计，绝不相加。',
    refresh: '刷新',
    settings: '设置',
    close: '关闭',
    overview: '总览',
    plugins: '按插件',
    sessions: '按会话',
    data: 'ZCode 数据',
    app: 'ZCode 程序',
    cache: '系统缓存',
    files: '个文件',
    scanned: '扫描用时',
    seconds: '秒',
    category: '类别',
    items: '项',
    open: '打开',
    copy: '复制路径',
    copied: '路径已复制',
    loading: '正在读取…',
    detail: '明细',
    loadMore: '加载更多',
    noItems: '这一部分没有条目',
    reclaim: '处理建议',
    warnings: '注意事项',
    cleanup: '清理（可撤销）',
    cleanupIntro: '只处理 🟢 可以安全清理的内容：日志、临时文件、图片缓存、旧插件缓存与更新包。移动只是改名到隔离目录，随时可以撤销；插件从不删除任何文件。',
    preview: '看看会移动什么',
    previewing: '正在预演…',
    willMove: '会移动',
    skipped: '最近还在使用，已跳过',
    excluded: '未列入',
    movedWithFailures: '已移动 {moved} 项，{failed} 项失败（{reason}）。',
    restoredWithFailures: '已恢复 {restored} 项，{failed} 项失败（{reason}）。',
    cleanupSpaceNote: '移动到隔离区只是改名，不会立即释放磁盘空间；确认不再需要后请手动清空隔离区。',
    move: '移动到隔离区',
    moveDisabled: '先在 ⚙ 里打开「允许清理」，这个按钮才会生效。',
    confirmMove: '确定，移动',
    cancel: '取消',
    confirmQuestion: '确定移动这 {n} 项（{size}）吗？',
    moving: '正在移动…',
    moved: '已移动到隔离区，可撤销。',
    nothingToMove: '现在没有可以安全清理的内容。',
    stale: '清单已经变化，请重新预演。',
    batches: '隔离批次',
    noBatches: '隔离目录里还没有批次。',
    undo: '撤销',
    undoing: '正在撤销…',
    undone: '已恢复。',
    openQuarantine: '打开隔离目录',
    openReports: '打开报告目录',
    cleanupPermission: '允许清理（移动到隔离区）',
    cleanupPermissionOn: '已开启',
    cleanupPermissionOff: '已关闭',
    cleanupPermissionWarn: '这是唯一会让文件移动的开关。打开后仍需要你在面板上二次确认；插件不会删除任何文件。',
    armCleanup: '确认打开清理',
    allowOpen: '允许打开安全位置',
    allowOpenSensitive: '允许打开敏感位置',
    followSymlinks: '跟随符号链接',
    topN: '每类条目数',
    excludeGlobs: '额外排除（逗号分隔）',
    language: '界面语言',
    auto: '自动',
    save: '保存',
    reset: '恢复默认',
    saved: '设置已保存。',
    resetDone: '已恢复默认设置。',
    paths: '路径',
    dataHome: '数据目录',
    desktopHome: '桌面端数据',
    appRoot: '程序目录',
    reportDir: '报告目录',
    quarantineDir: '隔离目录',
    pluginsRoot: '插件目录',
    chromiumDir: '浏览器数据',
    updaterDir: '更新缓存',
    safetyLegend: '颜色说明',
    safe: '可以安全清理',
    care: '要谨慎处理',
    keep: '不要动',
    safeHint: 'ZCode 会按需重新生成，清理不影响使用。',
    careHint: '能用正确方法省下，例如卸载插件，而不是手删文件。',
    keepHint: 'ZCode 运行需要，或属于你的会话内容；不要动。',
    error: '出错了',
    noReport: '还没有扫描结果。',
    note: '三个区各自独立统计，不能相加。程序与系统缓存不属于你的 ZCode 数据。',
    pluginView: '插件相关',
    sessionView: '会话相关',
    health: 'ZCode 数据',
    dismiss: '知道了'
  },
  en: {
    title: 'Disk Doctor',
    subtitle: 'See where ZCode’s data, application and caches live. Three areas, never summed.',
    refresh: 'Refresh',
    settings: 'Settings',
    close: 'Close',
    overview: 'Overview',
    plugins: 'By plugin',
    sessions: 'By session',
    data: 'ZCode data',
    app: 'ZCode application',
    cache: 'System caches',
    files: 'files',
    scanned: 'Scanned in',
    seconds: 's',
    category: 'Category',
    items: 'items',
    open: 'Open',
    copy: 'Copy path',
    copied: 'Path copied',
    loading: 'Loading…',
    detail: 'Details',
    loadMore: 'Load more',
    noItems: 'Nothing in this category',
    reclaim: 'What happens if removed',
    warnings: 'Notes',
    cleanup: 'Cleanup (reversible)',
    cleanupIntro: 'Only 🟢 safe items: logs, temp files, image cache, old plugin cache and updater downloads. A move is a rename into quarantine and can be undone; the plugin never deletes anything.',
    preview: 'Preview what would move',
    previewing: 'Previewing…',
    willMove: 'Would move',
    skipped: 'Skipped because they were used recently',
    excluded: 'Excluded',
    movedWithFailures: 'Moved {moved} items; {failed} failed ({reason}).',
    restoredWithFailures: 'Restored {restored} items; {failed} failed ({reason}).',
    cleanupSpaceNote: 'A move only renames files into quarantine; it does not free disk space. Empty the quarantine manually when you are sure.',
    move: 'Move to quarantine',
    moveDisabled: 'Turn on “Allow cleanup” in ⚙ first.',
    confirmMove: 'Confirm move',
    cancel: 'Cancel',
    confirmQuestion: 'Move these {n} items ({size})?',
    moving: 'Moving…',
    moved: 'Moved to quarantine. You can undo it.',
    nothingToMove: 'Nothing safe to clean right now.',
    stale: 'The list changed. Preview again.',
    batches: 'Quarantine batches',
    noBatches: 'No batches in quarantine yet.',
    undo: 'Undo',
    undoing: 'Undoing…',
    undone: 'Restored.',
    openQuarantine: 'Open quarantine',
    openReports: 'Open reports',
    cleanupPermission: 'Allow cleanup (move to quarantine)',
    cleanupPermissionOn: 'On',
    cleanupPermissionOff: 'Off',
    cleanupPermissionWarn: 'This is the only switch that lets files move. You still confirm every move in the panel; the plugin never deletes anything.',
    armCleanup: 'Confirm enable cleanup',
    allowOpen: 'Allow opening safe locations',
    allowOpenSensitive: 'Allow opening sensitive locations',
    followSymlinks: 'Follow symlinks',
    topN: 'Items per category',
    excludeGlobs: 'Extra exclusions (comma separated)',
    language: 'Language',
    auto: 'Auto',
    save: 'Save',
    reset: 'Reset',
    saved: 'Settings saved.',
    resetDone: 'Settings reset.',
    paths: 'Paths',
    dataHome: 'Data folder',
    desktopHome: 'Desktop data',
    appRoot: 'Application',
    reportDir: 'Reports',
    quarantineDir: 'Quarantine',
    pluginsRoot: 'Plugins',
    chromiumDir: 'Browser data',
    updaterDir: 'Updater cache',
    safetyLegend: 'Legend',
    safe: 'Safe to clean',
    care: 'Handle with care',
    keep: 'Leave alone',
    safeHint: 'ZCode regenerates it; cleaning does not affect use.',
    careHint: 'Can be reclaimed the right way, e.g. uninstall a plugin instead of deleting files.',
    keepHint: 'Needed by ZCode or your own conversations. Do not touch.',
    error: 'Error',
    noReport: 'No scan result yet.',
    note: 'The three areas are counted independently and never summed. The application and system caches are not your ZCode data.',
    pluginView: 'Plugin-related',
    sessionView: 'Session-related',
    health: 'ZCode data',
    dismiss: 'Dismiss'
  }
}

const state = {
  language: 'zh-CN',
  report: null,
  settings: null,
  batches: [],
  view: 'overview',
  expanded: new Set(),
  details: new Map(),
  plan: null,
  planItems: [],
  planNext: null,
  planArmed: false,
  cleanupPermissionArmed: false,
  settingsOpen: false,
  notice: null,
  busy: null
}

function t (key) {
  return STR[state.language]?.[key] ?? STR.zh[key] ?? key
}

function formatBytes (bytes) {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B'
  const units = [
    { suffix: 'TB', scale: 1024 ** 4 },
    { suffix: 'GB', scale: 1024 ** 3 },
    { suffix: 'MB', scale: 1024 ** 2 },
    { suffix: 'KB', scale: 1024 }
  ]
  for (const unit of units) {
    if (bytes >= unit.scale) {
      const value = bytes / unit.scale
      const digits = value >= 100 ? 0 : value >= 10 ? 1 : 2
      return `${value.toFixed(digits)} ${unit.suffix}`
    }
  }
  return `${bytes} B`
}

function h (tag, props = {}, ...children) {
  const node = document.createElement(tag)
  for (const [key, value] of Object.entries(props)) {
    if (value === undefined || value === null || value === false) continue
    if (key === 'class') node.className = value
    else if (key === 'text') node.textContent = String(value)
    else if (key === 'style') node.setAttribute('style', value)
    else if (key === 'dataset') Object.assign(node.dataset, value)
    else if (key === 'onclick') node.addEventListener('click', value)
    else if (key === 'onchange') node.addEventListener('change', value)
    else if (key === 'oninput') node.addEventListener('input', value)
    else if (value === true) node.setAttribute(key, '')
    else node.setAttribute(key, String(value))
  }
  for (const child of children.flat(Infinity)) {
    if (child === undefined || child === null) continue
    node.appendChild(typeof child === 'string' ? document.createTextNode(child) : child)
  }
  return node
}

function label (entity) {
  return state.language === 'en-US' && entity.labelEn ? entity.labelEn : entity.label
}

function reclaim (category) {
  const text = category.reclaim
  if (!text) return ''
  if (typeof text === 'string') return text
  return state.language === 'en-US' ? text.en : text.zh
}

function plainText (text) {
  return String(text ?? '').replace(/\*\*(.+?)\*\*/g, '$1')
}

function safetyLabel (safety) {
  return safety === 'safe' ? t('safe') : safety === 'care' ? t('care') : t('keep')
}

function setNotice (kind, text) {
  state.notice = text ? { kind, text } : null
}

async function callTool (name, args = {}) {
  const result = await app.callServerTool({ name, arguments: args })
  if (result?.isError) {
    const message = result.content?.find?.((item) => item.type === 'text')?.text ?? `${name} failed`
    throw new Error(message)
  }
  let data = result?.structuredContent
  if (typeof data === 'string') {
    try { data = JSON.parse(data) } catch { /* leave as-is */ }
  }
  return data ?? {}
}

async function withBusy (labelText, fn) {
  state.busy = labelText
  render()
  try {
    return await fn()
  } catch (error) {
    setNotice('error', String(error?.message ?? error))
  } finally {
    state.busy = null
    render()
  }
}

function applyHostContext (context) {
  if (!context) return
  const theme = context.theme === 'dark' ? 'dark' : 'light'
  try {
    applyDocumentTheme(theme)
  } catch {
    document.documentElement.dataset.theme = theme
  }
  if (context.styles?.variables) {
    try { applyHostStyleVariables(context.styles.variables) } catch { /* optional */ }
  }
  if (context.styles?.css?.fonts) {
    try { applyHostFonts(context.styles.css.fonts) } catch { /* optional */ }
  }
  const locale = context.locale ?? navigator.language ?? ''
  if (state.settings?.values?.language === 'auto' || state.settings?.values?.language === undefined) {
    state.language = /^zh/i.test(locale) ? 'zh-CN' : 'en-US'
  }
}

function resolveLanguage (settings) {
  const choice = settings?.values?.language
  if (choice === 'zh-CN' || choice === 'en-US') {
    state.language = choice
    return
  }
  const locale = app.getHostContext()?.locale ?? navigator.language ?? ''
  state.language = /^zh/i.test(locale) ? 'zh-CN' : 'en-US'
}

async function loadSettings () {
  const data = await callTool('get_settings')
  state.settings = data
  resolveLanguage(data)
  return data
}

async function loadReport () {
  const data = await callTool('get_report')
  state.report = data
  state.details.clear()
  return data
}

async function loadBatches () {
  const data = await callTool('list_quarantine')
  state.batches = Array.isArray(data.batches) ? data.batches : []
  return state.batches
}

async function loadCategory (categoryId, offset = 0) {
  const data = await callTool('get_category', { categoryId, offset, limit: 25 })
  const previous = state.details.get(categoryId)
  const items = offset === 0 || previous === undefined
    ? data.items
    : [...previous.items, ...data.items]
  state.details.set(categoryId, {
    category: data.category,
    items,
    next: data.next,
    offset: data.offset
  })
}

async function toggleCategory (categoryId) {
  if (state.expanded.has(categoryId)) {
    state.expanded.delete(categoryId)
    render()
    return
  }
  state.expanded.add(categoryId)
  render()
  if (!state.details.has(categoryId)) {
    await withBusy(t('loading'), async () => {
      await loadCategory(categoryId, 0)
    })
  }
}

async function loadPlan (offset = 0) {
  const data = await callTool('plan_cleanup', { offset, limit: 100 })
  if (offset === 0) {
    state.plan = data
    state.planItems = data.items ?? []
  } else {
    state.planItems.push(...(data.items ?? []))
    state.plan.next = data.next
  }
  state.planNext = data.next
  state.planArmed = false
  // A fresh preview always requires a fresh confirmation, even if the previous
  // plan had been armed. This closes the window where a stale plan could be
  // followed by a one-click move.
  state.cleanupPermissionArmed = false
}

async function openPath (target) {
  await withBusy(t('loading'), async () => {
    await callTool('open_folder', { path: target })
  })
}

async function copyPath (target) {
  try {
    await navigator.clipboard.writeText(target)
    setNotice('success', t('copied'))
  } catch {
    const area = document.createElement('textarea')
    area.value = target
    area.style.position = 'fixed'
    area.style.opacity = '0'
    document.body.appendChild(area)
    area.select()
    try { document.execCommand('copy') } catch { /* ignore */ }
    area.remove()
    setNotice('success', t('copied'))
  }
  render()
}

async function saveSettings (patch) {
  await withBusy(t('loading'), async () => {
    const data = await callTool('set_settings', patch)
    state.settings.values = data.values
    state.cleanupPermissionArmed = false
    setNotice('success', t('saved'))
    await loadReport()
    state.plan = null
    state.planItems = []
    state.planNext = null
  })
}

async function resetSettings () {
  await withBusy(t('loading'), async () => {
    await callTool('reset_settings')
    await loadSettings()
    setNotice('success', t('resetDone'))
    await loadReport()
    state.plan = null
    state.planItems = []
    state.planNext = null
  })
}

async function performCleanup () {
  if (!state.plan) return
  if (!state.cleanupPermissionArmed && state.settings?.values?.allowCleanup === true) {
    state.cleanupPermissionArmed = true
    state.planArmed = true
    render()
    return
  }
  await withBusy(t('moving'), async () => {
    const result = await callTool('perform_cleanup', {
      confirm: true,
      expectedBytes: state.plan.totalBytes,
      expectedItemCount: state.plan.itemCount
    })
    if (result?.reason === 'stale-plan') {
      setNotice('error', t('stale'))
      state.cleanupPermissionArmed = false
      state.planArmed = false
      await loadPlan(0)
      return
    }
    const failed = Number(result?.failureCount ?? 0)
    if (result?.status === 'nothing-to-move') {
      setNotice('success', t('nothingToMove'))
    } else if (failed > 0 || result?.ok === false) {
      setNotice('error', t('movedWithFailures')
        .replace('{moved}', String(result?.itemCount ?? 0))
        .replace('{failed}', String(failed))
        .replace('{reason}', String(result?.failures?.[0]?.reason ?? 'unknown')))
    } else {
      setNotice('success', t('moved'))
    }
    state.plan = null
    state.planItems = []
    state.planNext = null
    state.planArmed = false
    state.cleanupPermissionArmed = false
    await Promise.all([loadReport(), loadBatches()])
  })
}

async function undoBatch (batchId) {
  await withBusy(t('undoing'), async () => {
    const result = await callTool('undo_cleanup', { batchId })
    const failed = Number(result?.failureCount ?? 0)
    if (failed > 0 || result?.ok === false) {
      setNotice('error', t('restoredWithFailures')
        .replace('{restored}', String(result?.restoredCount ?? 0))
        .replace('{failed}', String(failed))
        .replace('{reason}', String(result?.failures?.[0]?.reason ?? 'unknown')))
    } else {
      setNotice('success', t('undone'))
    }
    await Promise.all([loadReport(), loadBatches(), loadPlan(0)])
  })
}

function header () {
  const settings = state.settings?.values ?? {}
  const paths = state.settings?.paths ?? {}
  const heroBytes = state.report?.totals?.bytes ?? 0
  const heroFiles = state.report?.totals?.files ?? 0
  const duration = state.report?.durationMs ?? 0
  return h('header', { class: 'zdd-head' },
    h('div', { class: 'zdd-head-main' },
      h('div', { class: 'zdd-title-row' },
        h('h1', { text: t('title') }),
        state.busy ? h('span', { class: 'zdd-pill busy', text: state.busy }) : null
      ),
      h('p', { class: 'zdd-sub', text: t('subtitle') })
    ),
    h('div', { class: 'zdd-actions' },
      h('button', {
        class: 'icon-btn',
        title: t('refresh'),
        'aria-label': t('refresh'),
        disabled: state.busy !== null,
        onclick: () => refreshAll()
      }, '⟳'),
      h('button', {
        class: 'icon-btn',
        title: t('settings'),
        'aria-label': t('settings'),
        onclick: () => { state.settingsOpen = true; render() }
      }, '⚙')
    ),
    h('div', { class: 'zdd-hero' },
      h('div', { class: 'zdd-hero-value', text: formatBytes(heroBytes) }),
      h('div', { class: 'zdd-hero-meta' },
        t('health'),
        ' · ',
        `${heroFiles.toLocaleString('en-US')} ${t('files')}`,
        ' · ',
        `${t('scanned')} ${(duration / 1000).toFixed(1)} ${t('seconds')}`
      ),
      h('div', { class: 'zdd-hero-paths' },
        h('span', { class: 'mono', text: paths.zcodeHome ?? '—' }),
        paths.desktopHome && paths.desktopHome !== paths.zcodeHome
          ? h('span', { class: 'mono', text: paths.desktopHome })
          : null
      ),
      h('div', { class: 'zdd-hero-note', text: t('note') })
    )
  )
}

function tabs () {
  const items = [
    ['overview', t('overview')],
    ['plugins', t('plugins')],
    ['sessions', t('sessions')]
  ]
  return h('nav', { class: 'zdd-tabs', role: 'tablist' },
    ...items.map(([id, text]) => h('button', {
      class: `zdd-tab ${state.view === id ? 'active' : ''}`,
      role: 'tab',
      'aria-selected': state.view === id ? 'true' : 'false',
      onclick: () => { state.view = id; render() }
    }, text))
  )
}

function categoryRow (category, maxBytes) {
  const expanded = state.expanded.has(category.id)
  const percent = maxBytes > 0 ? Math.max(2, Math.round((category.bytes / maxBytes) * 100)) : 0
  const detail = state.details.get(category.id)
  const row = h('button', {
    class: 'cat-row',
    'aria-expanded': expanded ? 'true' : 'false',
    onclick: () => toggleCategory(category.id)
  },
    h('span', { class: `dot ${category.safety}`, title: safetyLabel(category.safety) }),
    h('span', { class: 'cat-label', text: label(category) }),
    h('span', { class: 'cat-bar' },
      h('span', { class: `cat-bar-fill ${category.safety}`, style: `width:${percent}%` })
    ),
    h('span', { class: 'cat-size', text: formatBytes(category.bytes) }),
    h('span', { class: 'cat-count', text: category.itemCount ? String(category.itemCount) : '' }),
    h('span', { class: 'chevron', text: expanded ? '▾' : '▸' })
  )

  const children = [row]
  if (expanded) {
    const panel = h('div', { class: 'cat-detail' })
    const note = reclaim(category)
    if (note) panel.appendChild(h('p', { class: 'reclaim', text: note }))
    if (!detail) {
      panel.appendChild(h('p', { class: 'muted', text: t('loading') }))
    } else {
      if (detail.items.length === 0) {
        panel.appendChild(h('p', { class: 'muted', text: t('noItems') }))
      } else {
        panel.appendChild(itemList(detail.items))
      }
      if (detail.next !== null && detail.next !== undefined) {
        panel.appendChild(h('button', {
          class: 'small-btn',
          onclick: (event) => {
            event.stopPropagation()
            withBusy(t('loading'), () => loadCategory(category.id, detail.next))
          }
        }, t('loadMore')))
      }
    }
    children.push(panel)
  }
  return h('div', { class: 'cat' }, ...children)
}

function itemList (items) {
  return h('div', { class: 'item-list' },
    ...items.map((item) => h('div', { class: 'item-row' },
      h('div', { class: 'item-main' },
        h('div', { class: 'item-path mono', title: item.path, text: item.path }),
        h('div', { class: 'item-meta' },
          formatBytes(item.bytes),
          ' · ',
          `${item.files} ${t('files')}`,
          item.note ? ` · ${item.note}` : ''
        )
      ),
      h('div', { class: 'item-actions' },
        h('button', {
          class: 'small-btn',
          title: t('open'),
          onclick: () => openPath(item.path)
        }, '↗'),
        h('button', {
          class: 'small-btn',
          title: t('copy'),
          onclick: () => copyPath(item.path)
        }, '⧉')
      )
    ))
  )
}

function areaCard (area, categories) {
  const maxBytes = Math.max(1, ...categories.map((category) => category.bytes))
  return h('section', { class: 'area-card' },
    h('div', { class: 'area-head' },
      h('div', { class: 'area-title' },
        h('span', { class: `area-dot ${area.id}` }),
        h('h2', { text: label(area) })
      ),
      h('div', { class: 'area-size', text: formatBytes(area.totals?.bytes ?? categories.reduce((sum, category) => sum + category.bytes, 0)) })
    ),
    area.notes?.length ? h('p', { class: 'area-note', text: area.notes.join('；') }) : null,
    h('div', { class: 'cat-list' },
      ...categories.filter((category) => category.bytes > 0 || category.itemCount > 0)
        .map((category) => categoryRow(category, maxBytes))
    )
  )
}

function filteredCategories () {
  const categories = state.report?.categories ?? []
  if (state.view === 'plugins') {
    return categories.filter((category) => category.id.startsWith('plugin-'))
  }
  if (state.view === 'sessions') {
    const ids = new Set(['artifacts', 'agent-outputs', 'exec-temp', 'image-cache', 'model-io', 'logs', 'visualizations', 'temp-spill'])
    return categories.filter((category) => ids.has(category.id))
  }
  return categories
}

function syntheticArea (categories) {
  return {
    id: 'data',
    label: state.view === 'plugins' ? t('pluginView') : t('sessionView'),
    labelEn: state.view === 'plugins' ? t('pluginView') : t('sessionView'),
    totals: { bytes: categories.reduce((sum, category) => sum + category.bytes, 0) },
    notes: [],
    categories: categories.map((category) => category.id)
  }
}

function mainContent () {
  if (!state.report) {
    return h('main', { class: 'zdd-main' }, h('p', { class: 'muted', text: t('noReport') }))
  }
  const categories = filteredCategories()
  if (state.view !== 'overview') {
    return h('main', { class: 'zdd-main' },
      areaCard(syntheticArea(categories), categories)
    )
  }
  const areas = state.report.areas ?? []
  return h('main', { class: 'zdd-main' },
    ...areas.map((area) => {
      const own = categories.filter((category) => category.area === area.id)
      return areaCard(area, own)
    })
  )
}

function cleanupBox () {
  const values = state.settings?.values ?? {}
  const allowCleanup = values.allowCleanup === true
  const plan = state.plan
  const children = [
    h('div', { class: 'section-head' },
      h('h2', { text: t('cleanup') }),
      h('div', { class: 'section-actions' },
        h('button', {
          class: 'small-btn',
          disabled: state.busy !== null,
          onclick: () => withBusy(t('previewing'), () => loadPlan(0))
        }, t('preview')),
        h('button', {
          class: 'small-btn',
          onclick: () => withBusy(t('loading'), () => callTool('open_quarantine'))
        }, t('openQuarantine'))
      )
    ),
    h('p', { class: 'section-note', text: t('cleanupIntro') }),
    h('p', { class: 'section-note', text: t('cleanupSpaceNote') })
  ]

  if (plan) {
    children.push(h('div', { class: 'plan-summary' },
      h('strong', { text: `${t('willMove')} ${plan.itemCount} ${t('items')} · ${formatBytes(plan.totalBytes)}` }),
      plan.skippedCount > 0
        ? h('span', { class: 'muted', text: ` · ${t('skipped')} ${plan.skippedCount} (${formatBytes(plan.skippedBytes)})` })
        : null,
      plan.excludedCount > 0
        ? h('span', { class: 'muted', text: ` · ${t('excluded')} ${plan.excludedCount} (${formatBytes(plan.excludedBytes)})` })
        : null
    ))
    if (plan.warnings?.length) {
      children.push(h('details', { class: 'warnings' },
        h('summary', { text: t('warnings') }),
        h('ul', {}, ...plan.warnings.map((warning) => h('li', { text: plainText(warning) })))
      ))
    }
    if (state.planItems.length > 0) {
      children.push(itemList(state.planItems.map((item) => ({
        path: item.path,
        bytes: item.bytes,
        files: item.files,
        note: item.note
      }))))
    } else {
      children.push(h('p', { class: 'muted', text: t('nothingToMove') }))
    }
    if (plan.next !== null && plan.next !== undefined) {
      children.push(h('button', {
        class: 'small-btn',
        disabled: state.busy !== null,
        onclick: () => withBusy(t('previewing'), () => loadPlan(plan.next))
      }, t('loadMore')))
    }

    if (!allowCleanup) {
      children.push(h('p', { class: 'notice warn', text: t('moveDisabled') }))
    } else if (plan.itemCount > 0) {
      if (state.planArmed) {
        children.push(h('div', { class: 'confirm-row' },
          h('span', {
            text: t('confirmQuestion')
              .replace('{n}', String(plan.itemCount))
              .replace('{size}', formatBytes(plan.totalBytes))
          }),
          h('button', {
            class: 'danger-btn',
            disabled: state.busy !== null,
            onclick: () => performCleanup()
          }, t('confirmMove')),
          h('button', {
            class: 'small-btn',
            onclick: () => { state.planArmed = false; state.cleanupPermissionArmed = false; render() }
          }, t('cancel'))
        ))
      } else {
        children.push(h('button', {
          class: 'primary-btn',
          disabled: state.busy !== null,
          onclick: () => performCleanup()
        }, t('move')))
      }
    }
  }

  return h('section', { class: 'zdd-section cleanup-section' }, ...children)
}

function batchesBox () {
  return h('section', { class: 'zdd-section' },
    h('div', { class: 'section-head' },
      h('h2', { text: t('batches') }),
      h('button', {
        class: 'small-btn',
        onclick: () => withBusy(t('loading'), async () => { await loadBatches(); render() })
      }, t('refresh'))
    ),
    state.batches.length === 0
      ? h('p', { class: 'muted', text: t('noBatches') })
      : h('div', { class: 'batch-list' },
        ...state.batches.map((batch) => h('div', { class: 'batch-row' },
          h('div', { class: 'batch-main' },
            h('div', { class: 'batch-id mono', text: batch.id }),
            h('div', { class: 'item-meta' },
              `${batch.itemCount} ${t('items')} · ${formatBytes(batch.bytes)} · ${batch.status}`,
              batch.failures ? ` · ${batch.failures} failures` : ''
            )
          ),
          h('button', {
            class: 'small-btn',
            disabled: state.busy !== null,
            onclick: () => undoBatch(batch.id)
          }, t('undo'))
        ))
      )
  )
}

function legend () {
  return h('footer', { class: 'zdd-legend' },
    h('h2', { text: t('safetyLegend') }),
    h('div', { class: 'legend-grid' },
      h('div', { class: 'legend-item' },
        h('span', { class: 'dot safe' }),
        h('div', {},
          h('strong', { text: t('safe') }),
          h('p', { text: t('safeHint') })
        )
      ),
      h('div', { class: 'legend-item' },
        h('span', { class: 'dot care' }),
        h('div', {},
          h('strong', { text: t('care') }),
          h('p', { text: t('careHint') })
        )
      ),
      h('div', { class: 'legend-item' },
        h('span', { class: 'dot keep' }),
        h('div', {},
          h('strong', { text: t('keep') }),
          h('p', { text: t('keepHint') })
        )
      )
    )
  )
}

function pathRow (text, value) {
  if (!value) return null
  return h('div', { class: 'path-row' },
    h('span', { class: 'path-label', text }),
    h('span', { class: 'path-value mono', title: value, text: value }),
    h('button', { class: 'small-btn', title: t('copy'), onclick: () => copyPath(value) }, '⧉')
  )
}

function settingsDrawer () {
  if (!state.settingsOpen) return null
  const values = state.settings?.values ?? {}
  const paths = state.settings?.paths ?? {}
  const allowCleanup = values.allowCleanup === true

  const cleanupButton = h('button', {
    class: `perm-btn ${allowCleanup ? 'on' : 'off'}`,
    onclick: () => {
      if (allowCleanup) {
        saveSettings({ allowCleanup: false })
      } else if (!state.cleanupPermissionArmed) {
        state.cleanupPermissionArmed = true
        render()
      } else {
        saveSettings({ allowCleanup: true })
      }
    }
  }, allowCleanup
    ? `${t('cleanupPermission')} · ${t('cleanupPermissionOn')}`
    : state.cleanupPermissionArmed
      ? t('armCleanup')
      : `${t('cleanupPermission')} · ${t('cleanupPermissionOff')}`)

  const field = (key, input) => h('label', { class: 'field' },
    h('span', { class: 'field-label', text: t(key) }),
    input
  )

  const drawer = h('aside', { class: 'drawer', onclick: (event) => event.stopPropagation() },
    h('div', { class: 'drawer-head' },
      h('h2', { text: t('settings') }),
      h('button', { class: 'icon-btn', onclick: () => { state.settingsOpen = false; render() } }, '×')
    ),
    h('div', { class: 'drawer-body' },
      h('div', { class: 'field-block danger-block' },
        cleanupButton,
        h('p', { class: 'section-note', text: t('cleanupPermissionWarn') })
      ),
      h('div', { class: 'field-block' },
        h('label', { class: 'check' },
          h('input', { type: 'checkbox', id: 'set-allow-open', checked: values.allowOpenFolder === true }),
          h('span', { text: t('allowOpen') })
        ),
        h('label', { class: 'check' },
          h('input', { type: 'checkbox', id: 'set-allow-sensitive', checked: values.allowOpenFolderSensitive === true }),
          h('span', { text: t('allowOpenSensitive') })
        ),
        h('label', { class: 'check' },
          h('input', { type: 'checkbox', id: 'set-follow', checked: values.followSymlinks === true }),
          h('span', { text: t('followSymlinks') })
        ),
        field('topN', h('input', {
          type: 'number',
          id: 'set-topn',
          min: '1',
          max: '100',
          value: String(values.topN ?? 10)
        })),
        field('excludeGlobs', h('input', {
          type: 'text',
          id: 'set-globs',
          value: (values.excludeGlobs ?? []).join(', ')
        })),
        field('language', h('select', { id: 'set-language' },
          h('option', { value: 'auto', selected: values.language === 'auto' }, t('auto')),
          h('option', { value: 'zh-CN', selected: values.language === 'zh-CN' }, '中文'),
          h('option', { value: 'en-US', selected: values.language === 'en-US' }, 'English')
        ))
      ),
      h('div', { class: 'field-block' },
        h('h3', { text: t('paths') }),
        pathRow(t('dataHome'), paths.zcodeHome),
        pathRow(t('desktopHome'), paths.desktopHome),
        pathRow(t('appRoot'), paths.appRoot),
        pathRow(t('pluginsRoot'), paths.pluginsRoot),
        pathRow(t('chromiumDir'), paths.chromiumDir),
        pathRow(t('updaterDir'), paths.updaterDir),
        pathRow(t('reportDir'), paths.reportDir),
        pathRow(t('quarantineDir'), paths.quarantineDir)
      )
    ),
    h('div', { class: 'drawer-foot' },
      h('button', {
        class: 'primary-btn',
        onclick: () => saveSettings(collectSettings())
      }, t('save')),
      h('button', {
        class: 'small-btn',
        onclick: () => resetSettings()
      }, t('reset')),
      h('button', {
        class: 'small-btn',
        onclick: () => withBusy(t('loading'), () => callTool('open_reports'))
      }, t('openReports'))
    )
  )

  return h('div', {
    class: 'drawer-backdrop',
    onclick: () => { state.settingsOpen = false; render() }
  }, drawer)
}

function collectSettings () {
  const patch = {}
  const topN = Number(document.getElementById('set-topn')?.value)
  if (Number.isInteger(topN) && topN >= 1 && topN <= 100) patch.topN = topN
  patch.allowOpenFolder = document.getElementById('set-allow-open')?.checked === true
  patch.allowOpenFolderSensitive = document.getElementById('set-allow-sensitive')?.checked === true
  patch.followSymlinks = document.getElementById('set-follow')?.checked === true
  patch.excludeGlobs = String(document.getElementById('set-globs')?.value ?? '')
    .split(',')
    .map((item) => item.trim())
    .filter((item) => item !== '')
  const language = document.getElementById('set-language')?.value
  if (language === 'auto' || language === 'zh-CN' || language === 'en-US') patch.language = language
  return patch
}

function noticeBar () {
  if (!state.notice) return null
  return h('div', { class: `notice ${state.notice.kind}` },
    h('span', { text: state.notice.text }),
    h('button', {
      class: 'notice-close',
      onclick: () => { state.notice = null; render() }
    }, '×')
  )
}

function render () {
  const root = document.getElementById('app')
  if (!root) return
  document.title = t('title')
  root.replaceChildren(
    h('div', { class: 'zdd' },
      noticeBar(),
      header(),
      tabs(),
      mainContent(),
      cleanupBox(),
      batchesBox(),
      legend(),
      settingsDrawer()
    )
  )
}

async function refreshAll () {
  await withBusy(t('loading'), async () => {
    await Promise.all([loadSettings(), loadReport(), loadBatches()])
    state.plan = null
    state.planItems = []
    state.planNext = null
    state.planArmed = false
  })
}

async function main () {
  app.onhostcontextchanged = (context) => {
    applyHostContext(context)
    render()
  }
  await app.connect()
  applyHostContext(app.getHostContext())
  render()
  await withBusy(t('loading'), async () => {
    await Promise.all([loadSettings(), loadReport(), loadBatches()])
  })
}

main().catch((error) => {
  const root = document.getElementById('app')
  if (root) {
    root.replaceChildren(h('div', { class: 'zdd' },
      h('div', { class: 'notice error', text: `${t('error')}: ${String(error?.message ?? error)}` })
    ))
  }
})
